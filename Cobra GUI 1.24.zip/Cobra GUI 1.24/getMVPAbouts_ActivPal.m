function mvbouts = getMVPAbouts_ActivPal(stepRaw,mvbouts,mvw,mvCrit) %#ok<*INUSL>
% 
% To avoid using loops I did the following:%
%     calculate cumsum%
%     shift the cumsum by (windowsize)%
%     substract the shifted from the original
%     now check if this is > the threshold value: this is our output.
% 
% This gives us 1's each time the criterion is satisfied, eg:
% 00100000
% 
% However I want to have 1's for the next (windowsize) points, eg:
% 00111000 (windowsize=3)
% 
% next step is to create a vector with the indexes of the 1's, create another vector by adding (windowsize) to each element and run a loop that sets to 1 all values of (output) between vector1 and vector2.

mvbouts=zeros(size(stepRaw,1),1); %#ok<NASGU>
% mvbouts2 = mvbouts;

%calculate cumsum
ctt = cumsum(stepRaw);
%shift cumsum by (windowsize)
ctto=[zeros(mvw,1); ctt];
%substract the shifted cumsum from the original
di = [ctt; zeros(mvw,1)]-ctto;
%output vector is 1 when the result is above threshold
mvbouts = di>=mvCrit;
%a bit of re-shifting indexes to have them align properly
mvbouts(end-mvw+2:end) = 0;
mvbouts = mvbouts(mvw:end-1);
mvbouts(1) = ctt(5)>=mvCrit;

%now add 1's for the next (windowsize) points following a 1
[c,~] = find(mvbouts);
for ie=1:size(c,1)
    mvbouts(c(ie):c(ie)+mvw-1) = 1;
end

% old code - 100x more time
% tic
% for ie = 1:size(stepRaw,1) - (mvw-1)
%     if size(find(stepRaw(ie:ie+mvw-1)),1) >= mvCrit
%         mvbouts2(ie:ie+mvw-1) = 1;
%     end
% end
% 
% toc
% 
% any(mvbouts2~=mvbouts)
% 
% mvbouts(1);




