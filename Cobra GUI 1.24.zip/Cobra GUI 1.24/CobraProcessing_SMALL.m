function varargout = CobraProcessing_SMALL(varargin)
% COBRAPROCESSING_SMALL MATLAB code for CobraProcessing_SMALL.fig
%      COBRAPROCESSING_SMALL, by itself, creates a new COBRAPROCESSING_SMALL or raises the existing
%      singleton*.
%
%      H = COBRAPROCESSING_SMALL returns the handle to a new COBRAPROCESSING_SMALL or the handle to
%      the existing singleton*.
%
%      COBRAPROCESSING_SMALL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in COBRAPROCESSING_SMALL.M with the given input arguments.
%
%      COBRAPROCESSING_SMALL('Property','Value',...) creates a new COBRAPROCESSING_SMALL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CobraProcessing_SMALL_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CobraProcessing_SMALL_OpeningFcn via varargin.
%
%      *See GUI optionsMenu on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CobraProcessing_SMALL

% Last Modified by GUIDE v2.5 04-Oct-2016 15:44:43

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @CobraProcessing_SMALL_OpeningFcn, ...
    'gui_OutputFcn',  @CobraProcessing_SMALL_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before CobraProcessing_SMALL is made visible.
function CobraProcessing_SMALL_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CobraProcessing_SMALL (see VARARGIN)

screensize = get( 0, 'Screensize' );
tpos = get(hObject,'position');
set(hObject,'position',[(screensize(3)-tpos(3))/2 (screensize(4)-tpos(4))/2 tpos(3) tpos(4)]);


%%
opengl software;
%puts axes handles into a list for easier control
for iax = 1:12
    udata.sa(iax) = handles.(['gd' num2str(iax)]);
end

set(hObject,'UserData',udata);

% Choose default command line output for CobraProcessing_SMALL
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes CobraProcessing_SMALL wait for user response (see UIRESUME)
% uiwait(handles.mainFig);


% --- Outputs from this function are returned to the command line.
function varargout = CobraProcessing_SMALL_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%maximize figure window to fit entire screen
% jFrame = get(handle(hObject),'JavaFrame'); 
% jFrame.setMaximized(true);


% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in openFolderBtn.
function openFolderBtn_Callback(hObject, eventdata, handles)
% hObject    handle to openFolderBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
udata = get(handles.mainFig,'UserData');

pn = uigetdir(pwd,'Select Folder');
if pn == 0, return, end

fList = dir(pn); fList([fList.isdir]) = []; %fList = fList(3:end);

udata.path = pn;

%set default output folder ([path]\results)
udata.rPath = [pn '\results'];
%check if folder already exists - if yes display warning etc
if exist(udata.rPath) == 7
    %ask for overwrite or change folder
    choice = questdlg('Output folder aready exists. Overwrite results?','Warning','OK','Change Folder','OK');
    switch choice
        case 'OK'
            %do nothing
        case 'Change Folder'
            tpn=uigetdir(udata.path,'Select or create a folder to save results');
            if ~isdir(tpn), mkdir(tpn); end
            udata.rPath = tpn;
    end
else
    mkdir(udata.rPath);
end

udata.fList = fList;

%load all files in memory
udata = loadAllFiles(udata,handles);

%update file list
set(handles.FilesList,'String',{fList.name});
set(handles.FilesList,'Value',1);

%load first file
udata = loadFromList(udata,handles);

if isempty(udata.events.day)
    errordlg('Error - this file is too short (<1 day) and can not be processed','Error - file too short');
    return,
end

if size(udata.events.day,1) > 12
    errordlg('Error - this file is too long (>12 days) and can not be processed','Error - file too long');
    return,
end

%reset state to 1
udata.state = 1;
udata = updateGUI(udata,handles);


set(handles.mainFig,'UserData',udata);


% --- Executes on selection change in FilesList.
function FilesList_Callback(hObject, eventdata, handles)
% hObject    handle to FilesList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns FilesList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from FilesList
udata = get(handles.mainFig,'UserData');

udata = loadFromList(udata,handles);

if isempty(udata.events.day)
    errordlg('Error - this file is too short (<1 day) and can not be processed','Error - file too short');
    return,
end

if size(udata.events.day,1) > 12
    errordlg('Error - this file is too long (>12 days) and can not be processed','Error - file too long');
    return,
end

%reset state to 1
udata.state = 1;
udata = updateGUI(udata,handles);

%load sleep events if required by user
if isfield(udata,'sleepFolder')
    [udata,fileFound] = loadSleepTimes(udata,handles);
    if fileFound
        udata.state = 2;
        udata = updateGUI(udata,handles);
    end
elseif isfield(udata,'sleepLog')
    if udata.monType==3
        udata = getSleepFromLog_ActivPal(udata,handles);
    else
        udata = getSleepFromLog(udata,handles);
    end
    if isfield(udata.events,'sleep')
        udata.state = 2;
        udata = updateGUI(udata,handles);
    end
elseif isfield(udata,'logInfo')
    if udata.monType==3
        udata = getSleepFromLog_ActivPal(udata,handles);
    else
        udata = getSleepFromLogLSAC(udata,handles);
    end
    if isfield(udata.events,'sleep')
        udata.state = 2;
        udata = updateGUI(udata,handles);
    end
    if isfield(udata.events,'nonwear')
        udata.state = 31;
        udata = updateGUI(udata,handles);
    end
end

%

set(handles.mainFig,'UserData',udata);


% --- Executes during object creation, after setting all properties.
function FilesList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FilesList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in sleepProc.
function sleepProc_Callback(hObject, eventdata, handles)
% hObject    handle to sleepProc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
udata = get(handles.mainFig,'UserData');

udata.isEditing = 1; %sleep

%get clicked points and create sleep events list

if ~isfield(udata.events,'son')
    udata.events.son = [];
end
if ~isfield(udata.events,'soff')
    udata.events.soff = [];
end
if ~isfield(udata.events,'sind')
    udata.events.sind = 1;
end

set(handles.mainFig,'userdata',udata);
set(handles.sleepProc, 'enable','off');


set(handles.mainFig,'WindowButtonMotionFcn',{@dispCoord,handles,udata});
set(handles.mainFig,'WindowButtonUpFcn',{@pickSleepEvent,handles,udata});
set(handles.mainFig,'WindowKeyPressFcn',{@donePickSleep,handles,udata});

function nonwearThreshold_Callback(hObject, eventdata, handles)
% hObject    handle to nonwearThreshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nonwearThreshold as text
%        str2double(get(hObject,'String')) returns contents of nonwearThreshold as a double


% --- Executes during object creation, after setting all properties.
function nonwearThreshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nonwearThreshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in nonWearProc.
function nonWearProc_Callback(hObject, eventdata, handles)
% hObject    handle to nonWearProc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

udata = get(handles.mainFig,'UserData');
nwt = round(str2double(get(handles.nonwearThreshold,'String')));

if ~isfield(udata.events,'nwon')
    udata.events.nwon = [];
end
if ~isfield(udata.events,'nwoff')
    udata.events.nwoff = [];
end

if (udata.monType == 2) %if geneactiv, counts are not 0 when non wear, use other method (SD)
    %     nwi = getGeneNonWear(udata,handles);
    nw = udata.counts<=str2double(get(handles.nonWearWindowDuration,'string')) & udata.events.sleep == 0;
    nwi = find(diff(nw)~=0)+1;
else
    nw = udata.counts == 0 & udata.events.sleep == 0;
    nwi = find(diff(nw)~=0)+1;
end

nwf = [];
nwf(size(udata.counts,1),size(udata.counts,2)) = 0;

if ~isempty(nwi)
    if ~nw(nwi(1))
        nwi = [1; nwi];
    end
    
    if nw(nwi(end))
        nwi = [nwi; size(nw,1)];
    end
    
    for iev = 1:2:size(nwi,1)
        if nwi(iev+1)-nwi(iev) > nwt
            if (~isfield(udata,'nonwear') || (~udata.events.nonwear(nwi(iev)) && ~udata.events.nonwear(nwi(iev+1)))) && (~isfield(udata,'sleep') || (~udata.events.sleep(nwi(iev)) && ~udata.events.sleep(nwi(iev+1))))
                nwf(nwi(iev):nwi(iev+1)-1) = 1;
                udata.events.nwon = [udata.events.nwon nwi(iev)];
                udata.events.nwoff = [udata.events.nwoff nwi(iev+1)];
            end
        end
    end
    
    udata.events.nwind = 1+ size(udata.events.nwon,2)+size(udata.events.nwoff,2);
    nwon = udata.events.nwon; nwoff = udata.events.nwoff;
    axLims = cell2mat(get(udata.sa,'xlim'));
    if isfield(udata,'nwl')
        iiline = size(udata.nwl,2)+1;
    else
        iiline = 1;
    end
    for ion = 1:size(nwon,2)
        iiax = find(axLims(:,1)<=nwon(ion) & axLims(:,2)>=nwon(ion) & axLims(:,1)~=0 & axLims(:,2)~=1);
        axes(udata.sa(iiax));
        ylims = get(gca,'ylim');
        udata.nwl(iiline) = line([nwon(ion) nwon(ion)],ylims,'color',[1 1 0]);
        iiline = iiline+1;
    end
    
    for ioff = 1:size(nwoff,2)
        iiax = find(axLims(:,1)<=nwoff(ioff) & axLims(:,2)>=nwoff(ioff));
        axes(udata.sa(iiax));
        ylims = get(gca,'ylim');
        udata.nwl(iiline) = line([nwoff(ioff) nwoff(ioff)],ylims,'color','blue');
        iiline = iiline+1;
    end
    udata = createNonWearFromEvents(udata,udata.events.nwon,udata.events.nwoff);
end

% if isfield(udata.events,'nonwear')
%     udata.events.nonwear = nwf | udata.events.nonwear;
% else
%     udata.events.nonwear = nwf;
% end

%update graphs with non wear zones
udata.state = 31;
udata = updateGUI(udata,handles);
set(handles.nonWearProc,'enable','off');

set(handles.mainFig,'UserData',udata);





function lightThreshold_Callback(hObject, eventdata, handles)
% hObject    handle to lightThreshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lightThreshold as text
%        str2double(get(hObject,'String')) returns contents of lightThreshold as a double


% --- Executes during object creation, after setting all properties.
function lightThreshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lightThreshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function moderateThreshold_Callback(hObject, eventdata, handles)
% hObject    handle to moderateThreshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of moderateThreshold as text
%        str2double(get(hObject,'String')) returns contents of moderateThreshold as a double


% --- Executes during object creation, after setting all properties.
function moderateThreshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to moderateThreshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vigorousThreshold_Callback(hObject, eventdata, handles)
% hObject    handle to vigorousThreshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vigorousThreshold as text
%        str2double(get(hObject,'String')) returns contents of vigorousThreshold as a double


% --- Executes during object creation, after setting all properties.
function vigorousThreshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vigorousThreshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in thresholdProc.
function thresholdProc_Callback(hObject, eventdata, handles)
% hObject    handle to thresholdProc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

udata = get(handles.mainFig,'UserData');
lt = round(str2double(get(handles.lightThreshold,'String')));
mt = round(str2double(get(handles.moderateThreshold,'String')));
vt = round(str2double(get(handles.vigorousThreshold,'String')));

%% sedentary
%

nw = (udata.counts >= 0 & udata.counts < lt) & udata.events.sleep == 0 & udata.events.nonwear == 0;
nwi = find(diff(nw)~=0)+1;

nwf = [];
nwf(size(udata.events.sleep,1),size(udata.events.sleep,2)) = 0;

if ~isempty(nwi)
    if ~nw(nwi(1))
        nwi = [1; nwi];
    end
    
    if nw(nwi(end))
        nwi = [nwi; size(nw,1)];
    end
    
    
    for iev = 1:2:size(nwi,1)
        %     if nwi(iev+1)-nwi(iev) > nwt
        nwf(nwi(iev):nwi(iev+1)-1) = 1;
        %     end
    end
end
udata.events.sedentary = (udata.events.sedentary | nwf) & ~udata.events.light & ~udata.events.moderate  & ~udata.events.vigorous  & ~udata.events.sleep;

%% light
%

nw = (udata.counts >= lt & udata.counts < mt) & udata.events.sleep == 0 & udata.events.nonwear == 0;
nwi = find(diff(nw)~=0)+1;

nwf = [];
nwf(size(udata.events.sleep,1),size(udata.events.sleep,2)) = 0;

if ~isempty(nwi)
    if ~nw(nwi(1))
        nwi = [1; nwi];
    end
    
    if nw(nwi(end))
        nwi = [nwi; size(nw,1)];
    end
    
    
    for iev = 1:2:size(nwi,1)
        %     if nwi(iev+1)-nwi(iev) > nwt
        nwf(nwi(iev):nwi(iev+1)-1) = 1;
        %     end
    end
end
udata.events.light = (udata.events.light | nwf) & ~udata.events.sedentary & ~udata.events.moderate  & ~udata.events.vigorous  & ~udata.events.sleep;

%% moderate
%

nw = (udata.counts >= mt & udata.counts < vt) & udata.events.sleep == 0 & udata.events.nonwear == 0;
nwi = find(diff(nw)~=0)+1;

nwf = [];
nwf(size(udata.events.sleep,1),size(udata.events.sleep,2)) = 0;
if ~isempty(nwi)
    if ~nw(nwi(1))
        nwi = [1; nwi];
    end
    
    if nw(nwi(end))
        nwi = [nwi; size(nw,1)];
    end
    
    
    for iev = 1:2:size(nwi,1)
        %     if nwi(iev+1)-nwi(iev) > nwt
        nwf(nwi(iev):nwi(iev+1)-1) = 1;
        %     end
    end
end
udata.events.moderate = (udata.events.moderate | nwf) & ~udata.events.sedentary & ~udata.events.light  & ~udata.events.vigorous  & ~udata.events.sleep;

%% vigorous
%

nw = (udata.counts >= vt) & udata.events.sleep == 0 & udata.events.nonwear == 0;
nwi = find(diff(nw)~=0)+1;

nwf = [];
nwf(size(udata.events.sleep,1),size(udata.events.sleep,2)) = 0;
if ~isempty(nwi)
    if ~nw(nwi(1))
        nwi = [1; nwi];
    end
    
    if nw(nwi(end))
        nwi = [nwi; size(nw,1)];
    end
    
    nwf = [];
    nwf(size(udata.events.sleep,1),size(udata.events.sleep,2)) = 0;
    for iev = 1:2:size(nwi,1)
        %     if nwi(iev+1)-nwi(iev) > nwt
        nwf(nwi(iev):nwi(iev+1)-1) = 1;
        %     end
    end
end

udata.events.vigorous = (udata.events.vigorous | nwf) & ~udata.events.sedentary & ~udata.events.light  & ~udata.events.moderate  & ~udata.events.sleep;

%  udata.events.MVPA = (udata.events.light | udata.events.moderate | udata.events.vigorous);

if udata.monType == 3
    udata.events.MVPA = (udata.events.light | udata.events.moderate | udata.events.vigorous);
else
    udata.events.MVPA = (udata.events.moderate | udata.events.vigorous);
end

%update graphs with non wear zones
udata.state = 4;
udata = updateGUI(udata,handles);

set(handles.mainFig,'UserData',udata);


% --- Executes on button press in saveProc.
function saveProc_Callback(hObject, eventdata, handles)
% hObject    handle to saveProc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

udata = get(handles.mainFig,'USerData');

if udata.monType == 3
    getOutputPerDay_ActivPal(udata,handles);
else
    getOutputPerDay(udata,handles);
end


function MVPADur_Callback(hObject, eventdata, handles)
% hObject    handle to MVPADur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MVPADur as text
%        str2double(get(hObject,'String')) returns contents of MVPADur as a double


% --- Executes during object creation, after setting all properties.
function MVPADur_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MVPADur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function MVPAPercent_Callback(hObject, eventdata, handles)
% hObject    handle to MVPAPercent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MVPAPercent as text
%        str2double(get(hObject,'String')) returns contents of MVPAPercent as a double


% --- Executes during object creation, after setting all properties.
function MVPAPercent_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MVPAPercent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sedDur_Callback(hObject, eventdata, handles)
% hObject    handle to sedDur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sedDur as text
%        str2double(get(hObject,'String')) returns contents of sedDur as a double


% --- Executes during object creation, after setting all properties.
function sedDur_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sedDur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sedPercent_Callback(hObject, eventdata, handles)
% hObject    handle to sedPercent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sedPercent as text
%        str2double(get(hObject,'String')) returns contents of sedPercent as a double


% --- Executes during object creation, after setting all properties.
function sedPercent_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sedPercent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in boutsProc.
function boutsProc_Callback(hObject, eventdata, handles)
% hObject    handle to boutsProc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

udata = get(handles.mainFig,'UserData');

mvw = round(str2double(get(handles.MVPADur,'String')));
mvper = round(str2double(get(handles.MVPAPercent,'String')));
sedw = round(str2double(get(handles.sedDur,'String')));
sedper = round(str2double(get(handles.sedPercent,'String')));

mvbouts = []; mvbouts(size(udata.counts,1),size(udata.counts,2)) = 0;
for ie = 1:size(udata.counts,1) - (mvw-1)
    if size(find(udata.events.MVPA(ie:ie+mvw-1)),1) >= mvw*mvper/100
        mvbouts(ie:ie+mvw-1) = 1;
    end
end

sedbouts = []; sedbouts(size(udata.counts,1),size(udata.counts,2)) = 0;
for ie = 1:size(udata.counts,1) - (sedw-1)
    if size(find(udata.events.sedentary(ie:ie+sedw-1)),1) >= sedw*sedper/100
        sedbouts(ie:ie+sedw-1) = 1;
    end
end

udata.events.mvbouts = mvbouts;
udata.events.sedbouts = sedbouts;

%update graphs with bouts
udata.state = 5;
udata = updateGUI(udata,handles);

set(handles.mainFig,'UserData',udata);



function wearTimeValid_Callback(hObject, eventdata, handles)
% hObject    handle to wearTimeValid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of wearTimeValid as text
%        str2double(get(hObject,'String')) returns contents of wearTimeValid as a double


% --- Executes during object creation, after setting all properties.
function wearTimeValid_CreateFcn(hObject, eventdata, handles)
% hObject    handle to wearTimeValid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function nwearTimeValid_Callback(hObject, eventdata, handles)
% hObject    handle to nwearTimeValid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nwearTimeValid as text
%        str2double(get(hObject,'String')) returns contents of nwearTimeValid as a double


% --- Executes during object creation, after setting all properties.
function nwearTimeValid_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nwearTimeValid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function daysValid_Callback(hObject, eventdata, handles)
% hObject    handle to daysValid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of daysValid as text
%        str2double(get(hObject,'String')) returns contents of daysValid as a double


% --- Executes during object creation, after setting all properties.
function daysValid_CreateFcn(hObject, eventdata, handles)
% hObject    handle to daysValid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function wdaysValid_Callback(hObject, eventdata, handles)
% hObject    handle to wdaysValid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of wdaysValid as text
%        str2double(get(hObject,'String')) returns contents of wdaysValid as a double


% --- Executes during object creation, after setting all properties.
function wdaysValid_CreateFcn(hObject, eventdata, handles)
% hObject    handle to wdaysValid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function scaleTxt_Callback(hObject, eventdata, handles)
% hObject    handle to scaleTxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of scaleTxt as text
%        str2double(get(hObject,'String')) returns contents of scaleTxt as a double
udata = get(handles.mainFig,'UserData');
udata.state = 6;
udata = updateGUI(udata,handles);


% --- Executes during object creation, after setting all properties.
function scaleTxt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to scaleTxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function optionsMenu_Callback(hObject, eventdata, handles)
% hObject    handle to optionsMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function changeOutputFolderMenu_Callback(hObject, eventdata, handles)
% hObject    handle to changeOutputFolderMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
udata = get(handles.mainFig,'UserData');
tpn=uigetdir(udata.path,'Select or create a folder to save results');
if tpn ==0, return; end
if ~isdir(tpn), mkdir(tpn); end
udata.rPath = tpn;
set(handles.mainFig,'UserData',udata);

% --------------------------------------------------------------------
function linkOutputFolderMenu_Callback(hObject, eventdata, handles)
% hObject    handle to linkOutputFolderMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
udata = get(handles.mainFig,'UserData');
tpn=uigetdir(udata.path,'Select results folder');
if tpn ==0, return; end

rfol = tpn;
fc = dir(tpn);
for id = 1:size(fc,1)
    if strcmp(fc(id).name,'mat') && fc(id).isdir
        rfol = fullfile(tpn,fc(id).name);
        break;
    end
end

udata.sleepFolder = rfol;
set(handles.mainFig,'UserData',udata);


% --------------------------------------------------------------------
function WriteSumFile_Callback(hObject, eventdata, handles)
% hObject    handle to WriteSumFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
udata = get(handles.mainFig,'UserData');

if udata.monType == 3
    writeSumFile_ActivPal(udata);
else
    writeSumFile(udata);
end

% --- Executes on button press in doallBtn.
function doallBtn_Callback(hObject, eventdata, handles)
% hObject    handle to doallBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cval = get(handles.FilesList,'value');

while cval <= size(get(handles.FilesList,'string'),1)
    set(handles.FilesList,'value',cval);
    FilesList_Callback(handles.FilesList, [], handles);
    nonWearProc_Callback(handles.nonWearProc, [], handles);
    thresholdProc_Callback(handles.thresholdProc, [], handles);
    boutsProc_Callback(handles.boutsProc, [], handles);
    saveProc_Callback(handles.saveProc, eventdata, handles);
    
    cval = cval+1;
    
end


% --------------------------------------------------------------------
function loadSleepLogFile_menu_Callback(hObject, eventdata, handles)
% hObject    handle to loadSleepLogFile_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

udata = get(handles.mainFig,'UserData');

[fn,pn] = uigetfile({'*.xls;*.xlsx;*.csv'},'Select sleeplog file');
if pn == 0, return, end


%% wait figure while loading
set(0,'units','pixels') ;
Pix_SS = get(0,'screensize');
hd = dialog('Position',[Pix_SS(3)/2-75 Pix_SS(4)/2-40 150 80],'Name','My Dialog');
txt = uicontrol('Parent',hd,...
    'Style','text',...
    'fontsize',14,...
    'Position',[50 30 40 20],...
    'String','Wait');

pause(0.01);

%% SPECIAL LOG FOR LSAC
udata.logInfo = main_parse_LSAC_logs(pn,fn);


%% old
%         rawSleep = importSleepLogFile(fullfile(pn,fn));
%
%         %% delete headers
%         rawSleep(1:2,:) = [];
%
%         %% get file name
%         pNames = rawSleep(:,1);
%
%         rawSleep(:,1) = [];
%
%         %% Replace non-numeric cells with NaN
%         R = cellfun(@(x) ~isnumeric(x) && ~islogical(x),rawSleep); % Find non-numeric cells
%         rawSleep(R) = {NaN}; % Replace non-numeric cells
%         rawSleep = cell2mat(rawSleep);
%         %participant x 2 x day
%         rawSleep = reshape(rawSleep,size(rawSleep,1),2,size(rawSleep,2)/2);
%
%         udata.sleepLog.times = rawSleep;
%         udata.sleepLog.part = pNames;
%

close(hd);
set(handles.mainFig,'UserData',udata);
FilesList_Callback(handles.FilesList, [], handles);


function dispCoord(object,eventdata,hh,udata)
% Modify mouse pointer over axes
if isMultipleCall();  return;  end
hAxes = overobj('axes');
if ~isempty(hAxes)
    setptr(hh.mainFig, 'crosshair');
    
    d = get(hAxes,'currentpoint'); c = floor(d(1,1));
    if c <= 0, c = 1; end
    set(hh.timeInd_txt,'string',datestr(udata.time(c),'HH:MM'));
    set(hh.cntInd_txt,'string',num2str(round(udata.counts(c))));
else
    setptr(hh.mainFig, 'arrow');
    set(hh.timeInd_txt,'string','');
    set(hh.cntInd_txt,'string','');
end

function dispCoordConsole(object,eventdata,hh,udata)
hAxes = overobj('axes');
if ~isempty(hAxes)
    
    c = get(hAxes,'currentpoint'); c = floor(c(1,1));
    if strcmp(get(gcf,'SelectionType'),'normal')
        disp([' LEFT ' datestr(udata.time(c),'HH:MM') '  ' num2str(round(udata.counts(c)))]);
    elseif strcmp(get(gcf,'SelectionType'),'alt')
        disp([' RIGHT ' datestr(udata.time(c),'HH:MM') '  ' num2str(round(udata.counts(c)))]);
    end
end





% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
udata=get(handles.mainFig,'userdata');
if get(hObject,'value')
    set(handles.mainFig,'WindowButtonMotionFcn',{@dispCoord,handles,udata});
    set(handles.mainFig,'WindowButtonUpFcn',{@dispCoordConsole,handles,udata});
else
    set(handles.mainFig,'WindowButtonMotionFcn','');
    set(handles.mainFig,'WindowButtonUpFcn','');
end


% --- Executes on button press in speelConfirm_btn.
function speelConfirm_btn_Callback(hObject, eventdata, handles)
% hObject    handle to speelConfirm_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
udata = get(handles.mainFig,'userdata');
udata.state = 21;
udata = updateGUI(udata,handles);


function pickSleepEvent(object,eventdata,hh,udata)
if isMultipleCall();  return;  end
udata=get(hh.mainFig,'userdata');
hAxes = overobj('axes');
if ~isempty(hAxes)
    modifiers = get(gcf,'currentModifier');
    selType = get(gcf,'SelectionType');
    disp(modifiers);
    
    xpos = get(hAxes,'currentpoint'); xpos = floor(xpos(1,1)); ylims = get(gca,'ylim');
    if strcmp(selType,'normal') %left click = start sleep
        sonInd = find(abs(udata.events.son-xpos)<=60);
        if ~isempty(sonInd) %if there is already a start sleep within 60 mins - move it instead of add
            udata.events.son(sonInd) = round(xpos);
            %also move line
            linePos = cell2mat(get(udata.sl,'xdata')); linePos = linePos(:,1);
            [~, lineInd] = min(abs(linePos-xpos));
            set(udata.sl(lineInd),'xdata',[xpos xpos]);
            drawnow;
        else
            udata.events.son(end+1) = round(xpos);
            udata.sl(end+1) = line([xpos xpos],ylims,'color','green');
            %             udata.sl(udata.events.sind) = line([xpos xpos],ylims,'color','green');
            %             udata.events.sind = udata.events.sind+1;
        end
    elseif strcmp(selType,'alt') %right click = end sleep
        soffInd = find(abs(udata.events.soff-xpos)<=60);
        if ~isempty(soffInd) %if there is already a start sleep within 60 mins - move it instead of add
            udata.events.soff(soffInd) = round(xpos);
            %also move line
            linePos = cell2mat(get(udata.sl,'xdata')); linePos = linePos(:,1);
            [~, lineInd] = min(abs(linePos-xpos));
            set(udata.sl(lineInd),'xdata',[xpos xpos]);
            drawnow;
        else
            udata.events.soff(end+1) = round(xpos);
            udata.sl(end+1) = line([xpos xpos],ylims,'color','red');
            %             udata.sl(udata.events.sind) = line([xpos xpos],ylims,'color','red');
            %             udata.events.sind = udata.events.sind+1;
        end
    end
    set(hh.mainFig,'userdata',udata);
end

function donePickSleep(object,eventdata,hh,udata)
if isMultipleCall();  return;  end
udata=get(hh.mainFig,'userdata');
keyPressed = eventdata.Key; %get(gcf,'CurrentKey');
hAxes = overobj('axes');
if ~isempty(hAxes)
    xpos = get(hAxes,'currentpoint'); xpos = floor(xpos(1,1));
end

% disp(keyPressed);
% get(hh.mainFig,'CurrentObject');

if strcmp(keyPressed,'space')
    setptr(hh.mainFig, 'arrow');
    set(hh.mainFig,'WindowButtonMotionFcn','');
    set(hh.mainFig,'WindowButtonUpFcn','');
    %     set(hh.mainFig,'WindowKeyPressFcn','');
    set(hh.sleepProc, 'enable','on');
    set(hh.timeInd_txt,'string','');
    set(hh.cntInd_txt,'string','');
    %         set(0, 'currentfigure', hh.mainFig);
    
    udata = createSleepFromEvents(udata,udata.events.son,udata.events.soff);
    udata.state = 2;
    udata = updateGUI(udata,hh);
    set(hh.mainFig,'UserData',udata);
    guidata(object, hh);
    
elseif strcmp(keyPressed,'delete')
    if ~isempty(hAxes)
        %detect hovered object
        udata = deleteObjectOverMouse(udata,hh,xpos);
        set(hh.mainFig,'userdata',udata);
    end
end

function pickNonWearEvent(object,eventdata,hh,udata)
if isMultipleCall();  return;  end
udata=get(hh.mainFig,'userdata');
% keyPressed = eventdata.Key;
hAxes = overobj('axes');
if ~isempty(hAxes)
    modifiers = get(gcf,'currentModifier');
    selType = get(gcf,'SelectionType');
    %     disp(modifiers);
    xpos = get(hAxes,'currentpoint'); xpos = floor(xpos(1,1)); ylims = get(gca,'ylim');
    
    if isempty(modifiers)
        
        
        if strcmp(selType,'normal') %left click = start sleep
            nwonInd = find(abs(udata.events.nwon-xpos)<=30);
            if ~isempty(nwonInd) %if there is already a start sleep within 60 mins - move it instead of add
                udata.events.nwon(nwonInd) = round(xpos);
                %also move line
                linePos = cell2mat(get(udata.nwl,'xdata')); linePos = linePos(:,1);
                [~, lineInd] = min(abs(linePos-xpos));
                set(udata.nwl(lineInd),'xdata',[xpos xpos]);
                drawnow;
            else
                udata.events.nwon(end+1) = round(xpos);
                udata.nwl(end+1) = line([xpos xpos],ylims,'color',[1 1 0]);
                %                 udata.nwl(udata.events.nwind) = line([xpos xpos],ylims,'color',[1 1 0]);
                %                 udata.events.nwind = udata.events.nwind+1;
            end
        elseif strcmp(selType,'alt') %right click = end sleep
            nwoffInd = find(abs(udata.events.nwoff-xpos)<=60);
            if ~isempty(nwoffInd) %if there is already a start sleep within 60 mins - move it instead of add
                udata.events.nwoff(nwoffInd) = round(xpos);
                %also move line
                linePos = cell2mat(get(udata.nwl,'xdata')); linePos = linePos(:,1);
                [~, lineInd] = min(abs(linePos-xpos));
                set(udata.nwl(lineInd),'xdata',[xpos xpos]);
                drawnow;
            else
                udata.events.nwoff(end+1) = round(xpos);
                udata.nwl(end+1) = line([xpos xpos],ylims,'color','blue');
                %                 udata.nwl(udata.events.nwind) = line([xpos xpos],ylims,'color','blue');
                %                 udata.events.nwind = udata.events.nwind+1;
            end
        end
        
    elseif strcmpi(modifiers{1},'shift')  %shift click
        if isfield(udata,'nwr')
            tt = [udata.nwr.Vertices]; tt = tt(1:2,1:2:end);
            pInd = find(xpos>tt(1,:) & xpos<tt(2,:));
            if ~isempty(pInd) %if we are over a nonwear patch
                udata = deleteZoneFromGUI(tt,pInd,udata);
            end
        end
        if isfield(udata.events,'nonwear')
            udata.events.nonwear(tt(1,pInd):tt(2,pInd)) = 0;
        end
    elseif strcmpi(modifiers{1},'control')
        if isfield(udata,'nwr')
            tt = [udata.nwr.Vertices]; tt = tt(1:2,1:2:end);
            pInd = find(xpos>tt(1,:) & xpos<tt(2,:));
            if ~isempty(pInd)
                typeSelection = changeNonWearZone;
                choice = typeSelection.UserData.state;
                delete(typeSelection);
                %now do stuff depending
                switch choice
                    case 0 %sleep
                    case 1 %sed
                        udata.events.sedentary(tt(1,pInd):tt(2,pInd)) = 1;
                        udata.events.forced.sedentary(tt(1,pInd):tt(2,pInd)) = 1;
                        udata = deleteZoneFromGUI(tt,pInd,udata);
                    case 2 %light
                        udata.events.light(tt(1,pInd):tt(2,pInd)) = 1;
                        udata.events.forced.light(tt(1,pInd):tt(2,pInd)) = 1;
                        udata = deleteZoneFromGUI(tt,pInd,udata);
                    case 3 %mvpa
                        udata.events.vigorous(tt(1,pInd):tt(2,pInd)) = 1;
                        udata.events.forced.vigorous(tt(1,pInd):tt(2,pInd)) = 1;
                        udata = deleteZoneFromGUI(tt,pInd,udata);
                    case 4 %cancel
                        return
                end
                
                
            end %if patch
        end %if any patches at all
        
        
    end
    set(hh.mainFig,'userdata',udata);
end

function donePickNonWear(object,eventdata,hh,udata)
if isMultipleCall();  return;  end
udata=get(hh.mainFig,'userdata');
set(0, 'currentfigure', hh.mainFig);
keyPressed = get(gcf,'CurrentKey');
hAxes = overobj('axes');
if ~isempty(hAxes)
    xpos = get(hAxes,'currentpoint'); xpos = floor(xpos(1,1));
end

%  disp(keyPressed);
if strcmp(keyPressed,'space')
    setptr(hh.mainFig, 'arrow');
    set(hh.timeInd_txt,'string','');
    set(hh.cntInd_txt,'string','');
    
    %     set(hh.mainFig,'WindowKeyPressFcn','');
    set(hh.mainFig,'WindowButtonMotionFcn','');
    set(hh.mainFig,'WindowButtonUpFcn','');
    set(hh.nonWearManual, 'enable','on');
    %         set(0, 'currentfigure', hh.mainFig);
    udata = createNonWearFromEvents(udata,udata.events.nwon,udata.events.nwoff);
    udata.state = 31;
    udata = updateGUI(udata,hh);
    set(hh.mainFig,'UserData',udata);
elseif strcmp(keyPressed,'delete')
    if ~isempty(hAxes)
        %detect hovered object
        udata = deleteObjectOverMouse(udata,hh,xpos);
        set(hh.mainFig,'userdata',udata);
    end
end


% --- Executes on selection change in Console.
function Console_Callback(hObject, eventdata, handles)
% hObject    handle to Console (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Console contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Console


% --- Executes during object creation, after setting all properties.
function Console_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Console (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function nonWearWindowDuration_Callback(hObject, eventdata, handles)
% hObject    handle to nonWearWindowDuration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nonWearWindowDuration as text
%        str2double(get(hObject,'String')) returns contents of nonWearWindowDuration as a double


% --- Executes during object creation, after setting all properties.
function nonWearWindowDuration_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nonWearWindowDuration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in nonWearManual.
function nonWearManual_Callback(hObject, eventdata, handles)
% hObject    handle to nonWearManual (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

udata = get(handles.mainFig,'UserData');

udata.isEditing = 2; %sleep

%get clicked points and create sleep events list

if ~isfield(udata.events,'nwon')
    udata.events.nwon = [];
end
if ~isfield(udata.events,'nwoff')
    udata.events.nwoff = [];
end
if ~isfield(udata.events,'nwind')
    udata.events.nwind = 1;
end

% if ~isfield(udata,'nwl')
%     udata.nwl = [];
% end

set(handles.mainFig,'userdata',udata);
set(handles.nonWearManual, 'enable','off');

set(handles.mainFig,'WindowButtonMotionFcn',{@dispCoord,handles,udata});
set(handles.mainFig,'WindowButtonUpFcn',{@pickNonWearEvent,handles,udata});
set(handles.mainFig,'WindowKeyPressFcn',{@donePickNonWear,handles,udata});


% --- Executes on button press in nonWearConfirm.
function nonWearConfirm_Callback(hObject, eventdata, handles)
% hObject    handle to nonWearConfirm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
udata = get(handles.mainFig,'UserData');
udata.state = 3;
udata = updateGUI(udata,handles);

set(handles.mainFig,'UserData',udata);

function flag=isMultipleCall()
s = dbstack();
% s(1) corresponds to isMultipleCall
if numel(s)<=2, flag=false; return; end
% compare all functions on stack to name of caller
count = sum(strcmp(s(2).name,{s(:).name}));
% is caller re-entrant?
if count>1, flag=true; else flag=false; end



function startPeriodH_Callback(hObject, eventdata, handles)
% hObject    handle to startPeriodH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startPeriodH as text
%        str2double(get(hObject,'String')) returns contents of startPeriodH as a double


% --- Executes during object creation, after setting all properties.
function startPeriodH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startPeriodH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function startPeriodM_Callback(hObject, eventdata, handles)
% hObject    handle to startPeriodM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startPeriodM as text
%        str2double(get(hObject,'String')) returns contents of startPeriodM as a double


% --- Executes during object creation, after setting all properties.
function startPeriodM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startPeriodM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
