function doSleepFrag(pn,fname,pnraw,flraw);

if ~isdir([pn '\WITH VAN HEES']), mkdir([pn '\WITH VAN HEES']); end

SAMPLING_FREQ = 100;
WINSIZE = 5; %rolling average window size (s) and angle epoch size (s)
SCORE_EPOCH = 5; %min interval between movements to be considered sleep
OUTPUT_EPOCH = 60; %length of output epoch (s)

load(fullfile(pn,fname));

% check if raw mat is available
fI = find(strncmpi(fname(1:6),flraw,6)); 

if isempty(fI)
    res.events.sleepVanHees = [];
    res.events.sleepcobra = [];
    save(fullfile([pn '\WITH VAN HEES'],fname),'res');    
    return;
end

fI = fI(1);

% file is available - process
load(char(fullfile(pnraw,flraw(fI))));

clear button light rawBatt2 rawTemp2;

starttime = rawTime2(1,:);
cc = strsplit(starttime,' '); cc = char(cc(2));
cc = strsplit(cc,':');
nepochs = round((str2num(char(cc(1)))*3600 + str2num(char(cc(2)))*60 + str2num(char(cc(3))))/5);

clear rawTime2;

% crop data - for testing and graphing
% start_hour = 21;
% end_hour = 34;
% xyz = xyz(3600*SAMPLING_FREQ*start_hour:3600*SAMPLING_FREQ*end_hour-1,:);

%% rolling median of raw accels
xyzmed = medfilt1(xyz,SAMPLING_FREQ*WINSIZE);

% figure, plot(xyz(:,1).*20); hold on;
np = size(xyz,1);
clear xyz;

%% calculate angle
angle = atan(xyzmed(:,3)./sqrt(xyzmed(:,1).^2 + xyzmed(:,2).^2)).*(180/pi);

% figure, plot(angle); hold on,
clear xyzmed;

%% collapse in 5s epochs

angle = reshape(angle,SAMPLING_FREQ*WINSIZE,[])';
angleEp = mean(angle,2);

% figure, plot(1:SAMPLING_FREQ*WINSIZE:np,angleEp); hold on;
clear angle;

%% difference between successive epochs
adiffs = abs([0; diff(angleEp)]);
%indices of epochs with diff > 5degrees
ptsOver5 = find(adiffs>5);
%get times between epochs of >5deg that are more than SCORE_EPOCH mins
if ~isempty(ptsOver5)
    timesBetween5 = find(diff(ptsOver5) > SCORE_EPOCH*60/WINSIZE);
end

isSleep = false(size(angleEp,1),1);
if ~isempty(timesBetween5)
    for ii = 1:length(timesBetween5)
        isSleep(ptsOver5(timesBetween5(ii)):ptsOver5(timesBetween5(ii)+1)) = 1;
    end
end

% hold on, plot(1:SAMPLING_FREQ*WINSIZE:np,isSleep*40,'black','linewidth',2)

% hold on, plot(1:SAMPLING_FREQ*WINSIZE:np,[adiffs>5]*35);

% legend({'angle 5s epochs' 'is sleep' 'change over 5deg'});

sleepbuffer =  zeros(nepochs,1);
sleepalgo = [sleepbuffer;isSleep];
sleepcobra = res.events.sleep;
sleepcobra = repmat(sleepcobra,1,12);
sleepcobra=sleepcobra';
sleepcobra = sleepcobra(:);
sleepalgo(size(sleepcobra,1)+1:end) = [];
sleepcobra(size(sleepalgo,1)+1:end) = [];
sleepOut = sleepalgo & sleepcobra;

res.events.sleepVanHees = sleepOut;
res.events.sleepVanHees_untrimmed = sleepalgo;
res.events.sleepcobra = sleepcobra;

save(fullfile([pn '\WITH VAN HEES'],fname),'res');

