function [midpoint,bedTime,upTime,frag] = getSleepParameters(udata,td,iday);

% computes consistency and timing
if any(udata.events.sleep(td(iday)-720:td(iday)+719))
    sl = double(udata.events.sleep(td(iday)-720:td(iday)+719));
    [~,midpoint] = min(abs(cumsum(sl)-sum(sl)./2));
    midpoint = midpoint - 720;
    
    bedTime = NaN; bedTime = min(find(sl)) - 720;
    upTime = NaN; upTime = max(find(sl)) - 720;
else
    midpoint = NaN;
    bedTime = NaN;
    upTime = NaN;
end

if isfield(udata.events,'sleepVanHees') && isfield(udata.events,'sleepcobra') && ~isempty(udata.events.sleepVanHees)
    frag = 100 * sum(udata.events.sleepVanHees((td(iday)-720)*12:(td(iday)+719)*12)) ./ sum(udata.events.sleepcobra((td(iday)-720)*12:(td(iday)+719)*12));
else
    frag = NaN;
end