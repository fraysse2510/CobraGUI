%folder with results mat files
pn = uigetdir(pwd,'select folder to reprocess');
pndone = [pn  '\WITH VAN HEES'];

%folder with raw mat files
pnraw = 'Z:\EHHP\NVC_2017data_Francois\raw mat files';
flraw = dir(pnraw); flraw([flraw.isdir]) = []; flraw = {flraw.name}';

flistdone = dir(pndone); flistdone([flistdone.isdir]) = []; flistdone = {flistdone.name}';


fList = dir(pn); fList([fList.isdir]) = [];

fListToDo = struct('name','','date','','bytes',[],'isdir',[],'datenum',[]);
for ifile = 1:size(fList,1)
    isDone = ~isempty(find(strcmpi(fList(ifile).name,flistdone)));
    if ~isDone
        fListToDo(end+1) = fList(ifile);
    end
end

fListToDo(1) = [];

for ifile = 1:size(fListToDo,2)
    doSleepFrag(pn,fListToDo(ifile).name,pnraw,flraw);
end