function MVPAfitW50 = MVPAcurvefitW50(VEC);

%use curvefit to find bout duration at which 50 percent of MVPA is accumulated

SortedBouts = sort(VEC,'ascend');

csMVPAday = cumsum(VEC);

for iLB = 1:max(SortedBouts)
        totDurInBout(iLB) = length(find(SortedBouts==iLB)).*iLB;
    end
    cumInBouts = cumsum(totDurInBout)./csMVPAday(end).*100;
    

    allboutdur = [1:max(SortedBouts)];
    
    options = optimoptions(@lsqnonlin,'Algorithm','Levenberg-Marquardt','Display','off','Diagnostics','off');
    
    x0 = [3 2];
    fun = @(x)((allboutdur.^x(2))./((allboutdur.^x(2))+(x(1).^x(2)))) - cumInBouts./100;
    
    x = lsqnonlin(fun,x0,[],[],options);
    
    fit_points = ((allboutdur.^x(2))./(allboutdur.^x(2)+x(1).^x(2))).*100;

MVPAfitW50 = x(1);
   

end
    

