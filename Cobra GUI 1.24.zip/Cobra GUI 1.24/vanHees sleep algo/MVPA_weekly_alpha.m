function weekMVPAalpha = MVPA_weekly_alpha(dailyMVPA);


%find coefficient of variation for MVPA accumulated across days.
mvpaweek = dailyMVPA(:);
    
      mvpaweek(isnan(mvpaweek)) = [];
    MvpaWeek = mvpaweek';
    
    csWeek = cumsum(MvpaWeek);
    
    
    csMVPA = csWeek(diff([0,MvpaWeek]) == -1);
    if ~isempty(csMVPA)
        Bouts = [csMVPA(1) diff(csMVPA)];
    else Bouts = 0
    end

     
    VEC = sort(Bouts,'descend');
    
    % get alpha
    bins_spaces = linspace(0,2,50);
    binLims = 10.^bins_spaces;
    %remove bins larger than longest bout
    binLims(max(find(binLims < VEC(1)))+2:end) = [];
    binsR = hist(VEC,binLims);
    
    if size(binLims) > size(binsR)
        binLims = binLims(1:end-1);
    end
    binRnorm = binsR./binLims;
    %         figure, loglog(binLims,binRnorm,'b-o'), grid; hold on;
    
    sumBouts = 0;
    for iBout = 1:length(VEC)
        sumBouts = sumBouts+log(VEC(iBout)/(1-0.5));
    end
    
    sumBouts = 1./sumBouts;
    
    weekMVPAalpha = 1+length(VEC)*sumBouts;
    
    
    

end

% % 
% % 
% %     CumMvpa=cumsum(mvpa,1);
% %     VolumeMvpaEachDay = CumMvpa(1440,:);
% %     HalfMvpaVolDay = VolumeMvpaEachDay./2;
% %     
% %     
% %     for iDay = 1:size(HalfMvpaVolDay,2)
% %         
% %         
% %         HalfTime= CumMvpa(:,iDay) >= HalfMvpaVolDay(:,iDay);
% %         
% %         if ~isempty(find(HalfTime~=0, 1, 'first'))
% %             Half(iDay) = find(HalfTime~=0, 1, 'first');
% %         else
% %             Half(iDay) = nan;
% %         end
% %         
% %     end
% %     
% %     
% %     
% %     date = rawData.res.date;
% %     date = reshape(date,1440,[]);
% %     date = date(1,:);
% %     weekday(datenum(date,'dd/mm/yyyy'));
% %     daynum = weekday(datenum(date,'dd/mm/yyyy'));
% %     daynum = daynum';
% %     
% %     WeekendHalf = 0;
% %     WeekdayHalf = 0;
% %     
% %     WeekendDays = 0;
% %     WeekdayDays = 0;
% %     
% %     halfbyday = [daynum;Half];
% %     
% %     
% %     for iDay = 1:size(Half,2)
% %         
% %         if  ~isnan(halfbyday(2,iDay)) && ((halfbyday(1,iDay) == 1) || (halfbyday(1,iDay) == 7));
% %             
% %             WeekendHalf = WeekendHalf + Half(iDay);
% %             WeekendDays =  ( WeekendDays + 1);
% %             
% %         end
% %     end
% %     
% %     for iDay = 1:size(Half,2)
% %         
% %         if ~isnan(halfbyday(2,iDay)) && ((halfbyday(1,iDay) == 2) || (halfbyday(1,iDay) == 3) || (halfbyday(1,iDay) == 4) || (halfbyday(1,iDay) == 5) || (halfbyday(1,iDay) == 6));
% %             
% %             WeekdayHalf = WeekdayHalf + Half(iDay);
% %             WeekdayDays =   WeekdayDays + 1;
% %         end
% %     end
% %     
% %     TotalDays = (WeekendDays + WeekdayDays);
% %     
% %     T50weighted52 = ((WeekendHalf/WeekendDays)*2 + (WeekdayHalf/WeekdayDays)*5)/7;
% %     
% %     T50weighted11 = ((WeekendHalf/WeekendDays)+(WeekdayHalf/WeekdayDays))/2;