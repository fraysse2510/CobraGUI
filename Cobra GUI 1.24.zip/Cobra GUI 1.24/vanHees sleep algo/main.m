pn = uigetdir(pwd,'select folder to reprocess');


fList = dir(pn); fList([fList.isdir]) = [];

for ifile = 1:size(fList,1)
    isChild = strcmpi(fList(ifile).name(6),'c');
    
    if isChild
        LT = 390;
        MT = 1260;
        VT = 3480;
    else
        LT = 188;
        MT = 403;
        VT = 1131;
    end
    
    load(fullfile(pn,fList(ifile).name));
    %create a copy of the results
    res2 = res;
    torep = res2.events.sedentary | res2.events.light | res2.events.MVPA;
    
    %         % test - reproduce
    %         res2.events.sedentary = torep & res2.counts < 301;
    %         res2.events.light = torep & res2.counts >= 301 & res2.counts < 645;
    %         res2.events.moderate = torep & res2.counts >= 645 & res2.counts < 1810;
    %         res2.events.vigorous = torep & res2.counts >= 1810;
    
    %real
    res2.events.sedentary = torep & res2.counts < LT;
    res2.events.light = torep & res2.counts >= LT & res2.counts < MT;
    res2.events.moderate = torep & res2.counts >= MT & res2.counts < VT;
    res2.events.vigorous = torep & res2.counts >= VT;
    
    %add forced vig
    res2.events.vigorous = res2.events.vigorous | res2.events.forced.vigorous;
    
    %MVPA
    res2.events.MVPA = res2.events.moderate | res2.events.vigorous;
    
    %% reproc bouts
    mvw = 10; %round(str2double(get(handles.MVPADur,'String')));
    mvper = 80; %round(str2double(get(handles.MVPAPercent,'String')));
    sedw = 30; %round(str2double(get(handles.sedDur,'String')));
    sedper = 100; %round(str2double(get(handles.sedPercent,'String')));
    
    mvbouts = []; mvbouts(size(res2.counts,1),size(res2.counts,2)) = 0;
    for ie = 1:size(res2.counts,1) - (mvw-1)
        if size(find(res2.events.MVPA(ie:ie+mvw-1)),1) >= mvw*mvper/100
            mvbouts(ie:ie+mvw-1) = 1;
        end
    end
    
    sedbouts = []; sedbouts(size(res2.counts,1),size(res2.counts,2)) = 0;
    for ie = 1:size(res2.counts,1) - (sedw-1)
        if size(find(res2.events.sedentary(ie:ie+sedw-1)),1) >= sedw*sedper/100
            sedbouts(ie:ie+sedw-1) = 1;
        end
    end
    
    res2.events.mvbouts = mvbouts;
    res2.events.sedbouts = sedbouts;
    
    %% compute output
    getOutputPerDay(res2,fList(ifile).name);
    
end

%% check times in PA levels
% sum(res.events.sleep)
% sum(res.events.sedentary)
% sum(res.events.light)
% sum(res.events.moderate)
% sum(res.events.vigorous)
% sum(res.events.nonwear)
%
% sum(res2.events.sleep)
% sum(res2.events.sedentary)
% sum(res2.events.light)
% sum(res2.events.moderate)
% sum(res2.events.vigorous)
% sum(res2.events.nonwear)