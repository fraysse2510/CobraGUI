function monType = getMonType(udata)
%gets monitor type from header

fList = udata.fList;
path = udata.path;

fid = fopen(fullfile(path,fList(1).name));
tt=fscanf(fid,'%[^\n]',1);
fclose(fid);

if ~isempty(strfind(lower(tt),'actigraph'))
    monType = 1; %actigraph
elseif ~isempty(strfind(lower(tt),'geneactiv'))
    monType = 2; %geneActiv
elseif ~isempty(strfind(lower(tt),'activitycode'))
    monType = 3; %activPAL
else
    monType = 0; %actical (cobra)
end

end