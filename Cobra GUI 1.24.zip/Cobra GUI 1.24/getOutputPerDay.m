function getOutputPerDay(udata,handles)

nwval = round(str2double(get(handles.nwearTimeValid,'String')));
wval = round(str2double(get(handles.wearTimeValid,'String')));

vwd = 0;    %no of valid week days
vwed = 0;   %no of valid weekend days

%get file name
contents = cellstr(get(handles.FilesList,'String'));
fn = contents{get(handles.FilesList,'Value')}; fn = fn(1:strfind(fn,'.')-1);
fnCsv = [fn '_RESULTS.csv'];
fnMat = [fn '.mat'];
fnFig = [fn '_RESULTS.pdf'];

%create paths to save
csvPath = [udata.rPath '\csv'];
if ~isdir(csvPath), mkdir(csvPath); end
matPath = [udata.rPath '\mat'];
if ~isdir(matPath), mkdir(matPath); end
figPath = [udata.rPath '\figures'];
if ~isdir(figPath), mkdir(figPath); end

fid = fopen(fullfile(csvPath,fnCsv),'w');

%print header
fprintf(fid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n','day no','is weekend','sleep time min','wear time min','sedentary time min','light time min','moderate time min','vigorous time min','MVPA time min','MVPA time spent in bouts min','number of MVPA bouts','average MVPA bout length min','sedentary time spent in bouts min','number of sedentary bouts','average sedentary bout length min','50% sedentary time bout length','Alpha','alpha_error','GINI','Median bout length','Time above median','% time per bout above median','total counts','average counts');

td = udata.events.day;

wdt = [];
wedt = [];

%get start of recording period
startH = str2double(get(handles.startPeriodH,'String'));
startM = str2double(get(handles.startPeriodM,'String'));

%convert start time to ActivPal epochs
offsetEpochs = (startH * 60) + (startM);

%create offset vector
td_off = td + offsetEpochs;

for iday = 1:size(td,1)
    
    if iday == size(td,1) && offsetEpochs ~= 0 %if last day and we dont process starting at midnight
        endEpoch = 1439 - offsetEpochs;
    else
        endEpoch = 1439;
    end
    
    %check if day is valid
    if ~isfield(udata.events,'nonwear') || (size(find(udata.events.nonwear(td_off(iday):td_off(iday)+endEpoch)),1) < nwval)% &&  ((size(find(~udata.events.nonwear(td_off(iday):td_off(iday)+endEpoch)),1) - size(find(udata.events.sleep(td_off(iday):td_off(iday)+endEpoch)),1)) > wval)
        
        %day is valid, carry on processing
        
        %check if week or weekend day
        [dn, ~] =weekday(datenum(udata.date(td_off(iday)),'dd/mm/yyyy'));
        if (dn == 1) || (dn == 7)
            isweekend = 1;
            disp(['day ' num2str(iday) ' is valid - weekend']);
            vwed = vwed+1;
        else
            isweekend = 0;
            disp(['day ' num2str(iday) ' is valid - weekday']);
            vwd = vwd+1;
        end
        
        % sleep time
        % ignore sleep time for checkpoint day and day after
        if iday <= 2
            sleepTime = NaN;
        else
            sleepTime = size(find(udata.events.sleep(td_off(iday)-720:td_off(iday)+719)),1);
        end
        % wear time
        wearTime = size(find(~udata.events.nonwear(td_off(iday):td_off(iday)+endEpoch)),1) - size(find(udata.events.sleep(td_off(iday):td_off(iday)+endEpoch)),1); %%%%%%%%%%%%%%%%%%%%%%%%%%%
        % sed time
        sedTime = size(find(udata.events.sedentary(td_off(iday):td_off(iday)+endEpoch)),1);
        % light time
        lightTime = size(find(udata.events.light(td_off(iday):td_off(iday)+endEpoch)),1);
        % moderate time
        modTime = size(find(udata.events.moderate(td_off(iday):td_off(iday)+endEpoch)),1);
        % vigorous time
        vigTime = size(find(udata.events.vigorous(td_off(iday):td_off(iday)+endEpoch)),1);
        % MVPA time
        mvTime = modTime+vigTime;
        % MVPA bouts time
        mvpaboutsTime = size(find(udata.events.mvbouts(td_off(iday):td_off(iday)+endEpoch)),1);
        % sed bouts time
        sedboutsTime = size(find(udata.events.sedbouts(td_off(iday):td_off(iday)+endEpoch)),1);
        
        %         %total counts
        %         totcounts = sum(udata.counts(td_off(iday):td_off(iday)+endEpoch));
        
        %total counts excluding sleep and non wear
        tmpcnt = udata.counts(td_off(iday):td_off(iday)+endEpoch);
        tmpMask = ~(udata.events.sleep(td_off(iday):td_off(iday)+endEpoch) | udata.events.nonwear(td_off(iday):td_off(iday)+endEpoch));
        tmpcnt = tmpcnt(tmpMask);
        totcounts = sum(tmpcnt); avgcounts = totcounts./size(tmpcnt,1);
        
        %number of bouts - sedentary
        sedboutsNumber = ceil(size(find(diff(udata.events.sedbouts(td_off(iday):td_off(iday)+endEpoch))),1)./2);
        %if the day both starts and end with a bout we need to add 1 bout
        if udata.events.sedbouts(td_off(iday)) == 1 && udata.events.sedbouts(td_off(iday)+endEpoch) == 1
            sedboutsNumber = sedboutsNumber+1;
        end
        %number of bouts - mvpa
        mvpaboutsNumber = ceil(size(find(diff(udata.events.mvbouts(td_off(iday):td_off(iday)+endEpoch))),1)./2);
        %if the day both starts and end with a bout we need to add 1 bout
        if udata.events.mvbouts(td_off(iday)) == 1 && udata.events.mvbouts(td_off(iday)+endEpoch) == 1
            mvpaboutsNumber = mvpaboutsNumber+1;
        end
        
        %bout length at which 50% sed time is accumulated
        sedBoutLength50 = findSedBoutLength50(udata.events.sedentary(td_off(iday):td_off(iday)+endEpoch));
        
        %%
        % NEW METRICS
        tt = udata.events.sedentary(td_off(iday):td_off(iday)+endEpoch);
        
        kBout = 1;
        BL = 0;
        ind = 1;
        VEC = [];
        
        while ind < size(tt,1)
            if ~tt(ind)
                if BL
                    VEC(kBout) = BL;
                    kBout = kBout+1;
                    BL=0;
                end
                ind = ind+1;
            elseif tt(ind)
                BL = BL+1;
                ind = ind+1;
            end
        end
        
        VEC = sort(VEC,'descend');
        
        if 0%~isempty(VEC)
            
            tresb = 10;
            
            VEC(VEC<tresb) = [];
            
            %%
            %get GINI, AUC etc
            cumVEC = cumsum(VEC);
            fracbout=[1:size(VEC,2)].*(1/size(VEC,2));
            cumVECn = cumVEC./cumVEC(end);
            cumVECn=[0 cumVECn];
            fracbout=[0 fracbout];
            AUC=(trapz(fracbout,cumVECn)-0.5);
            GINI = AUC./0.5;
            Median_bout = median(VEC);
            Per_time_above_median = sum(VEC(VEC>median(VEC)))./sum(VEC).*100;
            Total_sed_Time = sum(VEC);
            no_bouts_above_median = sum(VEC>Median_bout);
            per_time_in_long_bouts = Per_time_above_median./no_bouts_above_median;
            frag_index = length(VEC)./sum(VEC);
            
            %%
            % get alpha
            bins_spaces = linspace(1,3,100);
            binLims = 10.^bins_spaces;
            %remove bins larger than longest bout
            binLims(max(find(binLims < VEC(1)))+2:end) = [];
            binsR = hist(VEC,binLims);
            
            if size(binLims) > size(binsR)
                binLims = binLims(1:end-1);
            end
            binRnorm = binsR./binLims;
            %         figure, loglog(binLims,binRnorm,'b-o'), grid; hold on;
            
            sumBouts = 0;
            for iBout = 1:length(VEC)
                sumBouts = sumBouts+log(VEC(iBout)/(10-0.5));
            end
            
            sumBouts = 1./sumBouts;
            
            alpha = 1+length(VEC)*sumBouts;
            SDalpha = (alpha-1)./sqrt(length(VEC));
            Constant = (alpha-1)*(10.^(alpha-1));
            
            %         estimates = trapz(binLims,binRnorm).*Constant*(binLims.^(-alpha));
            
            %         loglog(binLims,estimates,'blue','linewidth',2);
        else
            alpha = NaN;
            SDalpha = NaN;
            GINI = NaN;
            Median_bout = NaN;
            Per_time_above_median = NaN;
            per_time_in_long_bouts = NaN;
            
        end
        
        
        %%
        fprintf(fid,'%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u\n',iday,isweekend,sleepTime,wearTime,sedTime,lightTime,modTime,vigTime,mvTime,mvpaboutsTime,mvpaboutsNumber,(mvpaboutsTime./mvpaboutsNumber),sedboutsTime,sedboutsNumber,(sedboutsTime./sedboutsNumber),sedBoutLength50,alpha,SDalpha,GINI,Median_bout,Per_time_above_median,per_time_in_long_bouts,totcounts,(totcounts./wearTime));
        
        %store for averaging later
        if isweekend
            wedt(end+1,:) = [sleepTime wearTime sedTime lightTime modTime vigTime mvTime mvpaboutsTime mvpaboutsNumber (mvpaboutsTime./mvpaboutsNumber) sedboutsTime sedboutsNumber (sedboutsTime./sedboutsNumber) sedBoutLength50 totcounts avgcounts];
        else
            wdt(end+1,:) = [sleepTime wearTime sedTime lightTime modTime vigTime mvTime mvpaboutsTime mvpaboutsNumber (mvpaboutsTime./mvpaboutsNumber) sedboutsTime sedboutsNumber (sedboutsTime./sedboutsNumber) sedBoutLength50 totcounts avgcounts];
        end
        
    end
    
end

alldays = [wdt;wedt];

fprintf(fid,'\n');
fprintf(fid,'\n');

%print averages
fprintf(fid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n',...
    'week day sleepTime','week day wearTime','week day sedTime','week day lightTime','week day modTime','week day vigTime','week day mvTime','week day mvpaBoutsTime','week day mvpaBoutsNumber','week day avg mvpaBoutsLength','week day sedBoutsTime','week day sedBoutsNumber','week day avg sedBoutsLength','week day 50% sedentary time bout length','week day totCounts','week day avgCounts',...
    'weekend day sleepTime','weekend day wearTime','weekend day sedTime','weekend day lightTime','weekend day modTime','weekend day vigTime','weekend day mvTime','weekend day mvpaBoutsTime','weekend day mvpaBoutsNumber','weekend day avg mvpaBoutsLength','weekend day sedBoutsTime','weekend day sedBoutsNumber','weekend day avg sedBoutsLength','weekend day 50% sedentary time bout length','weekend day totCounts','weekend day avgCounts',...
    'all days sleepTime','all days wearTime','all days sedTime','all days lightTime','all days modTime','all days vigTime','all days mvTime','all days mvpaBoutsTime','all days mvpaBoutsNumber','all days avg mvpaBoutsLength','all days sedBoutsTime','all days sedBoutsNumber','all days avg sedBoutsLength','all days 50% sedentary time bout length','all days totCounts','all days avgCounts');

fprintf(fid,'%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f\n',...
    nanmean(wdt,1),nanmean(wedt,1),nanmean(alldays,1));

fprintf(fid,'\n');
fprintf(fid,'\n');

%summary header
fprintf(fid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n','file ID','valid file','valid weekdays','valid weekend days','total valid days','min valid weekdays for valid file','min valid weekend days for valid file','non wear window size (min)','light threshold (counts)','moderate threshold (counts)','vigorous threshold (counts)','MVPA bout window size (min)','MVPA bout % above','sedentary bout window size (min)','sedentary bout % above','min wear for valid day (min)','max non wear for valid day (min)');
fprintf(fid,'%s,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u\n',contents{get(handles.FilesList,'Value')},(vwd>=3 && vwed >=1),vwd,vwed,vwd+vwed,3,1,round(str2double(get(handles.nonwearThreshold,'String'))),round(str2double(get(handles.lightThreshold,'String'))),round(str2double(get(handles.moderateThreshold,'String'))),round(str2double(get(handles.vigorousThreshold,'String'))),round(str2double(get(handles.MVPADur,'String'))),round(str2double(get(handles.MVPAPercent,'String'))),round(str2double(get(handles.sedDur,'String'))),round(str2double(get(handles.sedPercent,'String'))),round(str2double(get(handles.wearTimeValid,'String'))),round(str2double(get(handles.nwearTimeValid,'String'))));

fclose(fid);

%save udata with events
res = rmfield(udata,'impData');
save(fullfile(matPath,fnMat),'res');

%save figure
hf = figure('units','normalized','outerposition',[0 0 1 1],'color','white');
ho = get(handles.mainFig,'children');
ho(strcmp(get(ho,'type'),'uicontrol')) = [];
copyobj(ho,hf);
export_fig(fullfile(figPath,fnFig));
close(hf);

end