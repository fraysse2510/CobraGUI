function writeSumFile(udata)

pn = uigetdir(udata.path,'Select Folder');
if pn == 0, return, end

rfol = pn;
fc = dir(pn);
for id = 1:size(fc,1)
    if strcmp(fc(id).name,'csv') && fc(id).isdir
        rfol = fullfile(pn,fc(id).name);
        break;
    end
end

pn = rfol;

%open file to write
wfid = fopen(fullfile(pn,'RESULTS_ALL_SUBJECTS.csv'),'w');

%print header
fprintf(wfid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n',...
    'file ID','valid File','valid week days','valid weekend days',...
    'week day sleepTime','week day sleepTime24','week day sleep consistency','week day sleep midpoint','week day sleep efficiency','week day bedtime','week day getuptime','week day wearTime','week day sedTime','week day lightTime','week day modTime','week day vigTime','week day mvTime','week day mvpaBoutsTime','week day mvpaBoutsNumber','week day avg mvpaBoutsLength','week day average counts during MVPA','week day sedBoutsTime','week day sedBoutsNumber','week day avg sedBoutsLength','week day W50% sedentary','week day W50% MVPA','week day T50% MVPA','week day sedentary alpha','week day MVPA alpha','week day totCounts','week day avgCounts','week day totCounts with sleep','week day avgCounts with sleep',...
    'weekend or holidays sleepTime','weekend or holidays sleepTime24','weekend or holidays sleep consistency','weekend or holidays sleep midpoint','weekend or holidays sleep efficiency','weekend or holidays bedtime','weekend or holidays getuptime','weekend or holidays wearTime','weekend or holidays sedTime','weekend or holidays lightTime','weekend or holidays modTime','weekend or holidays vigTime','weekend or holidays mvTime','weekend or holidays mvpaBoutsTime','weekend or holidays mvpaBoutsNumber','weekend or holidays avg mvpaBoutsLength','weekend or holidays average counts during MVPA','weekend or holidays sedBoutsTime','weekend or holidays sedBoutsNumber','weekend or holidays avg sedBoutsLength','weekend or holidays W50% sedentary','weekend or holidays W50% MVPA','weekend or holidays T50% MVPA','weekend or holidays sedentary alpha','weekend or holidays MVPA alpha','weekend or holidays totCounts','weekend or holidays avgCounts','weekend or holidays totCounts with sleep','weekend or holidays avgCounts with sleep',...
    'all days sleepTime','all days sleepTime24','all days sleep consistency','all days sleep midpoint','all days sleep efficiency','all days bedtime','all days getuptime','all days wearTime','all days sedTime','all days lightTime','all days modTime','all days vigTime','all days mvTime','all days mvpaBoutsTime','all days mvpaBoutsNumber','all days avg mvpaBoutsLength','all days average counts during MVPA','all days sedBoutsTime','all days sedBoutsNumber','all days avg sedBoutsLength','all days W50% sedentary','all days W50% MVPA','all days T50% MVPA', 'all days sedentary alpha','all days MVPA alpha','all days totCounts','all days avgCounts','all days totCounts with sleep','all days avgCounts with sleep',...
    '11_all days sleepTime','11_all days sleepTime24','11_all days sleep consistency','11_all days sleep midpoint','11_all days sleep efficiency','11_all days bedtime','11_all days getuptime','11_all days wearTime','11_all days sedTime','11_all days lightTime','11_all days modTime','11_all days vigTime','11_all days mvTime','11_all days mvpaBoutsTime','11_all days mvpaBoutsNumber','11_all days avg mvpaBoutsLength','11_all days average counts during MVPA','11_all days sedBoutsTime','11_all days sedBoutsNumber','11_all days avg sedBoutsLength','11_all days W50% sedentary','11_all days W50% MVPA','11_all days T50% MVPA','11_all days sedentary alpha','11_all days MVPA alpha','11_all days totCounts','11_all days avgCounts','11_all days totCounts with sleep','11_all days avgCounts with sleep',...
    '52_all days sleepTime','52_all days sleepTime24','52_all days sleep consistency','52_all days sleep midpoint','52_all days sleep efficiency','52_all days bedtime','52_all days getuptime','52_all days wearTime','52_all days sedTime','52_all days lightTime','52_all days modTime','52_all days vigTime','52_all days mvTime','52_all days mvpaBoutsTime','52_all days mvpaBoutsNumber','52_all days avg mvpaBoutsLength','52_all days average counts during MVPA','52_all days sedBoutsTime','52_all days sedBoutsNumber','52_all days avg sedBoutsLength','52_all days W50% sedentary','52_all days W50% MVPA','52_all days T50%','52_all days sedentary alpha','52_all days MVPA alpha','52_all days totCounts','52_all days avgCounts','52_all days totCounts with sleep','52_all days avgCounts with sleep',...
    'start recording date');

% fprintf(wfid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n',...
%     'file ID','valid File','valid week days','valid weekend days','week day sleepTime','week day wearTime','week day sedTime','week day lightTime','week day modTime','week day vigTime','week day mvTime','week day mvpaBoutsTime','week day mvpaBoutsNumber','week day avg mvpaBoutsLength','week day sedBoutsTime','week day sedBoutsNumber','week day avg sedBoutsLength','week day 50% sedentary time bout length','week day totCounts','week day avgCounts',...
%     'weekend day sleepTime','weekend day wearTime','weekend day sedTime','weekend day lightTime','weekend day modTime','weekend day vigTime','weekend day mvTime','weekend day mvpaBoutsTime','weekend day mvpaBoutsNumber','weekend day sedBoutsTime','weekend day sedBoutsNumber','weekend day 50% sedentary time bout length','weekend day totCounts',...
%     'all days sleepTime','all days wearTime','all days sedTime','all days lightTime','all days modTime','all days vigTime','all days mvTime','all days mvpaBoutsTime','all days mvpaBoutsNumber','all days sedBoutsTime','all days sedBoutsNumber','all days 50% sedentary time bout length','all days totCounts');

%get files to process
fList = dir(pn); fList([fList.isdir]) = []; %fList = fList(3:end);

procFile = 0;
for ifile = 1:size(fList,1)
    if size(fList(ifile).name,2)>11 && strcmp(fList(ifile).name(end-11:end),'_RESULTS.csv')
        
        fid = fopen(fullfile(pn,fList(ifile).name),'r');
        
        
        ll=fgetl(fid);
        
        while size(ll,2) < 18 || ~strcmp(ll(1:18),'week day sleepTime')
            ll=fgetl(fid);
        end
        
        vals=fgetl(fid);
        
        while size(ll,2) < 7 || ~strcmp(ll(1:7),'file ID')
            ll=fgetl(fid);
        end
        
        fileID = fgetl(fid); cin = strfind(fileID,','); fileID = fileID(1:cin(4));%fileID = strsplit(fileID,','); fileID = fileID{1};
        
        fprintf(wfid,[fileID vals '\n']);
        
        
        fclose(fid);
        
        procFile = procFile+1;
    end
end
fclose(wfid);

msgbox(['Done! processed ' num2str(procFile) ' files.']);