function [impData, tmpaa] = importXls_activPal(path,fname)
% Import 'Events" CSV ActivPal file and parse it
%   impData = cell array
%   day_no      date            time        activityType
%   [1]         [11/05/2004]    [0.5289]    [328]

fid = fopen(fullfile(path,fname));
tt=fscanf(fid,'%[^\n]',1);
fclose(fid);

%% Initialize variables.
delimiter = ',';
startRow = 2;
endRow = inf;
formatSpec = '%f%f%f%f%f%f%f%*s%*s%[^\n\r]';
%% Open the text file.
fileID = fopen(fullfile(path,fname),'r');

%% Read columns of data according to format string.
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);

%% Close the text file.
fclose(fileID);

%% Create output variable
% dataArray = cellfun(@(x) num2cell(x), dataArray, 'UniformOutput', false);
impData = [dataArray{1:end-1}];

%% Clear temporary variables
clearvars filename delimiter startRow formatSpec fileID dataArray ans;

%% clear first line if nothing (sometimes 1st line is rubbish data)
if all(impData(1,2:7)==0)
    impData(1,:)=[];
end
if all(impData(end,2:7)==0)
    impData(end,:)=[];
end

% %% parse date
% rd = impData(:,1);
% %convert Excel date format to Matlab
% rd=excelDateToMatlab(rd);
% %date
% td = cellstr(datestr(rd,'dd/mm/yyyy'));
% %time
% tt = rd-floor(rd); %as array

%% create epoch vector (0.1s epoch)

stime = impData(1,1);
etime = impData(end,1)+impData(end,3)/(3600*24);

nEpochs = (etime-stime)*3600*24*10 +1;

dates =excelDateToMatlab(linspace(stime,etime,nEpochs)');

%% find midnights
tt=dates-floor(dates);
di = find(abs(diff(tt))>0.5); di = di+1; % di = days index

dn=[]; dn=zeros(size(dates,1),1);
id = 0;
while id < size(di,1)
    dn(di(id+1):end)=id+1;
    id = id+1;
end
% dn=num2cell(dn');

% dn=[]; dn=zeros(size(dates,1),1);
% for id = 1:size(di,1)-1
%     dn(di(id):di(id+1)-1) = id;
% end
% dn(di(id+1):end)=id+1;

%% prepare activities array
actArray = nan(size(dates,1),4);
actArray(:,1) = dates;
actArray(:,2) = dn;

%% fill activities
sdate = 1;
for il = 1:size(impData,1)
    %activity
    actArray(sdate:sdate+10*impData(il,3)-1,3) = impData(il,4);
    %cumulative step count
    actArray(sdate:sdate+10*impData(il,3)-1,4) = impData(il,5);
    sdate = sdate+10*impData(il,3);
end

actArray(end,:) = [];

%% prepare display data array - collapse into 60s epochs

%if 1st day starts at 23:30 or later, discard the 1st day
tmpd = actArray(:,1)-floor(actArray(:,1));
if tmpd(1,1)>0.979167
    cre = 1;
    while tmpd(cre)>=0.979167
        cre = cre+1;
    end
    actArray(1:cre-1,:) = [];
end


%remove 1st incomplete minute
xx = (actArray(1:600,1)-floor(actArray(1:600,1)))*1440;
xxInd = find(xx-floor(xx)<0.002); xxInd = xxInd(1);
actArray(1:xxInd-1,:) = [];

% remove last incomplete minute
actArray(end-rem(length(actArray),600)+1:end,:)=[];

%reshape
tmpaa = permute(reshape(actArray.', 4,600,[]),[2 1 3]);

%get majority activity for each 1-min epoch
tt=num2cell(squeeze(mode(tmpaa(:,3,:))).*1500+500);

%get date
ttdate = cellstr(datestr(tmpaa(1,1,:),'dd/mm/yyyy'));

%get time (datenum)
tttime = num2cell(squeeze(tmpaa(1,1,:)));
% tttime = num2cell(squeeze(tmpaa(1,1,:)-floor(tmpaa(1,1,:))));

%day number
dn = num2cell(squeeze(tmpaa(1,2,:)));
%filler for other vars to match geneactiv etc
filldata = num2cell(zeros(size(tt,1),6));

impData = [dn ttdate tttime tt filldata];
end
