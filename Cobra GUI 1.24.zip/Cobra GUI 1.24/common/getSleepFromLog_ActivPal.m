function udata = getSleepFromLog(udata,handles);

%reads the loaded sleep times from a sleep log file (filled manually by
%participants) and creates sleep events for the GUI
%31/07/2015 F Fraysse for UniSA

if isfield(udata.events,'son')
    udata.events = rmfield(udata.events,'son');
end
if isfield(udata.events,'soff')
    udata.events = rmfield(udata.events,'soff');
end
if isfield(udata.events,'sleep')
    udata.events = rmfield(udata.events,'sleep');
end

if isfield(udata.events,'nwon')
    udata.events = rmfield(udata.events,'nwon');
end
if isfield(udata.events,'nwoff')
    udata.events = rmfield(udata.events,'nwoff');
end
if isfield(udata.events,'nonwear')
    udata.events = rmfield(udata.events,'nonwear');
end


son = []; soff = []; nwon = []; nwoff = [];

% get participant ID
fList = get(handles.FilesList,'string');
fName = fList{get(handles.FilesList,'value')};
fName = fName(1:9);
%remove file extension
% tmt = strsplit(fName,'.'); fName = tmt{1};

%remove file extension in sleep log file names
fns = cellfun(@(x) strsplit(x,'.'), udata.logInfo.sleepLog.part,'UniformOutput',false);
for ic = 1:size(fns,1)
    fns{ic} = fns{ic}(1);
end
fns=[fns{:}]';

%get participant index
pnum = find(strcmpi(fns,fName));

%do nothing if no log for this participant
if isempty(pnum), return; end

stimes = squeeze(udata.logInfo.sleepLog.times(pnum,:,:))'; stimes = floor(stimes.*1000000); stimes(stimes==0 | stimes==1000000 )=695;  stimes(stimes>1000000) = stimes(stimes>1000000)-1000000;
tt = ceil((udata.time-floor(udata.time))*1000000); %tt(tt==999999) = 1000000;

kon = 1; koff = 1;
maxDays = size(udata.events.day,1);
%get epoch numbers for get up (soff)
for iDay = 1:min(size(stimes,1),maxDays)
    if ~isnan(stimes(iDay,1))
        et = find(abs(tt - stimes(iDay,1))<=2);
        %HERE GO TO BED TIME CAN BE NEXT DAY!!! (eg day 1 at 3am = day2)
        %for get up time we assume it's always on the same day (nth day)
        if iDay<maxDays
            soff(koff) = et(et>=udata.events.day(iDay) & et<udata.events.day(iDay+1));
            koff = koff+1;
        else
            soff(koff) = et(et>=udata.events.day(iDay));
            koff = koff+1;
        end
    end
    if ~isnan(stimes(iDay,2))
        et = find(abs(tt - stimes(iDay,2))<=2);
        %HERE GO TO BED TIME CAN BE NEXT DAY!!! (eg day 1 at 3am = day2)
        %for go to bed time we assume if go to bed time is between noon and
        %midnight it's the same day - after midnight it is the following
        %day
        if stimes(iDay,2)>500000
            if iDay<maxDays
                son(kon) = et(et>=udata.events.day(iDay) & et<udata.events.day(iDay+1));
                kon = kon+1;
            else
                son(kon) = et(et>=udata.events.day(iDay));
                kon = kon+1;
            end
        else %bed after 12am
            if iDay+1<maxDays
                son(kon) = et(et>=udata.events.day(iDay+1) & et<udata.events.day(iDay+2));
                kon = kon+1;
                %             else %if last sleep and after 12am = out of range, don't record
                %                 son(kon) = et(et>=udata.events.day(iDay+1));
                %                 kon = kon+1;
            end
        end
        
    end
end

%%
%------------------------------------------------------------------
% naps
% stimes = flipdim(permute(squeeze(udata.logInfo.napsLog.times(pnum,:,:,:)),[3 1 2]),2); 
stimes = permute(reshape(squeeze(udata.logInfo.napsLog.times(pnum,:,:,:)),[2 3 12]),[3 1 2]);
stimes = flipdim(stimes,2);
stimes = floor(stimes.*1000000); stimes(stimes==0 | stimes==1000000 )=695;  stimes(stimes>1000000) = stimes(stimes>1000000)-1000000;


for iDay = 1:min(size(stimes,1),maxDays)    
    for iNap = 1:3
        if ~isnan(stimes(iDay,1,iNap))
            et = find(abs(tt - stimes(iDay,1,iNap))<=2);
            %HERE GO TO BED TIME CAN BE NEXT DAY!!! (eg day 1 at 3am = day2)
            %for get up time we assume it's always on the same day (nth day)
            if iDay<maxDays
                soff(koff) = et(et>=udata.events.day(iDay) & et<udata.events.day(iDay+1));
                koff = koff+1;
            else
                soff(koff) = et(et>=udata.events.day(iDay));
                koff = koff+1;
            end
        end
        if ~isnan(stimes(iDay,2,iNap))
            et = find(abs(tt - stimes(iDay,2,iNap))<=2);
            %HERE GO TO BED TIME CAN BE NEXT DAY!!! (eg day 1 at 3am = day2)
            %for go to bed time we assume if go to bed time is between noon and
            %midnight it's the same day - after midnight it is the following
            %day
            %             if stimes(iDay,2,iNap)>500000
            if iDay<maxDays
                son(kon) = et(et>=udata.events.day(iDay) & et<udata.events.day(iDay+1));
                kon = kon+1;
            else
                son(kon) = et(et>=udata.events.day(iDay));
                kon = kon+1;
            end
            %             else %bed after 12am
            %                 if iDay+1<maxDays
            %                     son(kon) = et(et>=udata.events.day(iDay+1) & et<udata.events.day(iDay+2));
            %                     kon = kon+1;
            %             else %if last sleep and after 12am = out of range, don't record
            %                 son(kon) = et(et>=udata.events.day(iDay+1));
            %                 kon = kon+1;
            %                 end
            %             end
            
        end
    end % nap 1-2-3
end %day

%%
%------------------------------------------------------------------
% non wear 

kon = 1; koff = 1; indexon = []; indexoff = [];

stimes = permute(reshape(squeeze(udata.logInfo.nonWearLog.times(pnum,:,:,:)),[2 3 12]),[3 1 2]);
stimes = flipdim(stimes,2);
stimes = floor(stimes.*1000000); stimes(stimes==0 | stimes==1000000 )=695;  stimes(stimes>1000000) = stimes(stimes>1000000)-1000000;


for iDay = 1:min(size(stimes,1),maxDays)
    for iNW = 1:3
        if ~isnan(stimes(iDay,1,iNW))
            et = find(abs(tt - stimes(iDay,1,iNW))<=2);
            %HERE GO TO BED TIME CAN BE NEXT DAY!!! (eg day 1 at 3am = day2)
            %for get up time we assume it's always on the same day (nth day)
            if iDay<maxDays
                nwoff(koff) = et(et>=udata.events.day(iDay) & et<udata.events.day(iDay+1));
                indexoff(koff) = (iDay-1)*3+iNW;
                koff = koff+1;
            else
                nwoff(koff) = et(et>=udata.events.day(iDay));
                indexoff(koff) = (iDay-1)*3+iNW;
                koff = koff+1;
            end
        end
        if ~isnan(stimes(iDay,2,iNW))
            et = find(abs(tt - stimes(iDay,2,iNW))<=2);
            %HERE GO TO BED TIME CAN BE NEXT DAY!!! (eg day 1 at 3am = day2)
            %for go to bed time we assume if go to bed time is between noon and
            %midnight it's the same day - after midnight it is the following
            %day
            %             if stimes(iDay,2,iNW)>500000
            if iDay<maxDays
                nwon(kon) = et(et>=udata.events.day(iDay) & et<udata.events.day(iDay+1));
                indexon(kon) = (iDay-1)*3+iNW;
                kon = kon+1;
            else
                nwon(kon) = et(et>=udata.events.day(iDay));
                indexon(kon) = (iDay-1)*3+iNW;
                kon = kon+1;
            end
            %             else %bed after 12am
            %                 if iDay+1<maxDays
            %                     nwon(kon) = et(et>=udata.events.day(iDay+1) & et<udata.events.day(iDay+2));
            %                     kon = kon+1;
            %             else %if last sleep and after 12am = out of range, don't record
            %                 nwon(kon) = et(et>=udata.events.day(iDay+1));
            %                 kon = kon+1;
            %                 end
            %             end
            
        end
    end % nap 1-2-3
end %day

%------------------------------------------------------------------

%draw green/red lines according to events
axLims = cell2mat(get(udata.sa,'xlim'));
iiline = 1;
for ion = 1:size(son,2)
    iiax = find(axLims(:,1)<=son(ion) & axLims(:,2)>=son(ion) & axLims(:,1)~=0 & axLims(:,2)~=1);
    axes(udata.sa(iiax));
    ylims = get(gca,'ylim');
    udata.sl(iiline) = line([son(ion) son(ion)],ylims,'color','green');
    iiline = iiline+1;
end

for ioff = 1:size(soff,2)
    iiax = find(axLims(:,1)<=soff(ioff) & axLims(:,2)>=soff(ioff));
    axes(udata.sa(iiax));
    ylims = get(gca,'ylim');
    udata.sl(iiline) = line([soff(ioff) soff(ioff)],ylims,'color','red');
    iiline = iiline+1;
end

udata.events.son = son;
udata.events.soff = soff;
udata.events.sind = 1+ size(udata.events.son,2)+size(udata.events.soff,2);

if ~isempty(son) && ~isempty(soff)
    udata = createSleepFromEvents(udata,udata.events.son,udata.events.soff);
end

%draw blue/yellow lines according to events
axLims = cell2mat(get(udata.sa,'xlim'));
iiline = 1;
for ion = 1:size(nwon,2)
    iiax = find(axLims(:,1)<=nwon(ion) & axLims(:,2)>=nwon(ion) & axLims(:,1)~=0 & axLims(:,2)~=1);
    axes(udata.sa(iiax));
    ylims = get(gca,'ylim');
    udata.nwl(end+1) = line([nwon(ion) nwon(ion)],ylims,'color',[1 1 0]);
    iiline = iiline+1;
    %also write reason if there is one
%     if ~strcmp(udata.logInfo.nonWearLog.descSport(pnum,indexon(ion)),'')
%         udata.nwt(end+1) = text(nwon(ion)+5,ylims(2)*0.95,udata.logInfo.nonWearLog.descSport(pnum,indexon(ion)));
%     elseif ~strcmp(udata.logInfo.nonWearLog.descOther(pnum,indexon(ion)),'')
%         udata.nwt(end+1) = text(nwon(ion)+5,ylims(2)*0.95,udata.logInfo.nonWearLog.descOther(pnum,indexon(ion)));
    if ~strcmp(udata.logInfo.nonWearLog.reason(pnum,indexon(ion)),'')
        udata.nwt(end+1) = text(nwon(ion)+5,ylims(2)*0.95,udata.logInfo.nonWearLog.reason(pnum,indexon(ion)));
    end
end

for ioff = 1:size(nwoff,2)
    iiax = find(axLims(:,1)<=nwoff(ioff) & axLims(:,2)>=nwoff(ioff));
    axes(udata.sa(iiax));
    ylims = get(gca,'ylim');
    udata.nwl(end+1) = line([nwoff(ioff) nwoff(ioff)],ylims,'color','blue');
    iiline = iiline+1;
end

udata.events.nwon = nwon;
udata.events.nwoff = nwoff;

if ~isempty(nwon) && ~isempty(nwoff)
    udata = createNonWearFromEvents(udata,udata.events.nwon,udata.events.nwoff);
end
