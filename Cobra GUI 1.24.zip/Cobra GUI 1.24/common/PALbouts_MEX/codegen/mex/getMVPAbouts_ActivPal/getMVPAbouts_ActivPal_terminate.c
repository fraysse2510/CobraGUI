/*
 * getMVPAbouts_ActivPal_terminate.c
 *
 * Code generation for function 'getMVPAbouts_ActivPal_terminate'
 *
 * C source code generated on: Sat Dec 19 16:12:38 2015
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "getMVPAbouts_ActivPal.h"
#include "getMVPAbouts_ActivPal_terminate.h"

/* Function Definitions */
void getMVPAbouts_ActivPal_atexit(void)
{
  emlrtCreateRootTLS(&emlrtRootTLSGlobal, &emlrtContextGlobal, NULL, 1);
  emlrtEnterRtStackR2012b(emlrtRootTLSGlobal);
  emlrtLeaveRtStackR2012b(emlrtRootTLSGlobal);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

void getMVPAbouts_ActivPal_terminate(void)
{
  emlrtLeaveRtStackR2012b(emlrtRootTLSGlobal);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

/* End of code generation (getMVPAbouts_ActivPal_terminate.c) */
