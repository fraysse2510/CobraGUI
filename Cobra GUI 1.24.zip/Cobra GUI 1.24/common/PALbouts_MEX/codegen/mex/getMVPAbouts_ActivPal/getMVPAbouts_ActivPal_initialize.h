/*
 * getMVPAbouts_ActivPal_initialize.h
 *
 * Code generation for function 'getMVPAbouts_ActivPal_initialize'
 *
 * C source code generated on: Sat Dec 19 16:12:38 2015
 *
 */

#ifndef __GETMVPABOUTS_ACTIVPAL_INITIALIZE_H__
#define __GETMVPABOUTS_ACTIVPAL_INITIALIZE_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "getMVPAbouts_ActivPal_types.h"

/* Function Declarations */
extern void getMVPAbouts_ActivPal_initialize(emlrtContext *aContext);
#endif
/* End of code generation (getMVPAbouts_ActivPal_initialize.h) */
