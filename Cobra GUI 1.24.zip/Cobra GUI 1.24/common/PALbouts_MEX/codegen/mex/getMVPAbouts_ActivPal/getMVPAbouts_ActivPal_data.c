/*
 * getMVPAbouts_ActivPal_data.c
 *
 * Code generation for function 'getMVPAbouts_ActivPal_data'
 *
 * C source code generated on: Sat Dec 19 16:12:38 2015
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "getMVPAbouts_ActivPal.h"
#include "getMVPAbouts_ActivPal_data.h"

/* Variable Definitions */
const volatile char_T *emlrtBreakCheckR2012bFlagVar;
emlrtRSInfo l_emlrtRSI = { 65, "find",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/elmat/find.m" };

emlrtMCInfo c_emlrtMCI = { 65, 1, "find",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/elmat/find.m" };

/* End of code generation (getMVPAbouts_ActivPal_data.c) */
