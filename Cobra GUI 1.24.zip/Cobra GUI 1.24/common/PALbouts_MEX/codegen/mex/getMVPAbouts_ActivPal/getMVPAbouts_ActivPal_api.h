/*
 * getMVPAbouts_ActivPal_api.h
 *
 * Code generation for function 'getMVPAbouts_ActivPal_api'
 *
 * C source code generated on: Sat Dec 19 16:12:38 2015
 *
 */

#ifndef __GETMVPABOUTS_ACTIVPAL_API_H__
#define __GETMVPABOUTS_ACTIVPAL_API_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "getMVPAbouts_ActivPal_types.h"

/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);
extern void getMVPAbouts_ActivPal_api(const mxArray *prhs[4], const mxArray *plhs[1]);
#endif
/* End of code generation (getMVPAbouts_ActivPal_api.h) */
