/*
 * getMVPAbouts_ActivPal.c
 *
 * Code generation for function 'getMVPAbouts_ActivPal'
 *
 * C source code generated on: Sat Dec 19 16:12:38 2015
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "getMVPAbouts_ActivPal.h"
#include "getMVPAbouts_ActivPal_emxutil.h"
#include "getMVPAbouts_ActivPal_data.h"

/* Variable Definitions */
static emlrtRSInfo emlrtRSI = { 7, "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m" };

static emlrtRSInfo b_emlrtRSI = { 15, "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m" };

static emlrtRSInfo c_emlrtRSI = { 20, "cumsum",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/datafun/cumsum.m" };

static emlrtRSInfo d_emlrtRSI = { 37, "cumsum",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/datafun/cumsum.m" };

static emlrtRSInfo e_emlrtRSI = { 35, "cumsum",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/datafun/cumsum.m" };

static emlrtRSInfo f_emlrtRSI = { 32, "cumsum",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/datafun/cumsum.m" };

static emlrtRSInfo g_emlrtRSI = { 91, "eml_matrix_vstride",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/eml/eml_matrix_vstride.m"
};

static emlrtRSInfo h_emlrtRSI = { 20, "eml_size_prod",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/eml/eml_size_prod.m" };

static emlrtRSInfo i_emlrtRSI = { 12, "eml_int_forloop_overflow_check",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m"
};

static emlrtRSInfo j_emlrtRSI = { 51, "eml_int_forloop_overflow_check",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m"
};

static emlrtRSInfo k_emlrtRSI = { 37, "find",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/elmat/find.m" };

static emlrtRSInfo m_emlrtRSI = { 168, "find",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/elmat/find.m" };

static emlrtMCInfo emlrtMCI = { 52, 9, "eml_int_forloop_overflow_check",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m"
};

static emlrtMCInfo b_emlrtMCI = { 51, 15, "eml_int_forloop_overflow_check",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m"
};

static emlrtMCInfo d_emlrtMCI = { 168, 9, "find",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/elmat/find.m" };

static emlrtRTEInfo emlrtRTEI = { 1, 20, "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m" };

static emlrtRTEInfo c_emlrtRTEI = { 127, 5, "find",
  "E:/Program Files/MATLAB 2013a/toolbox/eml/lib/matlab/elmat/find.m" };

static emlrtRTEInfo d_emlrtRTEI = { 7, 1, "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m" };

static emlrtRTEInfo e_emlrtRTEI = { 8, 1, "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m" };

static emlrtRTEInfo f_emlrtRTEI = { 16, 1, "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m" };

static emlrtBCInfo emlrtBCI = { -1, -1, 20, 5, "mvbouts",
  "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m", 0 };

static emlrtBCInfo b_emlrtBCI = { -1, -1, 20, 23, "c", "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m", 0 };

static emlrtBCInfo c_emlrtBCI = { -1, -1, 20, 15, "c", "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m", 0 };

static emlrtECInfo emlrtECI = { -1, 18, 1, "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m" };

static emlrtECInfo b_emlrtECI = { -1, 17, 1, "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m" };

static emlrtBCInfo d_emlrtBCI = { -1, -1, 13, 1, "mvbouts",
  "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m", 0 };

static emlrtBCInfo e_emlrtBCI = { -1, -1, 13, 14, "ctt", "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m", 0 };

static emlrtECInfo c_emlrtECI = { -1, 12, 11, "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m" };

static emlrtBCInfo f_emlrtBCI = { -1, -1, 12, 11, "mvbouts",
  "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m", 0 };

static emlrtBCInfo g_emlrtBCI = { -1, -1, 11, 1, "mvbouts",
  "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m", 0 };

static emlrtECInfo d_emlrtECI = { -1, 9, 6, "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m" };

static emlrtDCInfo emlrtDCI = { 8, 13, "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m", 1 };

static emlrtDCInfo b_emlrtDCI = { 8, 13, "getMVPAbouts_ActivPal",
  "E:/MATLAB/COBRA code/Cobra GUI/getMVPAbouts_ActivPal.m", 4 };

/* Function Declarations */
static void check_forloop_overflow_error(void);
static void error(const mxArray *b, emlrtMCInfo *location);
static const mxArray *message(const mxArray *b, const mxArray *c, emlrtMCInfo
  *location);

/* Function Definitions */
static void check_forloop_overflow_error(void)
{
  const mxArray *y;
  static const int32_T iv0[2] = { 1, 34 };

  const mxArray *m0;
  char_T cv0[34];
  int32_T i;
  static const char_T cv1[34] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o',
    'l', 'b', 'o', 'x', ':', 'i', 'n', 't', '_', 'f', 'o', 'r', 'l', 'o', 'o',
    'p', '_', 'o', 'v', 'e', 'r', 'f', 'l', 'o', 'w' };

  const mxArray *b_y;
  static const int32_T iv1[2] = { 1, 23 };

  char_T cv2[23];
  static const char_T cv3[23] = { 'c', 'o', 'd', 'e', 'r', '.', 'i', 'n', 't',
    'e', 'r', 'n', 'a', 'l', '.', 'i', 'n', 'd', 'e', 'x', 'I', 'n', 't' };

  emlrtPushRtStackR2012b(&j_emlrtRSI, emlrtRootTLSGlobal);
  y = NULL;
  m0 = mxCreateCharArray(2, iv0);
  for (i = 0; i < 34; i++) {
    cv0[i] = cv1[i];
  }

  emlrtInitCharArrayR2013a(emlrtRootTLSGlobal, 34, m0, cv0);
  emlrtAssign(&y, m0);
  b_y = NULL;
  m0 = mxCreateCharArray(2, iv1);
  for (i = 0; i < 23; i++) {
    cv2[i] = cv3[i];
  }

  emlrtInitCharArrayR2013a(emlrtRootTLSGlobal, 23, m0, cv2);
  emlrtAssign(&b_y, m0);
  error(message(y, b_y, &emlrtMCI), &b_emlrtMCI);
  emlrtPopRtStackR2012b(&j_emlrtRSI, emlrtRootTLSGlobal);
}

static void error(const mxArray *b, emlrtMCInfo *location)
{
  const mxArray *pArray;
  pArray = b;
  emlrtCallMATLABR2012b(emlrtRootTLSGlobal, 0, NULL, 1, &pArray, "error", TRUE,
                        location);
}

static const mxArray *message(const mxArray *b, const mxArray *c, emlrtMCInfo
  *location)
{
  const mxArray *pArrays[2];
  const mxArray *m2;
  pArrays[0] = b;
  pArrays[1] = c;
  return emlrtCallMATLABR2012b(emlrtRootTLSGlobal, 1, &m2, 2, pArrays, "message",
    TRUE, location);
}

void getMVPAbouts_ActivPal(const emxArray_boolean_T *stepRaw, emxArray_boolean_T
  *mvbouts, real_T mvw, real_T mvCrit)
{
  int32_T dim;
  emxArray_real_T *ctt;
  int32_T vlen;
  int32_T ixstart;
  int32_T vstride;
  int32_T k;
  boolean_T b0;
  int32_T idx;
  real_T xlast;
  emxArray_real_T *ctto;
  emxArray_real_T *r1;
  emxArray_int32_T *r2;
  emxArray_int32_T *r3;
  emxArray_int32_T *r4;
  emxArray_boolean_T *b_mvbouts;
  emxArray_int32_T *ii;
  boolean_T exitg1;
  boolean_T guard1 = FALSE;
  const mxArray *y;
  const mxArray *m3;
  emxArray_int32_T *b_ii;
  emxArray_real_T *c;
  int32_T c_ii[1];
  emxArray_real_T *b_c;
  int32_T d_ii[1];
  emxArray_real_T *c_c;
  int32_T d_c[1];
  emxArray_int32_T *r5;
  emxArray_int32_T *r6;
  emlrtHeapReferenceStackEnterFcnR2012b(emlrtRootTLSGlobal);

  /* replaced by MEX file */
  emlrtPushRtStackR2012b(&emlrtRSI, emlrtRootTLSGlobal);
  dim = 2;
  if (stepRaw->size[0] != 1) {
    dim = 1;
  }

  emxInit_real_T(&ctt, 1, &d_emlrtRTEI, TRUE);
  emlrtPushRtStackR2012b(&c_emlrtRSI, emlrtRootTLSGlobal);
  vlen = ctt->size[0];
  ctt->size[0] = stepRaw->size[0];
  emxEnsureCapacity((emxArray__common *)ctt, vlen, (int32_T)sizeof(real_T),
                    &emlrtRTEI);
  ixstart = stepRaw->size[0];
  for (vlen = 0; vlen < ixstart; vlen++) {
    ctt->data[vlen] = stepRaw->data[vlen];
  }

  if (dim <= 1) {
    vlen = ctt->size[0];
  } else {
    vlen = 1;
  }

  if ((!(ctt->size[0] == 0)) && (vlen > 1)) {
    emlrtPushRtStackR2012b(&f_emlrtRSI, emlrtRootTLSGlobal);
    emlrtPushRtStackR2012b(&g_emlrtRSI, emlrtRootTLSGlobal);
    vstride = 1;
    emlrtPushRtStackR2012b(&h_emlrtRSI, emlrtRootTLSGlobal);
    emlrtPopRtStackR2012b(&h_emlrtRSI, emlrtRootTLSGlobal);
    k = 1;
    while (k <= dim - 1) {
      vstride *= ctt->size[0];
      k = 2;
    }

    emlrtPopRtStackR2012b(&g_emlrtRSI, emlrtRootTLSGlobal);
    emlrtPopRtStackR2012b(&f_emlrtRSI, emlrtRootTLSGlobal);
    emlrtPushRtStackR2012b(&e_emlrtRSI, emlrtRootTLSGlobal);
    emlrtPopRtStackR2012b(&e_emlrtRSI, emlrtRootTLSGlobal);
    ixstart = -1;
    emlrtPushRtStackR2012b(&d_emlrtRSI, emlrtRootTLSGlobal);
    if (1 > vstride) {
      b0 = FALSE;
    } else {
      b0 = (vstride > 2147483646);
    }

    if (b0) {
      emlrtPushRtStackR2012b(&i_emlrtRSI, emlrtRootTLSGlobal);
      check_forloop_overflow_error();
      emlrtPopRtStackR2012b(&i_emlrtRSI, emlrtRootTLSGlobal);
    }

    emlrtPopRtStackR2012b(&d_emlrtRSI, emlrtRootTLSGlobal);
    for (idx = 1; idx <= vstride; idx++) {
      ixstart++;
      dim = ixstart;
      xlast = ctt->data[ixstart];
      for (k = 0; k <= vlen - 2; k++) {
        dim += vstride;
        xlast += ctt->data[dim];
        ctt->data[dim] = xlast;
      }
    }
  }

  emxInit_real_T(&ctto, 1, &e_emlrtRTEI, TRUE);
  emlrtPopRtStackR2012b(&c_emlrtRSI, emlrtRootTLSGlobal);
  emlrtPopRtStackR2012b(&emlrtRSI, emlrtRootTLSGlobal);
  vlen = ctto->size[0];
  xlast = emlrtNonNegativeCheckFastR2012b(mvw, &b_emlrtDCI, emlrtRootTLSGlobal);
  ctto->size[0] = (int32_T)emlrtIntegerCheckFastR2012b(xlast, &emlrtDCI,
    emlrtRootTLSGlobal) + ctt->size[0];
  emxEnsureCapacity((emxArray__common *)ctto, vlen, (int32_T)sizeof(real_T),
                    &emlrtRTEI);
  xlast = emlrtNonNegativeCheckFastR2012b(mvw, &b_emlrtDCI, emlrtRootTLSGlobal);
  ixstart = (int32_T)emlrtIntegerCheckFastR2012b(xlast, &emlrtDCI,
    emlrtRootTLSGlobal);
  for (vlen = 0; vlen < ixstart; vlen++) {
    ctto->data[vlen] = 0.0;
  }

  ixstart = ctt->size[0];
  for (vlen = 0; vlen < ixstart; vlen++) {
    xlast = emlrtNonNegativeCheckFastR2012b(mvw, &b_emlrtDCI, emlrtRootTLSGlobal);
    ctto->data[vlen + (int32_T)emlrtIntegerCheckFastR2012b(xlast, &emlrtDCI,
      emlrtRootTLSGlobal)] = ctt->data[vlen];
  }

  emxInit_real_T(&r1, 1, &emlrtRTEI, TRUE);
  vlen = r1->size[0];
  r1->size[0] = ctt->size[0] + (int32_T)mvw;
  emxEnsureCapacity((emxArray__common *)r1, vlen, (int32_T)sizeof(real_T),
                    &emlrtRTEI);
  ixstart = ctt->size[0];
  for (vlen = 0; vlen < ixstart; vlen++) {
    r1->data[vlen] = ctt->data[vlen];
  }

  ixstart = (int32_T)mvw;
  for (vlen = 0; vlen < ixstart; vlen++) {
    r1->data[vlen + ctt->size[0]] = 0.0;
  }

  vlen = r1->size[0];
  dim = ctto->size[0];
  emlrtSizeEqCheck1DFastR2012b(vlen, dim, &d_emlrtECI, emlrtRootTLSGlobal);
  vlen = mvbouts->size[0];
  mvbouts->size[0] = r1->size[0];
  emxEnsureCapacity((emxArray__common *)mvbouts, vlen, (int32_T)sizeof(boolean_T),
                    &emlrtRTEI);
  ixstart = r1->size[0];
  for (vlen = 0; vlen < ixstart; vlen++) {
    mvbouts->data[vlen] = (r1->data[vlen] - ctto->data[vlen] >= mvCrit);
  }

  emxFree_real_T(&r1);
  emxFree_real_T(&ctto);
  xlast = ((real_T)mvbouts->size[0] - mvw) + 2.0;
  if (xlast > mvbouts->size[0]) {
    vlen = 1;
    dim = 0;
  } else {
    vlen = mvbouts->size[0];
    dim = (int32_T)xlast;
    vlen = emlrtDynamicBoundsCheckFastR2012b(dim, 1, vlen, &g_emlrtBCI,
      emlrtRootTLSGlobal);
    dim = mvbouts->size[0];
    ixstart = mvbouts->size[0];
    dim = emlrtDynamicBoundsCheckFastR2012b(ixstart, 1, dim, &g_emlrtBCI,
      emlrtRootTLSGlobal);
  }

  b_emxInit_int32_T(&r2, 1, &emlrtRTEI, TRUE);
  ixstart = r2->size[0];
  r2->size[0] = (dim - vlen) + 1;
  emxEnsureCapacity((emxArray__common *)r2, ixstart, (int32_T)sizeof(int32_T),
                    &emlrtRTEI);
  ixstart = dim - vlen;
  for (dim = 0; dim <= ixstart; dim++) {
    r2->data[dim] = vlen + dim;
  }

  emxInit_int32_T(&r3, 2, &emlrtRTEI, TRUE);
  vlen = r3->size[0] * r3->size[1];
  r3->size[0] = 1;
  emxEnsureCapacity((emxArray__common *)r3, vlen, (int32_T)sizeof(int32_T),
                    &emlrtRTEI);
  ixstart = r2->size[0];
  vlen = r3->size[0] * r3->size[1];
  r3->size[1] = ixstart;
  emxEnsureCapacity((emxArray__common *)r3, vlen, (int32_T)sizeof(int32_T),
                    &emlrtRTEI);
  ixstart = r2->size[0];
  for (vlen = 0; vlen < ixstart; vlen++) {
    r3->data[vlen] = r2->data[vlen] - 1;
  }

  emxFree_int32_T(&r2);
  emxInit_int32_T(&r4, 2, &emlrtRTEI, TRUE);
  vlen = r4->size[0] * r4->size[1];
  r4->size[0] = 1;
  r4->size[1] = r3->size[1];
  emxEnsureCapacity((emxArray__common *)r4, vlen, (int32_T)sizeof(int32_T),
                    &emlrtRTEI);
  ixstart = r3->size[1];
  for (vlen = 0; vlen < ixstart; vlen++) {
    r4->data[r4->size[0] * vlen] = r3->data[r3->size[0] * vlen];
  }

  ixstart = r3->size[1];
  for (vlen = 0; vlen < ixstart; vlen++) {
    mvbouts->data[r4->data[r4->size[0] * vlen]] = FALSE;
  }

  emxFree_int32_T(&r4);
  if (mvw > (real_T)mvbouts->size[0] - 1.0) {
    vlen = 0;
    dim = 0;
  } else {
    vlen = mvbouts->size[0];
    dim = (int32_T)mvw;
    vlen = emlrtDynamicBoundsCheckFastR2012b(dim, 1, vlen, &f_emlrtBCI,
      emlrtRootTLSGlobal) - 1;
    dim = mvbouts->size[0];
    ixstart = (int32_T)((real_T)mvbouts->size[0] - 1.0);
    dim = emlrtDynamicBoundsCheckFastR2012b(ixstart, 1, dim, &f_emlrtBCI,
      emlrtRootTLSGlobal);
  }

  emxInit_boolean_T(&b_mvbouts, 1, &emlrtRTEI, TRUE);
  emlrtVectorVectorIndexCheckR2012b(mvbouts->size[0], 1, 1, dim - vlen,
    &c_emlrtECI, emlrtRootTLSGlobal);
  ixstart = b_mvbouts->size[0];
  b_mvbouts->size[0] = dim - vlen;
  emxEnsureCapacity((emxArray__common *)b_mvbouts, ixstart, (int32_T)sizeof
                    (boolean_T), &emlrtRTEI);
  ixstart = dim - vlen;
  for (dim = 0; dim < ixstart; dim++) {
    b_mvbouts->data[dim] = mvbouts->data[vlen + dim];
  }

  vlen = mvbouts->size[0];
  mvbouts->size[0] = b_mvbouts->size[0];
  emxEnsureCapacity((emxArray__common *)mvbouts, vlen, (int32_T)sizeof(boolean_T),
                    &emlrtRTEI);
  ixstart = b_mvbouts->size[0];
  for (vlen = 0; vlen < ixstart; vlen++) {
    mvbouts->data[vlen] = b_mvbouts->data[vlen];
  }

  emxFree_boolean_T(&b_mvbouts);
  b_emxInit_int32_T(&ii, 1, &emlrtRTEI, TRUE);
  vlen = mvbouts->size[0];
  emlrtDynamicBoundsCheckFastR2012b(1, 1, vlen, &d_emlrtBCI, emlrtRootTLSGlobal);
  vlen = ctt->size[0];
  emlrtDynamicBoundsCheckFastR2012b(5, 1, vlen, &e_emlrtBCI, emlrtRootTLSGlobal);
  mvbouts->data[0] = (ctt->data[4] >= mvCrit);
  emlrtPushRtStackR2012b(&b_emlrtRSI, emlrtRootTLSGlobal);
  emlrtPushRtStackR2012b(&k_emlrtRSI, emlrtRootTLSGlobal);
  idx = 0;
  vlen = ii->size[0];
  ii->size[0] = mvbouts->size[0];
  emxEnsureCapacity((emxArray__common *)ii, vlen, (int32_T)sizeof(int32_T),
                    &c_emlrtRTEI);
  if (mvbouts->size[0] == 0) {
    vlen = ii->size[0];
    ii->size[0] = 0;
    emxEnsureCapacity((emxArray__common *)ii, vlen, (int32_T)sizeof(int32_T),
                      &emlrtRTEI);
  } else {
    ixstart = 1;
    dim = 1;
    exitg1 = FALSE;
    while ((exitg1 == FALSE) && (dim <= 1)) {
      guard1 = FALSE;
      if (mvbouts->data[ixstart - 1]) {
        idx++;
        ii->data[idx - 1] = ixstart;
        if (idx >= mvbouts->size[0]) {
          exitg1 = TRUE;
        } else {
          guard1 = TRUE;
        }
      } else {
        guard1 = TRUE;
      }

      if (guard1 == TRUE) {
        ixstart++;
        if (ixstart > mvbouts->size[0]) {
          ixstart = 1;
          dim = 2;
        }
      }
    }

    if (idx <= mvbouts->size[0]) {
    } else {
      emlrtPushRtStackR2012b(&m_emlrtRSI, emlrtRootTLSGlobal);
      y = NULL;
      m3 = mxCreateString("Assertion failed.");
      emlrtAssign(&y, m3);
      error(y, &d_emlrtMCI);
      emlrtPopRtStackR2012b(&m_emlrtRSI, emlrtRootTLSGlobal);
    }

    if (mvbouts->size[0] == 1) {
      if (idx == 0) {
        vlen = ii->size[0];
        ii->size[0] = 0;
        emxEnsureCapacity((emxArray__common *)ii, vlen, (int32_T)sizeof(int32_T),
                          &emlrtRTEI);
      }
    } else {
      if (1 > idx) {
        ixstart = 0;
      } else {
        ixstart = idx;
      }

      b_emxInit_int32_T(&b_ii, 1, &emlrtRTEI, TRUE);
      vlen = b_ii->size[0];
      b_ii->size[0] = ixstart;
      emxEnsureCapacity((emxArray__common *)b_ii, vlen, (int32_T)sizeof(int32_T),
                        &emlrtRTEI);
      for (vlen = 0; vlen < ixstart; vlen++) {
        b_ii->data[vlen] = ii->data[vlen];
      }

      vlen = ii->size[0];
      ii->size[0] = b_ii->size[0];
      emxEnsureCapacity((emxArray__common *)ii, vlen, (int32_T)sizeof(int32_T),
                        &emlrtRTEI);
      ixstart = b_ii->size[0];
      for (vlen = 0; vlen < ixstart; vlen++) {
        ii->data[vlen] = b_ii->data[vlen];
      }

      emxFree_int32_T(&b_ii);
    }
  }

  emlrtPopRtStackR2012b(&k_emlrtRSI, emlrtRootTLSGlobal);
  vlen = ctt->size[0];
  ctt->size[0] = ii->size[0];
  emxEnsureCapacity((emxArray__common *)ctt, vlen, (int32_T)sizeof(real_T),
                    &emlrtRTEI);
  ixstart = ii->size[0];
  for (vlen = 0; vlen < ixstart; vlen++) {
    ctt->data[vlen] = ii->data[vlen];
  }

  b_emxInit_real_T(&c, 2, &f_emlrtRTEI, TRUE);
  emlrtPopRtStackR2012b(&b_emlrtRSI, emlrtRootTLSGlobal);
  ixstart = ctt->size[0];
  vlen = c->size[0] * c->size[1];
  c->size[0] = ixstart;
  c->size[1] = 2;
  emxEnsureCapacity((emxArray__common *)c, vlen, (int32_T)sizeof(real_T),
                    &emlrtRTEI);
  ixstart = ctt->size[0] << 1;
  for (vlen = 0; vlen < ixstart; vlen++) {
    c->data[vlen] = 0.0;
  }

  ixstart = ctt->size[0];
  vlen = ii->size[0];
  ii->size[0] = ixstart;
  emxEnsureCapacity((emxArray__common *)ii, vlen, (int32_T)sizeof(int32_T),
                    &emlrtRTEI);
  for (vlen = 0; vlen < ixstart; vlen++) {
    ii->data[vlen] = vlen;
  }

  c_ii[0] = ii->size[0];
  emlrtSubAssignSizeCheckR2012b(c_ii, 1, *(int32_T (*)[1])ctt->size, 1,
    &b_emlrtECI, emlrtRootTLSGlobal);
  ixstart = ctt->size[0];
  for (vlen = 0; vlen < ixstart; vlen++) {
    c->data[ii->data[vlen]] = ctt->data[vlen];
  }

  emxFree_real_T(&ctt);
  ixstart = c->size[0];
  vlen = ii->size[0];
  ii->size[0] = ixstart;
  emxEnsureCapacity((emxArray__common *)ii, vlen, (int32_T)sizeof(int32_T),
                    &emlrtRTEI);
  for (vlen = 0; vlen < ixstart; vlen++) {
    ii->data[vlen] = vlen;
  }

  emxInit_real_T(&b_c, 1, &emlrtRTEI, TRUE);
  d_ii[0] = ii->size[0];
  ixstart = c->size[0];
  vlen = b_c->size[0];
  b_c->size[0] = ixstart;
  emxEnsureCapacity((emxArray__common *)b_c, vlen, (int32_T)sizeof(real_T),
                    &emlrtRTEI);
  for (vlen = 0; vlen < ixstart; vlen++) {
    b_c->data[vlen] = c->data[vlen];
  }

  emxInit_real_T(&c_c, 1, &emlrtRTEI, TRUE);
  d_c[0] = b_c->size[0];
  emlrtSubAssignSizeCheckR2012b(d_ii, 1, d_c, 1, &emlrtECI, emlrtRootTLSGlobal);
  ixstart = c->size[0];
  vlen = c_c->size[0];
  c_c->size[0] = ixstart;
  emxEnsureCapacity((emxArray__common *)c_c, vlen, (int32_T)sizeof(real_T),
                    &emlrtRTEI);
  emxFree_real_T(&b_c);
  for (vlen = 0; vlen < ixstart; vlen++) {
    c_c->data[vlen] = (c->data[vlen] + mvw) - 1.0;
  }

  ixstart = c_c->size[0];
  for (vlen = 0; vlen < ixstart; vlen++) {
    c->data[ii->data[vlen] + c->size[0]] = c_c->data[vlen];
  }

  emxFree_real_T(&c_c);
  emxFree_int32_T(&ii);
  idx = 0;
  b_emxInit_int32_T(&r5, 1, &emlrtRTEI, TRUE);
  emxInit_int32_T(&r6, 2, &emlrtRTEI, TRUE);
  while (idx <= c->size[0] - 1) {
    vlen = c->size[0];
    dim = (int32_T)(1.0 + (real_T)idx);
    emlrtDynamicBoundsCheckFastR2012b(dim, 1, vlen, &c_emlrtBCI,
      emlrtRootTLSGlobal);
    vlen = c->size[0];
    dim = (int32_T)(1.0 + (real_T)idx);
    emlrtDynamicBoundsCheckFastR2012b(dim, 1, vlen, &b_emlrtBCI,
      emlrtRootTLSGlobal);
    if (c->data[idx] > c->data[idx + c->size[0]]) {
      vlen = 1;
      dim = 0;
    } else {
      vlen = mvbouts->size[0];
      dim = (int32_T)c->data[idx];
      vlen = emlrtDynamicBoundsCheckFastR2012b(dim, 1, vlen, &emlrtBCI,
        emlrtRootTLSGlobal);
      dim = mvbouts->size[0];
      ixstart = (int32_T)c->data[idx + c->size[0]];
      dim = emlrtDynamicBoundsCheckFastR2012b(ixstart, 1, dim, &emlrtBCI,
        emlrtRootTLSGlobal);
    }

    ixstart = r5->size[0];
    r5->size[0] = (dim - vlen) + 1;
    emxEnsureCapacity((emxArray__common *)r5, ixstart, (int32_T)sizeof(int32_T),
                      &emlrtRTEI);
    ixstart = dim - vlen;
    for (dim = 0; dim <= ixstart; dim++) {
      r5->data[dim] = vlen + dim;
    }

    vlen = r3->size[0] * r3->size[1];
    r3->size[0] = 1;
    emxEnsureCapacity((emxArray__common *)r3, vlen, (int32_T)sizeof(int32_T),
                      &emlrtRTEI);
    ixstart = r5->size[0];
    vlen = r3->size[0] * r3->size[1];
    r3->size[1] = ixstart;
    emxEnsureCapacity((emxArray__common *)r3, vlen, (int32_T)sizeof(int32_T),
                      &emlrtRTEI);
    ixstart = r5->size[0];
    for (vlen = 0; vlen < ixstart; vlen++) {
      r3->data[vlen] = r5->data[vlen] - 1;
    }

    vlen = r6->size[0] * r6->size[1];
    r6->size[0] = 1;
    r6->size[1] = r3->size[1];
    emxEnsureCapacity((emxArray__common *)r6, vlen, (int32_T)sizeof(int32_T),
                      &emlrtRTEI);
    ixstart = r3->size[1];
    for (vlen = 0; vlen < ixstart; vlen++) {
      r6->data[r6->size[0] * vlen] = r3->data[r3->size[0] * vlen];
    }

    ixstart = r3->size[1];
    for (vlen = 0; vlen < ixstart; vlen++) {
      mvbouts->data[r6->data[r6->size[0] * vlen]] = TRUE;
    }

    idx++;
    emlrtBreakCheckFastR2012b(emlrtBreakCheckR2012bFlagVar, emlrtRootTLSGlobal);
  }

  emxFree_int32_T(&r6);
  emxFree_int32_T(&r5);
  emxFree_int32_T(&r3);
  emxFree_real_T(&c);

  /*  tic */
  /*  for ie = 1:size(stepRaw,1) - (mvw-1) */
  /*      if size(find(stepRaw(ie:ie+mvw-1)),1) >= mvCrit */
  /*          mvbouts2(ie:ie+mvw-1) = 1; */
  /*      end */
  /*  end */
  /*   */
  /*  toc */
  /*   */
  /*  any(mvbouts2~=mvbouts) */
  emlrtHeapReferenceStackLeaveFcnR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (getMVPAbouts_ActivPal.c) */
