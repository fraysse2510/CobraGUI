/*
 * rtwtypes.h
 *
 * Code generation for function 'getMVPAbouts_ActivPal'
 *
 * C source code generated on: Sat Dec 19 16:12:38 2015
 *
 */

#ifndef __RTWTYPES_H__
#define __RTWTYPES_H__
#include "tmwtypes.h"
/* 
 * TRUE/FALSE definitions
 */
#ifndef TRUE
#define TRUE (1U)
#endif 
#ifndef FALSE
#define FALSE (0U)
#endif 
#endif
/* End of code generation (rtwtypes.h) */
