/*
 * getMVPAbouts_ActivPal_initialize.c
 *
 * Code generation for function 'getMVPAbouts_ActivPal_initialize'
 *
 * C source code generated on: Sat Dec 19 16:12:38 2015
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "getMVPAbouts_ActivPal.h"
#include "getMVPAbouts_ActivPal_initialize.h"
#include "getMVPAbouts_ActivPal_data.h"

/* Function Definitions */
void getMVPAbouts_ActivPal_initialize(emlrtContext *aContext)
{
  emlrtBreakCheckR2012bFlagVar = emlrtGetBreakCheckFlagAddressR2012b();
  emlrtCreateRootTLS(&emlrtRootTLSGlobal, aContext, NULL, 1);
  emlrtClearAllocCountR2012b(emlrtRootTLSGlobal, FALSE, 0U, 0);
  emlrtEnterRtStackR2012b(emlrtRootTLSGlobal);
  emlrtFirstTimeR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (getMVPAbouts_ActivPal_initialize.c) */
