%% import raw data
tt =  importSleepLogFile('C:\Users\frayssfe\Documents\work\Experimental data\Braden\REACH\sleep_logs_baseline.xlsx');

%% delete headers
tt(1:2,:) = [];

%% get file name
pNames = tt(:,1);

tt(:,1) = [];

%% Replace non-numeric cells with NaN
R = cellfun(@(x) ~isnumeric(x) && ~islogical(x),tt); % Find non-numeric cells
tt(R) = {NaN}; % Replace non-numeric cells
tt = cell2mat(tt);
%participant x 2 x day
tt = reshape(tt,size(tt,1),2,size(tt,2)/2);