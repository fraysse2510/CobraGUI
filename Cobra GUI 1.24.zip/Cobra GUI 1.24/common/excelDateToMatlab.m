function dates = excelDateToMatlab(dates)

dates = dates + datenum(1900, 1, 1) - 2;

end

