function impData = getActigraphCSVtype(path,fname)

% Initialize variables.
% filename = 'C:\Users\frayssfe\Documents\work\Experimental data\jocelyn\jocelyn csv\new export\021T3NEO1C1111015160sec.csv';
delimiter = ',';
endRow = 11;
formatSpec = '%s%s%s%s%s%s%s%s%s%s%s%s%[^\n\r]';

% Open the  file.
fileID = fopen(fullfile(path,fname),'r');
dataArray = textscan(fileID, formatSpec, endRow, 'Delimiter', delimiter, 'ReturnOnError', false);
fclose(fileID);

hval = [dataArray{1:end-1}];
% Clear temporary variables
clearvars filename delimiter endRow formatSpec fileID dataArray ans;

%determine if dates and timestamps are in the file
ts = ~isempty(find(strcmpi(hval,'Date'))) && ~isempty(find(strcmpi(hval,'Time')));

if ~ts %no timestamps - create them
    impData = importXls_ActiGraph_noTS(path,fname,hval);
else
    impData = importXls_ActiGraph(path,fname);
end
    
