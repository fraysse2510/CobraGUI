function udata = deleteObjectOverMouse(udata,hh,xpos)

lineThresh = 12;

switch udata.isEditing
    case 1 %sleep
        %first find if there is a sleep line close
        onToDel = udata.events.son(abs(udata.events.son-xpos)<=lineThresh);
        offToDel = udata.events.soff(abs(udata.events.soff-xpos)<=lineThresh);
        if ~isempty(onToDel)
            udata.events.son(abs(udata.events.son-xpos)<=lineThresh) = [];
            %also delete line
            if size(udata.sl,2) ~= 0
            tmpxd = [udata.sl.XData]; tmpxd = tmpxd(1:2:end);
            delete(udata.sl(tmpxd==onToDel)); udata.sl(tmpxd==onToDel) = [];
            end
        elseif ~isempty(offToDel)
            udata.events.soff(abs(udata.events.soff-xpos)<=lineThresh) = [];
            %also delete line
            if size(udata.sl,2) ~= 0
            tmpxd = [udata.sl.XData]; tmpxd = tmpxd(1:2:end);
            delete(udata.sl(tmpxd==offToDel)); udata.sl(tmpxd==offToDel) = [];
            end
        end
        
    case 2 %nonwear
        %first find if there is a sleep line close
        onToDel = udata.events.nwon(abs(udata.events.nwon-xpos)<=lineThresh);
        offToDel = udata.events.nwoff(abs(udata.events.nwoff-xpos)<=lineThresh);
        if ~isempty(onToDel)
            udata.events.nwon(abs(udata.events.nwon-xpos)<=lineThresh) = [];
            %also delete line
            if size(udata.nwl,2) ~= 0
            tmpxd = [udata.nwl.XData]; tmpxd = tmpxd(1:2:end);
            delete(udata.nwl(tmpxd==onToDel)); udata.nwl(tmpxd==onToDel) = [];
            end
        elseif ~isempty(offToDel)
            udata.events.nwoff(abs(udata.events.nwoff-xpos)<=lineThresh) = [];
            %also delete line
            if size(udata.nwl,2) ~= 0
            tmpxd = [udata.nwl.XData]; tmpxd = tmpxd(1:2:end);
            delete(udata.nwl(tmpxd==offToDel)); udata.nwl(tmpxd==offToDel) = [];
            end
            %       elseif udata.events.nonwear(xpos) %if over a zone
        end
end

