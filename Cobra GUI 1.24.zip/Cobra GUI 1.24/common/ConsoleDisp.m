function ConsoleDisp(handles,text,clearPrevious)

if ischar(text)
    text = {text};
end

if ~clearPrevious
    oldTxt = get(handles.Console,'string');
    newTxt = [oldTxt; text];    
else
    newTxt = text;
end

set(handles.Console,'string',newTxt);
set(handles.Console,'value',1);
set(handles.Console,'FontName','FixedWidth');
