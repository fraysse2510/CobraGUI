function udata = getSleepFromLog(udata,handles);

%reads the loaded sleep times from a sleep log file (filled manually by
%participants) and creates sleep events for the GUI
%31/07/2015 F Fraysse for UniSA

son = []; soff = [];

if isfield(udata.events,'son')
    udata.events = rmfield(udata.events,'son');
end
if isfield(udata.events,'soff')
    udata.events = rmfield(udata.events,'soff');
end
if isfield(udata.events,'sleep')
    udata.events = rmfield(udata.events,'sleep');
end

% get participant ID
fList = get(handles.FilesList,'string');
fName = fList{get(handles.FilesList,'value')}; 

%remove file extension
tmt = strsplit(fName,'.'); fName = tmt{1};fName = fName(1:6);

%remove file extension in sleep log file names
tt = cellfun(@(x) strsplit(x,'.'), udata.sleepLog.part,'UniformOutput',false); 
for ic = 1:size(tt,1)
    tt{ic} = tt{ic}(1);
end
tt=[tt{:}]';

%get participant index
pnum = find(strcmpi(tt,fName(1:6)));

%do nothing if no log for this participant
if isempty(pnum), return; end

stimes = squeeze(udata.sleepLog.times(pnum,:,:))'; stimes = floor(stimes.*1000000); stimes(stimes==0 | stimes==1000000 )=695;  stimes(stimes>1000000) = stimes(stimes>1000000)-1000000;
tt = ceil((udata.time-floor(udata.time))*1000000); 

kon = 1; koff = 1;
maxDays = size(udata.events.day,1);
%get epoch numbers for get up (soff)
for iDay = 1:min(size(stimes,1),maxDays)
    if ~isnan(stimes(iDay,1))
        et = find(abs(tt - stimes(iDay,1))<=1);
        %dirty - some dates still aren't found - fix
        if isempty(et)
            et = find(abs(tt - stimes(iDay,1))<=2);
        end
        %HERE GO TO BED TIME CAN BE NEXT DAY!!! (eg day 1 at 3am = day2)
        %for get up time we assume it's always on the same day (nth day)
        if iDay<maxDays
            soff(koff) = et(et>=udata.events.day(iDay) & et<udata.events.day(iDay+1));
            koff = koff+1;
        else
            soff(koff) = et(et>=udata.events.day(iDay));
            koff = koff+1;
        end
    end
    if ~isnan(stimes(iDay,2))
        et = find(abs(tt - stimes(iDay,2))<=1);
        if isempty(et)
            et = find(abs(tt - stimes(iDay,2))<=2);
        end
        %HERE GO TO BED TIME CAN BE NEXT DAY!!! (eg day 1 at 3am = day2)
        %for go to bed time we assume if go to bed time is between noon and
        %midnight it's the same day - after midnight it is the following
        %day
        if stimes(iDay,2)>500000
            if iDay<maxDays
                son(kon) = et(et>=udata.events.day(iDay) & et<udata.events.day(iDay+1));
                kon = kon+1;
            else
                son(kon) = et(et>=udata.events.day(iDay));
                kon = kon+1;
            end
        else %bed after 12am
            if iDay+1<maxDays
                son(kon) = et(et>=udata.events.day(iDay+1) & et<udata.events.day(iDay+2));
                kon = kon+1;
%             else %if last sleep and after 12am = out of range, don't record
%                 son(kon) = et(et>=udata.events.day(iDay+1));
%                 kon = kon+1;
            end
        end
        
    end
end

%draw green/red lines according to events
axLims = cell2mat(get(udata.sa,'xlim'));
iiline = 1;
for ion = 1:size(son,2)
    iiax = find(axLims(:,1)<=son(ion) & axLims(:,2)>=son(ion) & axLims(:,1)~=0 & axLims(:,2)~=1);
    axes(udata.sa(iiax));
    ylims = get(gca,'ylim');
    udata.sl(iiline) = line([son(ion) son(ion)],ylims,'color','green');
    iiline = iiline+1;
end

for ioff = 1:size(soff,2)
    iiax = find(axLims(:,1)<=soff(ioff) & axLims(:,2)>=soff(ioff));
    axes(udata.sa(iiax));
    ylims = get(gca,'ylim');
    udata.sl(iiline) = line([soff(ioff) soff(ioff)],ylims,'color','red');
    iiline = iiline+1;
end

udata.events.son = son;
udata.events.soff = soff;
udata.events.sind = 1+ size(udata.events.son,2)+size(udata.events.soff,2);

udata = createSleepFromEvents(udata,udata.events.son,udata.events.soff);

