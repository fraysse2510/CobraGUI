function udata = deleteZoneFromGUI(tt,pInd,udata)

pInd = pInd(1);
%delete patch object
delete(udata.nwr(pInd)); udata.nwr(pInd) = [];
%delete lines at each end
if isfield(udata,'nwl') && size(udata.nwl,2) ~= 0
    %find line indices
    tl = [udata.nwl.XData]; tl = tl(1:2:end);
    lToDelInd = [find(tl==tt(1,pInd)) find(tl==tt(2,pInd))];
    delete(udata.nwl(lToDelInd)); udata.nwl(lToDelInd) = [];
end
%delete events
udata.events.nwon(udata.events.nwon == tt(1,pInd)) = [];
udata.events.nwoff(udata.events.nwoff == tt(2,pInd)) = [];
udata.events.nwind = size(udata.events.nwon,2) + size(udata.events.nwoff,2) +1;