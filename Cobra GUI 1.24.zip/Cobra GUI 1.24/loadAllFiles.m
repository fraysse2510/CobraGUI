function udata = loadAllFiles(udata,handles)


%gets monitor type and imports files
%0 = actiCal (cobra) 1 = actigraph
monType = getMonType(udata);
udata.monType = monType;

fList = udata.fList;
path = udata.path;

% hw = waitbar(0,sprintf('Loading %3.0f files',size(fList,1)));

switch monType
    case 0 %actical (cobra)
        disp('ActiCAL filetype detected');
        set(handles.lightThreshold,'String','100');
        set(handles.moderateThreshold,'String','1500');
        set(handles.vigorousThreshold,'String','6500');
        consoleDisp(udata,handles,'ActiCal');
        set(handles.nonWearWindowDuration,'String','0');
        %udata contains files list
        totalFiles = size(fList,1);
%         for iFile = 1:size(fList,1)
%             disp(fList(iFile).name);
%             udata.impData{iFile} = importXls_ActiCal(path,fList(iFile).name);
%             waitbar(iFile/totalFiles,hw,sprintf('Loaded %3.0f / %3.0f',iFile,totalFiles));
%         end
        
    case 1 %actiGraph
        disp('ActiGraph filetype detected');
        consoleDisp(udata,handles,'ActiGraph');
        set(handles.lightThreshold,'String','100');
        set(handles.moderateThreshold,'String','1500');
        set(handles.vigorousThreshold,'String','6500');
        set(handles.nonWearWindowDuration,'String','0');
        %udata contains files list
        totalFiles = size(fList,1);
%         for iFile = 1:size(fList,1)
%             disp(fList(iFile).name);
%             udata.impData{iFile} = getActigraphCSVtype(path,fList(iFile).name);
%             waitbar(iFile/totalFiles,hw,sprintf('Loaded %3.0f / %3.0f',iFile,totalFiles));
%         end
    case 2 %geneactiv
        disp('GeneActiv filetype detected');
        consoleDisp(udata,handles,'GeneActiv');
        set(handles.lightThreshold,'String','377');
        set(handles.moderateThreshold,'String','806');
        set(handles.vigorousThreshold,'String','2263');
        set(handles.scaleTxt,'String','2000');
        set(handles.nonWearWindowDuration,'String','25');
        %udata contains files list
        totalFiles = size(fList,1);
%         for iFile = 1:totalFiles
%             disp(fList(iFile).name);
%             udata.impData{iFile} = importXls_GeneActiv(path,fList(iFile).name);
%             waitbar(iFile/totalFiles,hw,sprintf('Loaded %3.0f / %3.0f',iFile,totalFiles));
%         end
    case 3 %activPal
        disp('ActivPAL filetype detected');
        consoleDisp(udata,handles,'ActivPAL');
        set(handles.lightThreshold,'String','501');
        set(handles.moderateThreshold,'String','2001');
        set(handles.vigorousThreshold,'String','3501');
        set(handles.nonWearWindowDuration,'String','0');
        %udata contains files list
        totalFiles = size(fList,1);
%         for iFile = 1:size(fList,1)
%             disp(fList(iFile).name);
%             [udata.impData{iFile},udata.impDataRaw{iFile}] = importXls_activPal(path,fList(iFile).name);
%             waitbar(iFile/totalFiles,hw,sprintf('Loaded %3.0f / %3.0f',iFile,totalFiles));
%         end
end
% delete(hw);
end