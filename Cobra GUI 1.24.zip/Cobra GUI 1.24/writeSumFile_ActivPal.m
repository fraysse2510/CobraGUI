function writeSumFile_ActivPal(udata)

pn = uigetdir(udata.path,'Select Folder');
if pn == 0, return, end

rfol = pn;
fc = dir(pn);
for id = 1:size(fc,1)
    if strcmp(fc(id).name,'csv') && fc(id).isdir
        rfol = fullfile(pn,fc(id).name);
        break;
    end
end

pn = rfol;

%open file to write
wfid = fopen(fullfile(pn,'RESULTS_ALL_SUBJECTS.csv'),'w');

%print header
fprintf(wfid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n',...
    'file ID','valid File','valid week days','valid weekend days',...
    'all days sitting min','all days sitting <30 min','all days sitting >30 min',...
    'all days standing min','all days stepping min','all days stepping >10 min','all days awake obs min',...
    'all days no of sitting bouts >30','all days no of sitstand trans','all days no steps',...
    'all days sleep min','all days sitstand trans per hour sitting',...
    'all days % sit','all days % sit >30min',...
    'weekday sitting min','weekday sitting <30 min','weekday sitting >30 min',...
    'weekday standing min','weekday stepping min','weekday stepping >10 min','weekday awake obs min',...
    'weekday no of sitting bouts >30','weekday no of sitstand trans','weekday no steps',...
    'weekday sleep min','weekday sitstand trans per hour sitting',...
    'weekday % sit','weekday % sit >30min',...
    'weekend day sitting min','weekend day sitting <30 min','weekend day sitting >30 min',...
    'weekend day standing min','weekend day stepping min','weekend day stepping >10 min','weekend day awake obs min',...
    'weekend day no of sitting bouts >30','weekend day no of sitstand trans','weekend day no steps',...
    'weekend day sleep min','weekend day sitstand trans per hour sitting',...
    'weekend day % sit','weekend day % sit >30min');
%get files to process
fList = dir(pn); fList([fList.isdir]) = []; %fList = fList(3:end);

procFile = 0;
for ifile = 1:size(fList,1)
    if size(fList(ifile).name,2)>11 && strcmp(fList(ifile).name(end-11:end),'_RESULTS.csv')
        
        fid = fopen(fullfile(pn,fList(ifile).name),'r');
        
        
        ll=fgetl(fid);
        
        while size(ll,2) < 18 || ~strcmp(ll(1:20),'all days sitting min')
            ll=fgetl(fid);
        end
        
        vals=fgetl(fid);
        
        while size(ll,2) < 7 || ~strcmp(ll(1:7),'file ID')
            ll=fgetl(fid);
        end
        
        fileID = fgetl(fid); cin = strfind(fileID,','); fileID = fileID(1:cin(4));%fileID = strsplit(fileID,','); fileID = fileID{1};
        
        fprintf(wfid,[fileID vals '\n']);
        
        
        fclose(fid);
        
        procFile = procFile+1;
    end
end
fclose(wfid);

msgbox(['Done! processed ' num2str(procFile) ' files.']);