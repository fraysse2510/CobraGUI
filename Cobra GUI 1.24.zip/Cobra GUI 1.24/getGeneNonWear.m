function nwi = getGeneNonWear(udata,handles)
%gets non wear for Gene epoch compressed files (based on avg of accel)

%get file no
% fnum = get(handles.FilesList,'value');
% tt = cell2mat(udata.impData{fnum}(:,5:10));

nw = udata.counts<=200 & udata.events.sleep == 0;
nwi = find(diff(nw)~=0)+1;
end