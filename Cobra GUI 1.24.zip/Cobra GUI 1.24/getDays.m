function udata = getDays(udata,handles)

%create day events
nfile = get(handles.FilesList,'value');
di = find(diff(udata.day_number));

%if one day is not 1440 epochs (apart from 1st or last) display a warning message
if ~isempty(find(diff(di)~=1440)), disp('warning - there is a short day'); end

%pad 1st and last days so they go to midnight (all days have 1440 epochs too)

if ~isempty(di)
    %% 1st day
    if di(1)~=1
        nme = 1440-di(1); %no of epochs missing
        if nme ~=0
            %pad all data values
            %date and day_number with 1st day values
            udata.day_number = [repmat(udata.day_number(1),nme,1); udata.day_number];
            udata.date = [repmat(udata.date(1),nme,1); udata.date];
            
            %epochs
            epls = udata.time(2)-udata.time(1); %datenum of epoch length HH:MM
            sep = udata.time(1) - nme*epls;     %1st epoch date
            udata.time = [[sep:epls:sep+epls*(nme-1)]'; udata.time];
            
            %pad counts with zeros (will be picked as non wear later)
            udata.counts = [zeros(nme,1); udata.counts];
            
            %             imported data
            fillMat = repmat(udata.impData(1,:),nme,1);
            fillMat(:,3) = num2cell([sep:epls:sep+epls*(nme-1)]');
            fillMat(:,4) = num2cell(zeros(size(fillMat,1),1));
            udata.impData = [fillMat; udata.impData];
            if isfield(udata,'impDataRaw')
                fillMatRaw = repmat(udata.impDataRaw(:,:,end),[1 1 nme]); fillMatRaw(:,3,:) = 0;
                udata.impDataRaw = cat(3,fillMatRaw,  udata.impDataRaw);
            end
            
            %pad midnight indexes
            di = [1; di+nme+1];
        elseif nme == 0
            %1st day index is not 1 but 1st day is full still
            %pad midnight indexes
            di = [1; di+nme+1];
            
        end
    end
    
    %% last day
    nme = di(end) + 1440 - size(udata.day_number,1) - 1 ;
    if nme ~=0
        %pad all data values
        %date and day_number with last day values
        udata.day_number(end+1:end+nme) = udata.day_number(end);
        udata.date(end+1:end+nme) = udata.date(end);
        
        %epochs
        epls = udata.time(2)-udata.time(1); %datenum of epoch length HH:MM
        sep = udata.time(end) + nme*epls;     %last epoch date
        udata.time = [udata.time; [udata.time(end)+epls:epls:sep]'];
        
        %pad counts with zeros (will be picked as non wear later)
        udata.counts(end+1:end+nme) = 0;
        
        %imported data
        fillMat = repmat(udata.impData(end,:),nme,1);
        tmpEpochs = cumsum(epls*ones(size(fillMat,1),1));
        fillMat(:,3) = num2cell(cell2mat(fillMat(:,3))+tmpEpochs);
        fillMat(:,4) = num2cell(zeros(size(fillMat,1),1));
        udata.impData(end+1:end+nme,:) = fillMat;
        if isfield(udata,'impDataRaw')
            fillMatRaw = repmat(udata.impDataRaw(:,:,end),[1 1 nme]); fillMatRaw(:,3,:) = 0;
            udata.impDataRaw(:,:,end+1:end+nme) = fillMatRaw;
        end
        
    end
end
udata.events.day = di;

end




