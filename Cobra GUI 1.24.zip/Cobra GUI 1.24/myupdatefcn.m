function output_txt = myupdatefcn(~,event_obj)
% ~            Currently not used (empty)
% event_obj    Object containing event data structure
% output_txt   Data cursor text (string or cell array 
%              of strings)

tt=get(event_obj,'Position');
disp(tt)