function impData = importXls_GeneActiv(path,fname)
%imports 60s epochs geneactiv CSV file
%   impData = cell array
%   day_no      date            time        counts      x       y       z       xsd         ysd         zsd
%   [1]         [11/05/2004]    [0.5289]    [328]       [0.526] ...

startRow = 101;
delimiter = ',';
formatSpec = '%s%s%s%s%s%s%s%s%s%s%s%s%[^\n\r]';
% formatSpec = '%s%f%f%f%s%s%s%f%f%f%f%s%[^\n\r]';
fileID = fopen(fullfile(path,fname),'r');


textscan(fileID, '%[^\n\r]', startRow-1, 'ReturnOnError', false);
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'ReturnOnError', false);
% Close the text file
fclose(fileID);

% Create output variable
impData = [dataArray{1:end-1}];
% impData = [dataArray{1} num2cell([dataArray{2:4}]) dataArray{5:7} num2cell([dataArray{8:11}]) dataArray{12}];

%% Clear temporary variables
clearvars filename delimiter startRow formatSpec fileID dataArray ans;

%parse date
rd = char(impData(:,1));
%date
% tic
td = cellstr(datestr(datenum(rd(:,1:10),'yyyy-mm-dd'),'dd/mm/yyyy'));
% toc
%time
if size(rd,2) == 23
tt = datenum(rd(:,12:end-4)); %as array
elseif size(rd,2) == 19
tt = datenum(rd(:,12:end));
end

%find midnights
%gene epochs are labeled with time at end of epoch
%find epoch length and substract from time stamps
tt = tt-(tt(2)-tt(1)); %datenum of epoch length HH:MM


% di = find(strcmp(cellstr(datestr(tt,'HH:MM:SS')),'00:00:00'));
%updated 25/09/2014 - check only for hours and minutes in case recordings
%are not at "00 seconds"
di = find(strcmp(cellstr(datestr(tt,'HH:MM')),'00:00'));

dn=[]; dn(size(impData,1)) = 0;

%changed to handle data with only 1 day
id = 0;
while id < size(di,1)
    dn(di(id+1):end)=id+1;
    id = id+1;
end
dn=num2cell(dn');

% for id = 1:size(di,1)-1
%     dn(di(id):di(id+1)-1) = id;
% end
% dn(di(id+1):end)=id+1;
% dn=num2cell(dn');
%changed to handle data with only 1 day

%newer faster
numData = real([str2doubleq(impData(:,8)) str2doubleq(impData(:,2:4)) str2doubleq(impData(:,9:11))]);
% numData = mat2cell(numData,ones(size(numData,1),1),ones(size(numData,2),1));
numData = num2cell(numData);
impData = [dn td num2cell(tt) numData];

%old slow
% tic
% impData = [dn td num2cell(tt) num2cell(str2doubleq(impData(:,8))) num2cell(str2doubleq(impData(:,2:4))) num2cell(str2doubleq(impData(:,9:11)))];
% toc

% impData = [dn td num2cell(tt) impData(:,8) impData(:,2:4) impData(:,9:11)];


if size(impData,1) > 14399
    impData = impData(1:14399,:);
end
end