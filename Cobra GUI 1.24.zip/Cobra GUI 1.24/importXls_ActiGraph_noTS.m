function impData = importXls_ActiGraph_noTS(path,fname,hval);

%get start date
[r,c] = find(strncmpi(hval,'start date',10));
sd = strsplit(hval{r,c},' ');
sd = sd(end);

%get start time
[r,c] = find(strncmpi(hval,'start time',10));
st = strsplit(hval{r,c},' ');
st = st(end);

%read data values
delimiter = ',';
startRow = 12;
formatSpec = '%f%f%f%f%f%f%f%f%f%[^\n\r]';

fileID = fopen(fullfile(path,fname),'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);
fclose(fileID);

dataArray = cellfun(@(x) num2cell(x), dataArray, 'UniformOutput', false);
impData = [dataArray{1:end-1}];
%% Clear temporary variables
clearvars filename delimiter startRow formatSpec fileID dataArray ans;

%create timestamp vector
%create a 00:00 to 23:59 vector
hours = 0:23;
mins = 0:59;
counter = 0;
tt = cell(1440,1);
for ii=1:24
    for jj=1:60
        counter=counter+1;
            tt{counter} = sprintf('%02d:%02d:00',hours(ii),mins(jj));
    end
end

tsv = tt(find(strcmp(tt,st)):end);
%date
dsv = repmat(sd,size(tsv,1),1);

dayinc = 1;
while size(tsv,1)<size(impData,1)
    tsv = [tsv;tt];
    dsv = [dsv;cellstr(repmat(datestr(addtodate(datenum(sd,'dd/mm/yyyy'),dayinc,'day'),'dd/mm/yyyy'),size(tt,1),1))];
    dayinc = dayinc+1;
end

tsv = tsv(1:size(impData,1),:);
dsv = dsv(1:size(impData,1),:);
%find midnights
di = find(strcmp(tsv,'00:00:00'));

dn=[]; dn(size(impData,1)) = 0;

for id = 1:size(di,1)-1
    dn(di(id):di(id+1)-1) = id;
end
dn(di(id+1):end)=id+1;
dn=num2cell(dn');

%compute vector magnitude
xyz = cell2mat(impData(:,1:3));
vecmag = sqrt(xyz(:,1).^2+xyz(:,2).^2+xyz(:,3).^2);

impData = [dn dsv num2cell(datenum(tsv,'HH:MM:SS')) num2cell(vecmag) num2cell(xyz)];
if size(impData,1) > 14399
    impData = impData(1:14399,:);
end

end
