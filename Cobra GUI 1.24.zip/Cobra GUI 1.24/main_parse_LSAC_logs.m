function udata = main_parse_LSAC_logs(pn,fn)



[rawT] = importSleepLogFileLSAC(fullfile(pn,fn));

udata.sleepLog.times = nan(size(rawT,1),2,8);
udata.sleepLog.part = rawT(:,1);

udata.nonWearLog.times = nan(size(rawT,1),2,12);
udata.nonWearLog.dates = cell(size(rawT,1),2,12); udata.nonWearLog.dates(:) = {''};
udata.nonWearLog.ampm = cell(size(rawT,1),2,12); udata.nonWearLog.ampm(:) = {''};
udata.nonWearLog.part = rawT(:,1);
udata.nonWearLog.isComplete = zeros(size(rawT,1),1);

udata.nonWearLog.reason = cell(size(rawT,1),12); udata.nonWearLog.reason(:) = {''};
udata.nonWearLog.descOther = cell(size(rawT,1),12); udata.nonWearLog.descOther(:) = {''};
udata.nonWearLog.descSport = cell(size(rawT,1),12); udata.nonWearLog.descSport(:) = {''};

for iPart = 1:size(rawT,1)
    
    %%
    %sleep
    for iDay = 1:8 %max number of sleep logs
        udata.sleepLog.dates(iPart,iDay) = rawT(iPart,8*(iDay-1)+25); %to later compare to 1st day of gene data
        
        %char conversion
        % wh:wm wam = wake time HH:MM AM/PM
        wh = char(rawT(iPart,8*(iDay-1)+26));
        wm = char(rawT(iPart,8*(iDay-1)+27));
        wam = char(rawT(iPart,8*(iDay-1)+28));
        
        bh = char(rawT(iPart,8*(iDay-1)+29));
        bm = char(rawT(iPart,8*(iDay-1)+30));
        bam = char(rawT(iPart,8*(iDay-1)+31));
        
        if ~isempty(wh) && isempty(wm)
            wm = '00';
        end
        if ~isempty(bh) && isempty(bm)
            bm = '00';
        end
        
        
        if ~isempty(wh) && ~isempty(wm) && ~isempty(wam)
            if strcmpi(wam,'PM') && ~strcmpi(wh,'12')
                wh = num2str(str2double(wh) + 12);
            elseif strcmpi(wam,'AM') && strcmpi(wh,'12')
                wh = '00';
            end
            udata.sleepLog.times(iPart,1,iDay) = datenum(0,0,0,str2double(wh),str2double(wm),0);
        end
        
        if ~isempty(bh) && ~isempty(bm) && ~isempty(bam)
            if strcmpi(bam,'PM') && ~strcmpi(bh,'12')
                bh = num2str(str2double(bh) + 12);
            elseif strcmpi(bam,'AM') && strcmpi(bh,'12')
                bh = '00';
            end
            udata.sleepLog.times(iPart,2,iDay) = datenum(0,0,0,str2double(bh),str2double(bm),0);
        end
        
    end %day
    
    %%
    %non wear
    for iEv = 1:12 %12 non wear events max
        
        offd = char(rawT(iPart,11*(iEv-1)+92));
        offh = char(rawT(iPart,11*(iEv-1)+93));
        offm = char(rawT(iPart,11*(iEv-1)+94));
        offam = char(rawT(iPart,11*(iEv-1)+95));
        
        ond = char(rawT(iPart,11*(iEv-1)+96));
        onh = char(rawT(iPart,11*(iEv-1)+97));
        onm = char(rawT(iPart,11*(iEv-1)+98));
        onam = char(rawT(iPart,11*(iEv-1)+99));
        
        %fill am/pm info for display later
        if ~isempty(onam)
            udata.nonWearLog.ampm(iPart,2,iEv) = {onam};
        end
        if ~isempty(offam)
            udata.nonWearLog.ampm(iPart,1,iEv) = {offam};
        end
        
        %impute data if missing (AM PM)
        %if back on am/pm missing
        if isempty(onam) && ~isempty(offam)
            if ~isempty(onh) && ~isempty(offh)
                if (str2double(onh) < str2double(offh)) && ~strcmpi(offh,'12')
                    if strcmpi(offam,'AM')
                        onam = 'PM';
                    else
                        onam = 'AM';
                    end
                else
                    if strcmpi(offam,'AM')
                        onam = 'AM';
                    else
                        onam = 'PM';
                    end
                end
                if strcmpi(onh,'12') %if on hour is 12 then am/pm will be opposite of off time
                    if strcmpi(offam,'AM')
                        onam = 'PM';
                    else
                        onam = 'AM';
                    end
                end
            end
        end %fill AM / PM
        
        %if back on date missing
        %copy date from off
        if isempty(ond) && ~isempty(offd)
            ond = offd;
        end
        
        %if there is a hour but no minutes set minutes to 0
        if isempty(onm) && ~isempty(onh)
            onm = '00';
        end
        
        if isempty(offm) && ~isempty(offh)
            offm = '00';
        end
        
        %now do proper times
        if ~isempty(offd) && ~isempty(offh) && ~isempty(offm) && ~isempty(offam)
            if strcmpi(offam,'PM') && ~strcmpi(offh,'12')
                offh = num2str(str2double(offh) + 12);
            elseif strcmpi(offam,'AM') && strcmpi(offh,'12')
                offh = '00';
            end
            udata.nonWearLog.times(iPart,1,iEv) = datenum(0,0,0,str2double(offh),str2double(offm),0);
            udata.nonWearLog.dates(iPart,1,iEv) = {offd};
        end
        
        if ~isempty(ond) && ~isempty(onh) && ~isempty(onm) && ~isempty(onam)
            if strcmpi(onam,'PM') && ~strcmpi(onh,'12')
                onh = num2str(str2double(onh) + 12);
            elseif strcmpi(onam,'AM') && strcmpi(onh,'12')
                onh = '00';
            end
            udata.nonWearLog.times(iPart,2,iEv) = datenum(0,0,0,str2double(onh),str2double(onm),0);
            udata.nonWearLog.dates(iPart,2,iEv) = {ond};
        end
        
        %comments on removal
        udata.nonWearLog.reason(iPart,iEv) = rawT(iPart,11*(iEv-1)+100);
        udata.nonWearLog.descOther(iPart,iEv) = rawT(iPart,11*(iEv-1)+101);
        udata.nonWearLog.descSport(iPart,iEv) = rawT(iPart,11*(iEv-1)+102);
        
        %if all time info is complete, event is complete
        if ~isempty(offd) && ~isempty(offh) && ~isempty(offm) && ~isempty(offam) && ~isempty(ond) && ~isempty(onh) && ~isempty(onm) && ~isempty(onam)
            udata.nonWearLog.isComplete(iPart,iEv) = 1;
        end
        %also if event is all empty mark it as "complete" so it doesnt get
        %displayed in the console
        if isempty(offd) && isempty(offh) && isempty(offm) && isempty(offam) && isempty(ond) && isempty(onh) && isempty(onm) && isempty(onam) && strcmp(udata.nonWearLog.reason(iPart,iEv),'') && strcmp(udata.nonWearLog.descOther(iPart,iEv),'') && strcmp(udata.nonWearLog.descSport(iPart,iEv),'')
            udata.nonWearLog.isComplete(iPart,iEv) = 1;
        end
        
    end %nonwear event
    
    %%
    % misc comments
    udata.nonWearLog.CommentsDaysNotRecorded(iPart) = rawT(iPart,24);
    udata.nonWearLog.CommentsRemoved(iPart) = rawT(iPart,91);
    udata.nonWearLog.CommentsRemovals13plus(iPart) = rawT(iPart,224);
    udata.nonWearLog.CommentsGeneral(iPart) = rawT(iPart,225);
    udata.nonWearLog.CommentsNotes(iPart) = rawT(iPart,227);
    
    
    
end %participant


