function udata = getSleepFromLogLSAC(udata,handles);

%reads the loaded sleep times from a sleep log file (filled manually by
%participants) and creates sleep events for the GUI - LSAC version
%07/04/2016 F Fraysse for UniSA

son = []; soff = [];

%text handles
udata.nwt = gobjects(0);

if isfield(udata.events,'son')
    udata.events = rmfield(udata.events,'son');
end
if isfield(udata.events,'soff')
    udata.events = rmfield(udata.events,'soff');
end
udata.events.sleep = udata.counts; udata.events.sleep(:) = 0;

% get participant ID
fList = get(handles.FilesList,'string');
fName = fList{get(handles.FilesList,'value')};
% fName = fName(1:9);
%remove file extension
tmt = strsplit(fName,'.'); fName = tmt{1};

%remove file extension in sleep log file names
tt = udata.logInfo.sleepLog.part;

%get participant index
pnum = find(strcmpi(tt,fName));

%do nothing if no log for this participant
if isempty(pnum), return; end

stimes = squeeze(udata.logInfo.sleepLog.times(pnum,:,:))'; stimes = floor(stimes.*1000000); stimes(stimes==0 | stimes==1000000 )=695;  stimes(stimes>1000000) = stimes(stimes>1000000)-1000000;
tt = ceil((udata.time-floor(udata.time))*1000000);

kon = 1; koff = 1;
maxDays = size(udata.events.day,1);
%get epoch numbers for get up (soff)
for iDay = 1:min(size(stimes,1),maxDays)
    if ~isnan(stimes(iDay,1))
        et = find(abs(tt - stimes(iDay,1))<=1);
        %dirty - some dates still aren't found - fix
        if isempty(et)
            et = find(abs(tt - stimes(iDay,1))<=2);
        end
        %HERE GO TO BED TIME CAN BE NEXT DAY!!! (eg day 1 at 3am = day2)
        %for get up time we assume it's always on the same day (nth day)
        
        %fix date - if day is 1-9 add a 0 at the start        
        tmpdate = udata.logInfo.sleepLog.dates(pnum,iDay);
        tmpdatesplit = strsplit(char(tmpdate),'/');
        if length(tmpdatesplit{1}) < 2
            tmpdate = cellstr(['0' char(tmpdate)]);
        end
        
        valdates = find(strcmpi(udata.date,tmpdate));
        if ~isempty(valdates)
        soff(koff) = et(ismember(et,valdates));
        koff = koff+1;
        end
    end
    if ~isnan(stimes(iDay,2))
        et = find(abs(tt - stimes(iDay,2))<=1);
        if isempty(et)
            et = find(abs(tt - stimes(iDay,2))<=2);
        end
        %HERE GO TO BED TIME CAN BE NEXT DAY!!! (eg day 1 at 3am = day2)
        %for go to bed time we assume if go to bed time is between noon and
        %midnight it's the same day - after midnight it is the following
        %day
        if stimes(iDay,2)>=500000
            valdates = find(strcmpi(udata.date,tmpdate));
            if ~isempty(valdates)
            son(kon) = et(ismember(et,valdates));
            kon = kon+1;
            end
        else %bed after 12am
            if iDay+1<maxDays
                valdates = find(strcmpi(udata.date,datestr(addtodate(datenum(tmpdate,'dd/mm/yyyy'),1,'day'),'dd/mm/yyyy')));
                if ~isempty(valdates)
                son(kon) = et(ismember(et,valdates));
                kon = kon+1;
                end
                %             else %if last sleep and after 12am = out of range, don't record
                %                 son(kon) = et(et>=udata.events.day(iDay+1));
                %                 kon = kon+1;
            end
        end
        
    end
end

%draw green/red lines according to events
axLims = cell2mat(get(udata.sa,'xlim'));
iiline = 1;
for ion = 1:size(son,2)
    iiax = find(axLims(:,1)<=son(ion) & axLims(:,2)>=son(ion) & axLims(:,1)~=0 & axLims(:,2)~=1);
    axes(udata.sa(iiax));
    ylims = get(gca,'ylim');
    udata.sl(end+1) = line([son(ion) son(ion)],ylims,'color','green');
    iiline = iiline+1;
end

for ioff = 1:size(soff,2)
    iiax = find(axLims(:,1)<=soff(ioff) & axLims(:,2)>=soff(ioff));
    axes(udata.sa(iiax));
    ylims = get(gca,'ylim');
    udata.sl(end+1) = line([soff(ioff) soff(ioff)],ylims,'color','red');
    iiline = iiline+1;
end

udata.events.son = son;
udata.events.soff = soff;
udata.events.sind = 1+ size(udata.events.son,2)+size(udata.events.soff,2);

if ~isempty(udata.events.son) || ~isempty(udata.events.soff)
    udata = createSleepFromEvents(udata,udata.events.son,udata.events.soff);
end



%% NON WEAR

nwon = []; nwoff = []; indexon = []; indexoff = [];

if isfield(udata.events,'nwon')
    udata.events = rmfield(udata.events,'nwon');
end
if isfield(udata.events,'nwoff')
    udata.events = rmfield(udata.events,'nwoff');
end
if isfield(udata.events,'nonwear')
    udata.events = rmfield(udata.events,'nonwear');
end

% get participant ID
fList = get(handles.FilesList,'string');
fName = fList{get(handles.FilesList,'value')};
% fName = fName(1:9);
%remove file extension
tmt = strsplit(fName,'.'); fName = tmt{1};

tt = udata.logInfo.nonWearLog.part;

%get participant index
pnum = find(strcmpi(tt,fName));

%do nothing if no log for this participant
if isempty(pnum), return; end

stimes = squeeze(udata.logInfo.nonWearLog.times(pnum,:,:))'; stimes = floor(stimes.*1000000); stimes(stimes==0 | stimes==1000000 )=695;  stimes(stimes>1000000) = stimes(stimes>1000000)-1000000;
tt = ceil((udata.time-floor(udata.time))*1000000);

kon = 1; koff = 1;
maxDays = size(udata.events.day,1);
%get epoch numbers for get up (nwoff)
for iDay = 1:size(stimes,1)
    if ~isnan(stimes(iDay,1))
        et = find(abs(tt - stimes(iDay,1))<=1);
        %dirty - some dates still aren't found - fix
        if isempty(et)
            et = find(abs(tt - stimes(iDay,1))<=2);
        end
        %HERE GO TO BED TIME CAN BE NEXT DAY!!! (eg day 1 at 3am = day2)
        %for get up time we assume it's always on the same day (nth day)
                
        %fix date - if day is 1-9 add a 0 at the start        
        tmpdate = udata.logInfo.nonWearLog.dates(pnum,iDay);
        tmpdatesplit = strsplit(char(tmpdate),'/');
        if length(tmpdatesplit{1}) < 2
            tmpdate = cellstr(['0' char(tmpdate)]);
        end
        
        valdates = find(strcmpi(udata.date,tmpdate));
        if ~isempty(find(ismember(et,valdates)))
            nwoff(koff) = et(ismember(et,valdates));
            indexoff(koff) = iDay;
            koff = koff+1;
        end
    end
    if ~isnan(stimes(iDay,2))
        et = find(abs(tt - stimes(iDay,2))<=1);
        if isempty(et)
            et = find(abs(tt - stimes(iDay,2))<=2);
        end
        %HERE GO TO BED TIME CAN BE NEXT DAY!!! (eg day 1 at 3am = day2)
        %for go to bed time we assume if go to bed time is between noon and
        %midnight it's the same day - after midnight it is the following
        %day
        valdates = find(strcmpi(udata.date,tmpdate));
        if ~isempty(find(ismember(et,valdates)))
            nwon(kon) = et(ismember(et,valdates));
            indexon(kon) = iDay;
            kon = kon+1;            
        end
        
    end
end

%inverse nwon and nwoff
tempnwvar = nwon;
nwon = nwoff;
nwoff = tempnwvar;

tempnwvar = indexon;
indexon = indexoff;
indexoff = tempnwvar;

if isfield(udata,'nwl')
    udata.nwl = gobjects(0);
end

%draw blue/yellow lines according to events
axLims = cell2mat(get(udata.sa,'xlim'));
iiline = 1;
for ion = 1:size(nwon,2)
    iiax = find(axLims(:,1)<=nwon(ion) & axLims(:,2)>=nwon(ion) & axLims(:,1)~=0 & axLims(:,2)~=1);
    axes(udata.sa(iiax));
    ylims = get(gca,'ylim');
    udata.nwl(end+1) = line([nwon(ion) nwon(ion)],ylims,'color',[1 1 0]);
    iiline = iiline+1;
    %also write reason if there is one
%     if ~strcmp(udata.logInfo.nonWearLog.descSport(pnum,indexon(ion)),'')
%         udata.nwt(end+1) = text(nwon(ion)+5,ylims(2)*0.95,udata.logInfo.nonWearLog.descSport(pnum,indexon(ion)));
%     elseif ~strcmp(udata.logInfo.nonWearLog.descOther(pnum,indexon(ion)),'')
%         udata.nwt(end+1) = text(nwon(ion)+5,ylims(2)*0.95,udata.logInfo.nonWearLog.descOther(pnum,indexon(ion)));
    if ~strcmp(udata.logInfo.nonWearLog.reason(pnum,indexon(ion)),'')
        udata.nwt(end+1) = text(nwon(ion)+5,ylims(2)*0.95,udata.logInfo.nonWearLog.reason(pnum,indexon(ion)));
    end
end

for ioff = 1:size(nwoff,2)
    iiax = find(axLims(:,1)<=nwoff(ioff) & axLims(:,2)>=nwoff(ioff));
    axes(udata.sa(iiax));
    ylims = get(gca,'ylim');
    udata.nwl(end+1) = line([nwoff(ioff) nwoff(ioff)],ylims,'color','blue');
    iiline = iiline+1;
end

udata.events.nwon = nwon;
udata.events.nwoff = nwoff;
udata.events.nwind = 1+ size(udata.events.nwon,2)+size(udata.events.nwoff,2);

if ~isempty(udata.events.nwon) || ~isempty(udata.events.nwoff)
    udata = createNonWearFromEvents(udata,udata.events.nwon,udata.events.nwoff);
end

%% display comments
% textToDisplay = [{sprintf(['Details of days not recorded: ' char(udata.logInfo.nonWearLog.CommentsDaysNotRecorded(pnum))])};...
%     {sprintf(['Removals comments:            ' char(udata.logInfo.nonWearLog.CommentsRemoved(pnum))])};...
%     {sprintf(['Removals 13+ comments:        ' char(udata.logInfo.nonWearLog.CommentsRemovals13plus(pnum))])};...
%     {sprintf(['General comments:             ' char(udata.logInfo.nonWearLog.CommentsGeneral(pnum))])};...
%     {sprintf(['Notes:                        ' char(udata.logInfo.nonWearLog.CommentsNotes(pnum))])};...
%     {sprintf('------------------------------')};...
%     {sprintf('Incomplete removal events:    ')}];
% 
% 
% for iEv = 1:size(udata.logInfo.nonWearLog.isComplete,2)
%     if ~udata.logInfo.nonWearLog.isComplete(pnum,iEv)
%         strInfo = [{'XX/XX/XXXX'} {'XX:XX'} {'XX'} {'XX/XX/XXXX'} {'XX:XX'} {'XX'} {''} {''} {''}];
%         %fill in whats available
%         %date
%         if ~strcmp(udata.logInfo.nonWearLog.dates(pnum,1,iEv),'')            
%             strInfo(1) = {datestr(datenum(char(udata.logInfo.nonWearLog.dates(pnum,1,iEv)),'yyyy-mm-dd'),'dd/mm/yyyy')};
%         end
%         if ~strcmp(udata.logInfo.nonWearLog.dates(pnum,2,iEv),'')
%             strInfo(4) = {datestr(datenum(char(udata.logInfo.nonWearLog.dates(pnum,2,iEv)),'yyyy-mm-dd'),'dd/mm/yyyy')};
%         end
%         %hour and minutes
%         if ~isnan(udata.logInfo.nonWearLog.times(pnum,1,iEv))
%             tt = udata.logInfo.nonWearLog.times(pnum,1,iEv); if tt > 0.5, tt = tt - 0.5; end            
%             strInfo(2) = {datestr(tt,'HH:MM')};              
%         end
%         if ~isnan(udata.logInfo.nonWearLog.times(pnum,2,iEv))
%             tt = udata.logInfo.nonWearLog.times(pnum,2,iEv); if tt > 0.5, tt = tt - 0.5; end            
%             strInfo(5) = {datestr(tt,'HH:MM')};              
%         end
%         %AM/PM
%         if ~strcmp(udata.logInfo.nonWearLog.ampm(pnum,1,iEv),'')
%             strInfo(3) = udata.logInfo.nonWearLog.ampm(pnum,1,iEv);
%         end 
%         if ~strcmp(udata.logInfo.nonWearLog.ampm(pnum,2,iEv),'')
%             strInfo(6) = udata.logInfo.nonWearLog.ampm(pnum,2,iEv);
%         end
%         %reasons
%         if ~strcmp(udata.logInfo.nonWearLog.reason(pnum,iEv),'')
%             strInfo(7) = udata.logInfo.nonWearLog.reason(pnum,iEv);
%         end
%         if ~strcmp(udata.logInfo.nonWearLog.descOther(pnum,iEv),'')
%             strInfo(8) = udata.logInfo.nonWearLog.descOther(pnum,iEv);
%         end
%         if ~strcmp(udata.logInfo.nonWearLog.descSport(pnum,iEv),'')
%             strInfo(9) = udata.logInfo.nonWearLog.descSport(pnum,iEv);
%         end
%         
%         
%         strToPrint = {sprintf(['Removal ' num2str(iEv) ': ' char(strInfo(1)) ' ' char(strInfo(2)) ' ' char(strInfo(3)) ' -- ' char(strInfo(4)) ' ' char(strInfo(5)) ' ' char(strInfo(6)) ' - Reason: ' char(strInfo(7)) ' - ' char(strInfo(8)) ' - ' char(strInfo(9))])};
%         textToDisplay = [textToDisplay;strToPrint];
%     end
% end
% 
% 
% 
% ConsoleDisp(handles,textToDisplay,1);

