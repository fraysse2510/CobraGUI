function udata = loadFromList(udata,handles)

% fnum = get(handles.FilesList,'value');
tt = udata.impData;

%clear previous file vars
if isfield(udata,'day_number'), udata = rmfield(udata,'day_number'); end,
if isfield(udata,'date'), udata = rmfield(udata,'date'); end,
if isfield(udata,'time'), udata = rmfield(udata,'time'); end,
if isfield(udata,'counts'), udata = rmfield(udata,'counts'); end,
if isfield(udata,'events'), udata = rmfield(udata,'events'); end,


% if isfield(udata,'sl'), udata = rmfield(udata,'sl'); end,
% if isfield(udata,'sr'), udata = rmfield(udata,'sr'); end,
% if isfield(udata,'nwl'), udata = rmfield(udata,'nwl'); end,
% if isfield(udata,'nwr'), udata = rmfield(udata,'nwr'); end,
% if isfield(udata,'nwt'), udata = rmfield(udata,'nwt'); end,

udata.sl = gobjects(0);
udata.sr = gobjects(0);
udata.nwl = gobjects(0);
udata.nwr = gobjects(0);
udata.nwt = gobjects(0);


%trim data at the end if it has nans (shorter files)
itrim = size(tt(:,1),1);
for itt = 1:size(tt,2)
    if ~isempty(find(strcmpi(tt(:,itt),'nan')))
        itrim = min([itrim min(find(strcmpi(tt(:,itt),'nan')))-1]);
    end
    if ~isempty(find(strcmpi(tt(:,itt),'')))
        itrim = min([itrim min(find(strcmpi(tt(:,itt),'')))-1]);
    end
end

udata.day_number = cell2mat(tt(1:itrim,1));

udata.date = tt(1:itrim,2);
udata.time = cell2mat(tt(1:itrim,3));

%CHANGE BELOW TO itrim,4 for VM - itrim,5 for Y axis only
udata.counts = cell2mat(tt(1:itrim,4));
%CHANGE ABOVE TO itrim,4

disp(['Found ' num2str(itrim) ' valid epochs']);

udata = getDays(udata,handles);

udata.events.sleep = udata.counts; udata.events.sleep(:) = 0;
udata.events.sedentary = udata.counts; udata.events.sedentary(:) = 0;
udata.events.light = udata.counts; udata.events.light(:) = 0;
udata.events.moderate = udata.counts; udata.events.moderate(:) = 0;
udata.events.vigorous = udata.counts; udata.events.vigorous(:) = 0;
udata.events.MVPA = udata.counts; udata.events.MVPA(:) = 0;
udata.events.nonwear = udata.counts; udata.events.nonwear(:) = 0;

%these are holding the zones redefined from non wear - we need to save them
%for when we reload from matfile

udata.events.forced.sedentary = udata.counts; udata.events.forced.sedentary(:) = 0;
udata.events.forced.light = udata.counts; udata.events.forced.light(:) = 0;
udata.events.forced.moderate = udata.counts; udata.events.forced.moderate(:) = 0;
udata.events.forced.vigorous = udata.counts; udata.events.forced.vigorous(:) = 0;

end
