function udata = createNonWearFromEvents(udata,nwon,nwoff)

% create sleep masks from start and end events (0 = not sleeping)
sm = nan(size(udata.counts));
nwon(nwon<1) = []; nwoff(nwoff<1) = [];
nwon = sort(nwon');
if ~isempty(nwon)
    nwon(:,2) = 1;
end
nwoff=sort(nwoff');
if ~isempty(nwoff)
    nwoff(:,2) = 0;
end

if isempty(nwon) && isempty(nwoff)
    if isfield(udata,'nwl')
        delete(udata.nwl(:)); udata.nwl = gobjects(0);
    end
    if isfield(udata,'nwr')
        delete(udata.nwr(:)); udata.nwr = gobjects(0);
    end
    if isfield(udata,'nwt')
        delete(udata.nwt(:)); udata.nwt = gobjects(0);
    end
    if isfield(udata.events,'nwon')
        udata.events.nwon = [];
    end
    if isfield(udata.events,'nwoff')
        udata.events.nwoff = [];
    end
    udata.events.nwind = 1;
    udata.events.nonwear = zeros(size(udata.counts,1),size(udata.counts,2));
    return,
end

st = [nwon; nwoff]; st = sortrows(st,1);
indexToDel = [];
indexToDelLine = [];

if st(1,2) %starts with a start sleep
    sm(1:st(1,1)-1) = 0;
    sleepState = 0;
else
    sm(1:st(1,1)-1) = 1;
    sleepState = 1;
end

%flip sleep state
for iev = 1:size(st,1)
    if st(iev,2) %if it's a start sleep
        if ~sleepState %if sleep is not already started
            %flip sleep state
            sm(st(iev,1):end) = st(iev,2);
            sleepState = 1;
        else
            %delete event
            ltodel=[udata.nwl.XData]; ltodel=ltodel(1:2:end);
            indexToDelLine = [indexToDelLine find(ltodel==st(iev,1))];
            indexToDel = [indexToDel iev];
            
        end
    else %if its a get up
        if iev < size(st,1) %if its not last event
            if st(iev+1,2)%if next event is go to bed, update sleep
                %flip sleep state
                sm(st(iev,1):end) = st(iev,2);
                sleepState = 0;
            else %delete zone
                %delete event
                ltodel=[udata.nwl.XData]; ltodel=ltodel(1:2:end);
                indexToDelLine = [indexToDelLine find(ltodel==st(iev,1))];
                indexToDel = [indexToDel iev];
            end
        else %update sleep state
            sm(st(iev,1):end) = st(iev,2);
            sleepState = 0;
        end
        
    end %check start or end
end
%
% if isfield(udata,'sl')
%     for il = 1:size(udata.sl,2)
%         delete(udata.sl(il));
%     end
%     udata = rmfield(udata,'sl');
% end

st(indexToDel,:) = [];
delete(udata.nwl(indexToDelLine));  udata.nwl(indexToDelLine) = [];
udata.events.nwon = st(st(:,2)==1,1)';
udata.events.nwoff = st(st(:,2)==0,1)';
udata.events.nwind = size(udata.events.nwon,2)+size(udata.events.nwoff,2);
udata.events.nonwear = int8(sm) & ~udata.events.sleep;