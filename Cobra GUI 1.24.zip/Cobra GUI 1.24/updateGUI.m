function udata = updateGUI(udata,handles)

yscale = str2double(get(handles.scaleTxt,'String'));
if ~isempty(yscale)
    for iax = 1:12
        set(udata.sa(iax),'ylim',[0 yscale]);
    end
end

switch udata.state
    
    case 1 %only graphs
        set(handles.scaleTxt,'String',num2str(yscale));
        td = udata.events.day;
        %flush all axes children
        for iax = 1:size(udata.sa,2)
            delete(get(udata.sa(iax),'children'));
            set(udata.sa(iax),'Visible','off');
        end
        %         if isfield(udata,'sl')
        %             udata = rmfield(udata,'sl');
        %         end
        %         if isfield(udata,'sr')
        %             udata = rmfield(udata,'sr');
        %         end
        %         if isfield(udata,'nwl')
        %             udata = rmfield(udata,'nwl');
        %         end
        %         if isfield(udata,'nwr')
        %             udata = rmfield(udata,'nwr');
        %         end
        %         if isfield(udata,'nwt')
        %             udata = rmfield(udata,'nwt');
        %         end
        
        for iax = 1:size(td,1)
            set(udata.sa(iax),'Visible','off');
            plot(udata.sa(iax),udata.counts);
            set(udata.sa(iax),'xlim',[td(iax) td(iax)+1439], ...
                'ylim',[0 yscale],...
                'xtick',[[td(iax):360: td(iax)+1439] td(iax)+1439],...
                'xticklabel','',...
                'ytick',[],...
                'xgrid','on',...
                'xlimmode','manual',...
                'ylimmode','manual',...
                'xtickmode','manual',...
                'ytickmode','manual'...
                );
            [dn, dw] =weekday(datenum(udata.date(td(iax)),'dd/mm/yyyy'));
            if (dn == 1) || (dn == 7)
                ylabel(udata.sa(iax),dw,'color','green');
            else
                ylabel(udata.sa(iax),dw,'color','black');
            end
            
            
            
            
        end
        [dn, dw] =weekday(datenum(udata.date(td(1)),'dd/mm/yyyy'));
        dw = [udata.date(td(1)) ' ' dw];
        if (dn == 1) || (dn == 7)
            ylabel(udata.sa(1),dw,'color','green');
        else
            ylabel(udata.sa(1),dw);
        end
        
        set(udata.sa(6),'ytick',[0 yscale],'yticklabel',{'0' num2str(yscale)});
        set(udata.sa(6),'xticklabel',{'00:00' '06:00' '12:00' '18:00' '23:59'});
        set(udata.sa(12),'xticklabel',{'00:00' '06:00' '12:00' '18:00' '23:59'});
        
        set([handles.text2 handles.sleepProc handles.text3 handles.speelConfirm_btn handles.pushbutton12 handles.doallBtn],'enable','on');
        set([handles.text4 handles.text5 handles.nonwearThreshold handles.text6 handles.nonWearProc],'enable','off');
        set([handles.text7 handles.text8 handles.lightThreshold handles.text10 handles.moderateThreshold handles.text9 handles.vigorousThreshold handles.thresholdProc],'enable','off');
        set([handles.text12 handles.text13 handles.MVPADur handles.text14 handles.MVPAPercent handles.text15 handles.text16 handles.sedDur handles.text17 handles.sedPercent handles.text18 handles.boutsProc],'enable','off');
        set([handles.text11 handles.text20 handles.wearTimeValid handles.text21 handles.nwearTimeValid handles.text22 handles.saveProc],'enable','off');
        
        set(handles.optionsMenu,'enable','on');
        
        %% ---  sleep --
    case 2 %draw sleep zones
        
        %delete previous zones
        if isfield(udata,'sr')
            for il = 1:size(udata.sr,2)
                delete(udata.sr(il));
            end
            udata = rmfield(udata,'sr');
        end
        
        td = udata.events.day;
        
        iirect = 1;
        for iax = 1:size(td,1)
            rects = [];
            %get xlims
            xl = get(udata.sa(iax),'xlim');
            yl = get(udata.sa(iax),'ylim');
            
            td = udata.events.sleep; tdi = find(diff(td))+1;
            tdi = tdi(find(tdi>=xl(1) & tdi<=xl(2)));
            
            if isempty(tdi) && udata.events.sleep(xl(1))
                rects(end+1:end+2) = xl;
            end
            
            if (~isempty(tdi) && ~td(tdi(1)))
                rects(end+1) = xl(1);
            end
            
            rects(end+1:end+size(tdi,1)) = tdi;
            
            if rem(size(rects,2),2) ~=0
                rects(end+1) = xl(2);
            end
            
            
            
            %reorganise rect limits
            if ~isempty(rects)
                axes(udata.sa(iax));
                
                for ir = 1:2:size(rects,2)
                    udata.sr(iirect) = patch([rects(ir) rects(ir+1) rects(ir+1) rects(ir)],[yl(1) yl(1) yl(2) yl(2)],[.1 .1 .1],'facealpha',0.4,'edgecolor','none');
                    iirect = iirect+1;
                end
            end
        end
        
        %         set([handles.text2 handles.sleepProc handles.text3],'enable','off');
        %         set([handles.text4 handles.text5 handles.nonwearThreshold handles.text6 handles.nonWearProc],'enable','on');
        set([handles.text7 handles.text8 handles.lightThreshold handles.text10 handles.moderateThreshold handles.text9 handles.vigorousThreshold handles.thresholdProc handles.nonWearProc handles.nonWearManual handles.nonWearConfirm],'enable','off');
        set([handles.text12 handles.text13 handles.MVPADur handles.text14 handles.MVPAPercent handles.text15 handles.text16 handles.sedDur handles.text17 handles.sedPercent handles.text18 handles.boutsProc],'enable','off');
        set([handles.text11 handles.text20 handles.wearTimeValid handles.text21 handles.nwearTimeValid handles.text22 handles.saveProc],'enable','off');
        
        
        %% ---  sleep  confirm--
    case 21 %draw sleep zones
        set([handles.text2 handles.sleepProc handles.text3 handles.speelConfirm_btn],'enable','off');
        set([handles.text4 handles.text5 handles.nonwearThreshold handles.text6 handles.nonWearProc handles.nonWearWindowDuration handles.nonWearManual handles.nonWearConfirm],'enable','on');
        set([handles.text7 handles.text8 handles.lightThreshold handles.text10 handles.moderateThreshold handles.text9 handles.vigorousThreshold handles.thresholdProc],'enable','off');
        set([handles.text12 handles.text13 handles.MVPADur handles.text14 handles.MVPAPercent handles.text15 handles.text16 handles.sedDur handles.text17 handles.sedPercent handles.text18 handles.boutsProc],'enable','off');
        set([handles.text11 handles.text20 handles.wearTimeValid handles.text21 handles.nwearTimeValid handles.text22 handles.saveProc],'enable','off');
        
        
        %% ---  non wear--
        
    case 3 %non wear zones
        
        %delete previous zones
        if isfield(udata,'nwr')
            for il = 1:size(udata.nwr,2)
                delete(udata.nwr(il));
            end
            udata = rmfield(udata,'nwr');
        end
        
        
        td = udata.events.day;
        iirect = 1;
        for iax = 1:size(td,1)
            rects = [];
            %get xlims
            xl = get(udata.sa(iax),'xlim');
            yl = get(udata.sa(iax),'ylim');
            
            if isfield(udata.events,'nonwear')
                
                
                td = udata.events.nonwear; tdi = find(diff(td))+1;
                tdi = tdi(find(tdi>=xl(1) & tdi<=xl(2)));
                
                if (~isempty(tdi) && ~td(tdi(1)))
                    rects(end+1) = xl(1);
                end
                
                rects(end+1:end+size(tdi,1)) = tdi;
                
                if rem(size(rects,2),2) ~=0
                    rects(end+1) = xl(2);
                end
                
                %if full day is non wear display a full day grey rect
                if all(td(xl(1):xl(2))) && isempty(rects)
                    rects = [xl(1) xl(2)];
                end
                
                %reorganise rect limits
                if ~isempty(rects)
                    axes(udata.sa(iax));
                    for ir = 1:2:size(rects,2)
                        udata.nwr(iirect) = patch([rects(ir) rects(ir+1) rects(ir+1) rects(ir)],[yl(1) yl(1) yl(2) yl(2)],[.7 .7 .7],'facealpha',0.3,'edgecolor','none');
                        iirect = iirect+1;
                    end
                end
            end
        end
        
        set([handles.text2 handles.sleepProc handles.text3],'enable','off');
        set([handles.text4 handles.text5 handles.nonwearThreshold handles.text6 handles.nonWearProc handles.nonWearWindowDuration handles.nonWearManual handles.nonWearConfirm],'enable','off');
        set([handles.text7 handles.text8 handles.lightThreshold handles.text10 handles.moderateThreshold handles.text9 handles.vigorousThreshold handles.thresholdProc],'enable','on');
        set([handles.text12 handles.text13 handles.MVPADur handles.text14 handles.MVPAPercent handles.text15 handles.text16 handles.sedDur handles.text17 handles.sedPercent handles.text18 handles.boutsProc],'enable','off');
        set([handles.text11 handles.text20 handles.wearTimeValid handles.text21 handles.nwearTimeValid handles.text22 handles.saveProc],'enable','off');
        
        %% ---  non wear but keep sleep editable (after loading from log)--
        
    case 31 %non wear zones without non wear buttons
        
        if isfield(udata,'nwr')
            for il = 1:size(udata.nwr,2)
                delete(udata.nwr(il));
            end
            udata = rmfield(udata,'nwr');
        end
        
        
        td = udata.events.day;
        iirect = 1;
        for iax = 1:size(td,1)
            rects = [];
            %get xlims
            xl = get(udata.sa(iax),'xlim');
            yl = get(udata.sa(iax),'ylim');
            
            if isfield(udata.events,'nonwear')
                
                td = udata.events.nonwear; tdi = find(diff(td))+1;
                tdi = tdi(find(tdi>=xl(1) & tdi<=xl(2)));
                
                if (~isempty(tdi) && ~td(tdi(1)))
                    rects(end+1) = xl(1);
                end
                
                rects(end+1:end+size(tdi,1)) = tdi;
                
                if rem(size(rects,2),2) ~=0
                    rects(end+1) = xl(2);
                end
                
                %if full day is non wear display a full day grey rect
                if all(td(xl(1):xl(2))) && isempty(rects)
                    rects = [xl(1) xl(2)];
                end
                
                %reorganise rect limits
                if ~isempty(rects)
                    axes(udata.sa(iax));
                    for ir = 1:2:size(rects,2)
                        udata.nwr(iirect) = patch([rects(ir) rects(ir+1) rects(ir+1) rects(ir)],[yl(1) yl(1) yl(2) yl(2)],[.7 .7 .7],'facealpha',0.3,'edgecolor','none');
                        iirect = iirect+1;
                    end
                end
            end
        end
        
        %         set([handles.text7 handles.text8 handles.lightThreshold handles.text10 handles.moderateThreshold handles.text9 handles.vigorousThreshold handles.thresholdProc handles.nonWearWindowDuration handles.nonWearManual handles.nonWearConfirm handles.nonWearProc],'enable','off');
        %         set([handles.text12 handles.text13 handles.MVPADur handles.text14 handles.MVPAPercent handles.text15 handles.text16 handles.sedDur handles.text17 handles.sedPercent handles.text18 handles.boutsProc],'enable','off');
        %         set([handles.text11 handles.text20 handles.wearTimeValid handles.text21 handles.nwearTimeValid handles.text22 handles.saveProc],'enable','off');
        
        %% ---  activity levels --
        
    case 4 %activity levels
        td = udata.events.day;
        for iax = 1:size(td,1)
            %sedentary
            rects = [];
            %get xlims
            xl = get(udata.sa(iax),'xlim');
            yl = get(udata.sa(iax),'ylim');
            
            td = udata.events.sedentary; tdi = find(diff(td))+1;
            tdi = tdi(find(tdi>=xl(1) & tdi<=xl(2)));
            
            if (~isempty(tdi) && ~td(tdi(1))) %if there is a transition during that day; AND the 1st transition of the day is STOP
                rects(end+1) = xl(1);
            end
            
            rects(end+1:end+size(tdi,1)) = tdi;
            
            if rem(size(rects,2),2) ~=0
                rects(end+1) = xl(2);
            end
            
            if all(td(xl(1):xl(2))) && isempty(rects)
                rects = [xl(1) xl(2)];
            end
            
            %reorganise rect limits
            if ~isempty(rects)
                axes(udata.sa(iax));
                for ir = 1:2:size(rects,2)
                    patch([rects(ir) rects(ir+1) rects(ir+1) rects(ir)],[yl(1) yl(1) yl(2) yl(2)],[0 1 0],'facealpha',0.5,'edgecolor','none');
                end
            end
            
            %light
            rects = [];
            %get xlims
            xl = get(udata.sa(iax),'xlim');
            yl = get(udata.sa(iax),'ylim');
            
            td = udata.events.light; tdi = find(diff(td))+1;
            tdi = tdi(find(tdi>=xl(1) & tdi<=xl(2)));
            
            if (~isempty(tdi) && ~td(tdi(1)))
                rects(end+1) = xl(1);
            end
            
            rects(end+1:end+size(tdi,1)) = tdi;
            
            if rem(size(rects,2),2) ~=0
                rects(end+1) = xl(2);
            end
            
            if all(td(xl(1):xl(2))) && isempty(rects)
                rects = [xl(1) xl(2)];
            end
            
            %reorganise rect limits
            if ~isempty(rects)
                axes(udata.sa(iax));
                for ir = 1:2:size(rects,2)
                    patch([rects(ir) rects(ir+1) rects(ir+1) rects(ir)],[yl(1) yl(1) yl(2) yl(2)],[1     1     0],'facealpha',0.5,'edgecolor','none');
                end
            end
            
            %             %moderate
            %             rects = [];
            %             %get xlims
            %             xl = get(udata.sa(iax),'xlim');
            %             yl = get(udata.sa(iax),'ylim');
            %
            %             td = udata.events.moderate; tdi = find(diff(td))+1;
            %             if td(xl(1))
            %                 rects(end+1) = xl(1);
            %             end
            %
            %             tdi = tdi(find(tdi>=xl(1) & tdi<=xl(2)));
            %             rects(end+1:end+size(tdi,1)) = tdi;
            %
            %             if rem(size(rects,2),2) ~=0
            %                 rects(end+1) = xl(2);
            %             end
            %
            %             %reorganise rect limits
            %             if ~isempty(rects)
            %                 axes(udata.sa(iax));
            %                 for ir = 1:2:size(rects,2)
            %                     patch([rects(ir) rects(ir+1) rects(ir+1) rects(ir)],[yl(1) yl(1) yl(2) yl(2)],[0.8706    0.4902  0],'facealpha',0.5,'edgecolor','none');
            %                 end
            %             end
            %
            %             %vigorous
            %             rects = [];
            %             %get xlims
            %             xl = get(udata.sa(iax),'xlim');
            %             yl = get(udata.sa(iax),'ylim');
            %
            %             td = udata.events.vigorous; tdi = find(diff(td))+1;
            %             if td(xl(1))
            %                 rects(end+1) = xl(1);
            %             end
            %
            %             tdi = tdi(find(tdi>=xl(1) & tdi<=xl(2)));
            %             rects(end+1:end+size(tdi,1)) = tdi;
            %
            %             if rem(size(rects,2),2) ~=0
            %                 rects(end+1) = xl(2);
            %             end
            %
            %             %reorganise rect limits
            %             if ~isempty(rects)
            %                 axes(udata.sa(iax));
            %                 for ir = 1:2:size(rects,2)
            %                     patch([rects(ir) rects(ir+1) rects(ir+1) rects(ir)],[yl(1) yl(1) yl(2) yl(2)],[1 0 0],'facealpha',0.5,'edgecolor','none');
            %                 end
            %             end
            %         end
            
            %MVPA
            rects = [];
            %get xlims
            xl = get(udata.sa(iax),'xlim');
            yl = get(udata.sa(iax),'ylim');
            
            td = udata.events.MVPA; tdi = find(diff(td))+1;
            tdi = tdi(find(tdi>=xl(1) & tdi<=xl(2)));
            
            if (~isempty(tdi) && ~td(tdi(1)))
                rects(end+1) = xl(1);
            end
            
            rects(end+1:end+size(tdi,1)) = tdi;
            
            if rem(size(rects,2),2) ~=0
                rects(end+1) = xl(2);
            end
            
            if all(td(xl(1):xl(2))) && isempty(rects)
                rects = [xl(1) xl(2)];
            end
            
            %reorganise rect limits
            if ~isempty(rects)
                axes(udata.sa(iax));
                for ir = 1:2:size(rects,2)
                    patch([rects(ir) rects(ir+1) rects(ir+1) rects(ir)],[yl(1) yl(1) yl(2) yl(2)],[1 0 0],'facealpha',0.5,'edgecolor','none');
                end
            end
        end
        
        set([handles.text2 handles.sleepProc handles.text3],'enable','off');
        set([handles.text4 handles.text5 handles.nonwearThreshold handles.text6 handles.nonWearProc],'enable','off');
        set([handles.text7 handles.text8 handles.lightThreshold handles.text10 handles.moderateThreshold handles.text9 handles.vigorousThreshold handles.thresholdProc],'enable','off');
        set([handles.text12 handles.text13 handles.MVPADur handles.text14 handles.MVPAPercent handles.text15 handles.text16 handles.sedDur handles.text17 handles.sedPercent handles.text18 handles.boutsProc],'enable','on');
        set([handles.text11 handles.text20 handles.wearTimeValid handles.text21 handles.nwearTimeValid handles.text22 handles.saveProc],'enable','off');
        
        
        %% bouts
        
    case 5
        
        %MVPA bouts
        td = udata.events.day;
        for iax = 1:size(td,1)
            %sedentary
            rects = [];
            %get xlims
            xl = get(udata.sa(iax),'xlim');
            yl = get(udata.sa(iax),'ylim');
            ysize = yl(2)-yl(1); ylm(1) = yl(1)+0.9*ysize; ylm(2) = yl(1)+0.95*ysize;
            
            td = udata.events.mvbouts; tdi = find(diff(td))+1;
            tdi = tdi(find(tdi>=xl(1) & tdi<=xl(2)));
            
            if (~isempty(tdi) && ~td(tdi(1)))
                rects(end+1) = xl(1);
            end
            
            rects(end+1:end+size(tdi,1)) = tdi;
            
            if rem(size(rects,2),2) ~=0
                rects(end+1) = xl(2);
            end
            
            if all(td(xl(1):xl(2))) && isempty(rects)
                rects = [xl(1) xl(2)];
            end
            
            %reorganise rect limits
            if ~isempty(rects)
                axes(udata.sa(iax));
                for ir = 1:2:size(rects,2)
                    patch([rects(ir) rects(ir+1) rects(ir+1) rects(ir)],[ylm(1) ylm(1) ylm(2) ylm(2)],[1 0 0],'facealpha',1,'edgecolor','none');
                end
            end
            
            %sed bouts
            rects = [];
            %get xlims
            xl = get(udata.sa(iax),'xlim');
            yl = get(udata.sa(iax),'ylim');
            ysize = yl(2)-yl(1); ylm(1) = yl(1)+0.9*ysize; ylm(2) = yl(1)+0.95*ysize;
            
            td = udata.events.sedbouts; tdi = find(diff(td))+1;
            tdi = tdi(find(tdi>=xl(1) & tdi<=xl(2)));
            
            if (~isempty(tdi) && ~td(tdi(1)))
                rects(end+1) = xl(1);
            end
            
            rects(end+1:end+size(tdi,1)) = tdi;
            
            if rem(size(rects,2),2) ~=0
                rects(end+1) = xl(2);
            end
            
            if all(td(xl(1):xl(2))) && isempty(rects)
                rects = [xl(1) xl(2)];
            end
            
            %reorganise rect limits
            if ~isempty(rects)
                axes(udata.sa(iax));
                for ir = 1:2:size(rects,2)
                    patch([rects(ir) rects(ir+1) rects(ir+1) rects(ir)],[ylm(1) ylm(1) ylm(2) ylm(2)],[0 0 0],'facealpha',1,'edgecolor','none');
                end
            end
        end
        
        set([handles.text2 handles.sleepProc handles.text3],'enable','off');
        set([handles.text4 handles.text5 handles.nonwearThreshold handles.text6 handles.nonWearProc],'enable','off');
        set([handles.text7 handles.text8 handles.lightThreshold handles.text10 handles.moderateThreshold handles.text9 handles.vigorousThreshold handles.thresholdProc],'enable','off');
        set([handles.text12 handles.text13 handles.MVPADur handles.text14 handles.MVPAPercent handles.text15 handles.text16 handles.sedDur handles.text17 handles.sedPercent handles.text18 handles.boutsProc],'enable','off');
        set([handles.text11 handles.text20 handles.wearTimeValid handles.text21 handles.nwearTimeValid handles.text22 handles.saveProc],'enable','on');
        
        %% rescale
    case 6
        
        yscale = str2double(get(handles.scaleTxt,'String'));
        if ~isempty(yscale)
            td = udata.events.day;
            for iax = 1:size(td,1)
                set(udata.sa(iax),'ylim',[0 yscale]);
            end
        end
        
        
end


