function impData = importXls_ActiGraph(path,fname)

startRow = 12;
delimiter = ',';
formatSpec = '%s%s%f%f%f%*s%*s%*s%*s%*s%*s%f%[^\n\r]';
fileID = fopen(fullfile(path,fname),'r');

dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);

% Close the text file
fclose(fileID);

dataArray([3, 4, 5, 6]) = cellfun(@(x) num2cell(x), dataArray([3, 4, 5, 6]), 'UniformOutput', false);
impData = [dataArray{1:end-1}];

%find midnights
di = find(strcmp(impData(:,2),'00:00:00'));

dn=[]; dn(size(impData,1)) = 0;

for id = 1:size(di,1)-1
    dn(di(id):di(id+1)-1) = id;
end
dn(di(id+1):end)=id+1;
dn=num2cell(dn');

%convert to cell
impData = [dn impData(:,1) num2cell(datenum(impData(:,2),'HH:MM:SS')) impData(:,6) impData(:,3:5)];
if size(impData,1) > 14399
    impData = impData(1:14399,:);
end
%% Clear temporary variables
clearvars filename delimiter startRow formatSpec fileID dataArray ans;

end
