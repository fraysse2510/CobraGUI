function udata = createSleepFromEvents(udata,son,soff)

% create sleep masks from start and end events (0 = not sleeping)
sm = nan(size(udata.counts));
son(son<1) = []; soff(soff<1) = [];
son = sort(son');
if ~isempty(son)
    son(:,2) = 1;
end
soff=sort(soff');
if ~isempty(soff)
    soff(:,2) = 0;
end

if isempty(son) && isempty(soff)
    if isfield(udata,'sl')
        delete(udata.sl(:)); udata = rmfield(udata,'sl');
    end
    if isfield(udata,'sr')
        delete(udata.sr(:)); udata = rmfield(udata,'sr');
    end
    if isfield(udata.events,'son')
        udata.events.son = [];
    end
    if isfield(udata.events,'soff')
        udata.events.soff = [];
    end
    udata.events.sind = 1;
    udata.events.sleep = zeros(size(udata.counts,1),size(udata.counts,2));
    return,
end

st = [son; soff]; st = sortrows(st,1);
indexToDel = [];
indexToDelLine = [];

if st(1,2) %starts with a start sleep
    sm(1:st(1,1)-1) = 0;
    sleepState = 0;
else
    sm(1:st(1,1)-1) = 1;
    sleepState = 1;
end

%flip sleep state
for iev = 1:size(st,1)
    if st(iev,2) %if it's a start sleep
        if ~sleepState %if sleep is not already started
            %flip sleep state
            sm(st(iev,1):end) = st(iev,2);
            sleepState = 1;
        else
            %delete event
            ltodel=[udata.sl.XData]; ltodel=ltodel(1:2:end);
            indexToDelLine = [indexToDelLine find(ltodel==st(iev,1))];
            indexToDel = [indexToDel iev];
            
        end
    else %if its a get up
        if iev < size(st,1) %if its not last event
            if st(iev+1,2)%if next event is go to bed, update sleep
                %flip sleep state
                sm(st(iev,1):end) = st(iev,2);
                sleepState = 0;
            else %delete zone
                %delete event
                ltodel=[udata.sl.XData]; ltodel=ltodel(1:2:end);
                indexToDelLine = [indexToDelLine find(ltodel==st(iev,1))];
                indexToDel = [indexToDel iev];
            end
        else %update sleep state
            sm(st(iev,1):end) = st(iev,2);
            sleepState = 0;
        end
        
    end %check start or end
end
%
% if isfield(udata,'sl')
%     for il = 1:size(udata.sl,2)
%         delete(udata.sl(il));
%     end
%     udata = rmfield(udata,'sl');
% end

st(indexToDel,:) = [];
delete(udata.sl(indexToDelLine)); udata.sl(indexToDelLine) = [];
udata.events.son = st(st(:,2)==1,1)';
udata.events.soff = st(st(:,2)==0,1)';
udata.events.sind = size(udata.events.son,2)+size(udata.events.soff,2);
udata.events.sleep = int8(sm);