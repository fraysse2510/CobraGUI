function impData = importXls_ActiCal(path,fname)

%% Import the data
[~, ~, impData_0] = xlsread(fullfile(path,fname),'Sheet1','B28:B16378');
[~, ~, impData_1] = xlsread(fullfile(path,fname),'Sheet1','D28:F16378');
impData = [impData_0,impData_1];
impData(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),impData)) = {''};

% %% Replace non-numeric cells with NaN
% R = cellfun(@(x) ~isnumeric(x) && ~islogical(x),impData); % Find non-numeric cells
% impData(R) = {NaN}; % Replace non-numeric cells

%% Clear temporary variables
clearvars impData_0 impData_1 R;

end