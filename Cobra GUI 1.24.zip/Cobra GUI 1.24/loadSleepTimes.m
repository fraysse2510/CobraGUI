function [udata,fileFound] = loadSleepTimes(udata,handles)

%reloads previous results and graphs sleep times from there
%created 30/09/2014 by Francois Fraysse for UniSA
fileFound = 0;
rf = udata.sleepFolder;

contents = cellstr(get(handles.FilesList,'String'));
fname = contents{get(handles.FilesList,'Value')};

di = strfind(fname,'.'); di = di(end);
fnameo = fname;

% fname = [fname(1:di-1) '.mat'];
fname = [fname(1:6) '.mat'];
fname = fullfile(rf,fname);

if exist(fname) == 2
    load(fname);
    udata.events.day = res.events.day;
    udata.events.sleep = res.events.sleep;
    udata.events.sleepcobra = res.events.sleepcobra;
    udata.events.sleepVanHees = res.events.sleepVanHees;
    udata.events.sleepVanHees_untrimmed = res.events.sleepVanHees_untrimmed;   
    fileFound = 1;
else %try with an 's' before the '.mat'
    fname = [fnameo(1:17) '_60.mat'];
    fname = fullfile(rf,fname);
    if exist(fname) == 2
        load(fname);
        udata.events.day = res.events.day;
        udata.events.sleep = res.events.sleep;
        udata.events.sleepcobra = res.events.sleepcobra;
        udata.events.sleepVanHees = res.events.sleepVanHees;
        udata.events.sleepVanHees_untrimmed = res.events.sleepVanHees_untrimmed;
        udata.events.nonwear = res.events.nonwear;
        fileFound = 1;
    end
end

