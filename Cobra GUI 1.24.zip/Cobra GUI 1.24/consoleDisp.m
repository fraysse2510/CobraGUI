function consoleDisp(udata,handles,st)

set(handles.infoTxt,'String',st);
end