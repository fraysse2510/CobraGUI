function sedBoutLength50 = findSedBoutLength50(sed);

%find the bout length at which 50% of sed time is accumulated

u = find(diff(sed)==+1);
d=find(diff(sed)==-1);

if ~isempty(d) && ~isempty(u)
    
    if d(1)<u(1)
        u = [0; u];
    end
    
    if u(end)>d(end)
        d = [d; size(sed,1)];
    end
    
    bdur = d-u;
    bdur = sort(bdur);
    bdurs = cumsum(bdur);
    indb = find(bdurs>=bdurs(end)./2); indb = indb(1);
    
    
    
    sedBoutLength50 = bdur(indb);
else
    sedBoutLength50 = NaN;
end