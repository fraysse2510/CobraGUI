t=0:.01:10; hp=plot(t,1);
hCursorbar = graphics.cursorbar(hp, 'position',[1 0 0],'UpdateFcn',@testupdatefcn);drawnow
% set(hCursorbar,'UpdateFcn',@testupdatefcn); 

% hCursorbar.CursorLineColor = [.9,.3,.6]; % default=[0,0,0]='k'
% hCursorbar.CursorLineStyle = '-.';       % default='-'
% hCursorbar.CursorLineWidth = 2.5;        % default=1
% hCursorbar.Orientation = 'vertical';     % =default
% hCursorbar.TargetMarkerSize = 12;        % default=8
% hCursorbar.TargetMarkerStyle = 'none';      % default='s' (square)


%
