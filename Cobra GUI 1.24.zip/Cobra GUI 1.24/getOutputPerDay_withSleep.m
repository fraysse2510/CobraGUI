function getOutputPerDay_withSleep(udata,handles)

nwval = round(str2double(get(handles.nwearTimeValid,'String')));
wval = round(str2double(get(handles.wearTimeValid,'String')));

vwd = 0;    %no of valid week days
vwed = 0;   %no of valid weekend days

%get file name
contents = cellstr(get(handles.FilesList,'String'));
fn = contents{get(handles.FilesList,'Value')}; fn = fn(1:strfind(fn,'.')-1);
fnCsv = [fn '_RESULTS.csv'];
fnMat = [fn '.mat'];
fnFig = [fn '_RESULTS.png'];

%create paths to save
csvPath = [udata.rPath '\csv'];
if ~isdir(csvPath), mkdir(csvPath); end
matPath = [udata.rPath '\mat'];
if ~isdir(matPath), mkdir(matPath); end
figPath = [udata.rPath '\figures'];
if ~isdir(figPath), mkdir(figPath); end

%% store whether kid or parent
moderateThreshold = str2num(get(handles.moderateThreshold,'string'));

%load holiday info
% indP = find(strcmpi(fn(1:5),udata.PartStateAndHand(:,1)),1);
% pState = cell2mat(udata.PartStateAndHand(indP,2));
%
% if isChild %for children, holidays = school + public
%     holList = [udata.SchoolHoliday(:,pState,1); udata.SchoolHoliday(:,pState,2)];
% else %for parents, holidays = public only
%     holList = udata.SchoolHoliday(:,pState,1);
% end

%% open and prepare results file
fid = fopen(fullfile(csvPath,fnCsv),'w');

%print header
fprintf(fid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n','day no','is weekend','is holiday','sleep time min','sleep time24 min','sleep midpoint min from midnight','sleep efficiency %','bed time min from midnight','getup time min from midnight','wear time min','sedentary time min','light time min','moderate time min','vigorous time min','MVPA time min','MVPA time spent in bouts min','number of MVPA bouts','average MVPA bout length min','average counts during MVPA','sedentary time spent in bouts min','number of sedentary bouts','average sedentary bout length min','50% sedentary time bout length','50% MVPA time bout length','W50% MVPA','T50% MVPA','Alpha sedentary','Alpha MVPA','alpha_sedentary_error','GINI sedentary','Median bout length sedentary','Time above median sedentary','% time per bout above median sedentary','total counts','average counts','total counts with sleep','average counts with sleep');

td = udata.events.day;

wdt = [];
wedt = [];

for iday = 1:size(td,1)
    
    endEpoch = 1439;
    
    %check if day is valid
    if isfield(udata.events,'nonwear')
        doProcess = (size(find(udata.events.nonwear(td(iday):td(iday)+1439)),1) < nwval) &&  ((size(find(~udata.events.nonwear(td(iday):td(iday)+1439)),1) - size(find(udata.events.sleep(td(iday):td(iday)+1439)),1)) > wval) && ~(iday>=size(td,1)-2 && size(find(udata.events.sleep(td(iday)-720:td(iday)+719)),1) <= 1);  %day is last 3 and no sleep)
    else
        doProcess = ((1440 - size(find(udata.events.sleep(td(iday):td(iday)+1439)),1)) > wval) && ~(iday>=size(td,1)-2 && size(find(udata.events.sleep(td(iday)-720:td(iday)+719)),1) <= 1);  %day is last 3 and no sleep)
    end
    
    if doProcess % ~isfield(udata.events,'nonwear') || (size(find(udata.events.nonwear(td(iday):td(iday)+endEpoch)),1) < nwval)% &&  ((size(find(~udata.events.nonwear(td(iday):td(iday)+endEpoch)),1) - size(find(udata.events.sleep(td(iday):td(iday)+endEpoch)),1)) > wval)
        
        %day is valid, carry on processing
        
        %% holidays and week end days
        %check if  holiday
        %         if ~isempty(find(strcmpi(udata.date(td(iday)),holList),1)) %holiday = YES
        %             isholiday = 1;
        %         else
        %             isholiday = 0;
        %         end
        isholiday = 0;
        
        %check if week or weekend day
        [dn, ~] = weekday(datenum(udata.date(td(iday)),'dd/mm/yyyy'));
        if (dn == 1) || (dn == 7)
            isweekend = 1;
            %             disp(['day ' num2str(iday) ' is valid - weekend']);
            %             vwed = vwed+1;
        else
            isweekend = 0;
            %             disp(['day ' num2str(iday) ' is valid - weekday']);
            %             vwd = vwd+1;
        end
        
        %group we and holiday
        if isweekend || isholiday
            %             disp(['day ' num2str(iday) ' is valid - weekend or holiday']);
            vwed = vwed+1;
        else
            %             disp(['day ' num2str(iday) ' is valid - weekday']);
            vwd = vwd+1;
        end
        
        %% activity
        % sleep time
        % ignore sleep time for checkpoint day and day after
        if iday < 2
            sleepTime = NaN;
            sleepTime24 = NaN;
        else
            sleepTime = size(find(udata.events.sleep(td(iday)-720:td(iday)+719)),1);
            sleepTime24 = size(find(udata.events.sleep(td(iday):td(iday)+endEpoch)),1);
        end
        
        % wear time
        wearTime = size(find(~udata.events.nonwear(td(iday):td(iday)+endEpoch)),1) - size(find(udata.events.sleep(td(iday):td(iday)+endEpoch)),1); %%%%%%%%%%%%%%%%%%%%%%%%%%%
        % sed time
        sedTime = size(find(udata.events.sedentary(td(iday):td(iday)+endEpoch)),1);
        % light time
        lightTime = size(find(udata.events.light(td(iday):td(iday)+endEpoch)),1);
        % moderate time
        modTime = size(find(udata.events.moderate(td(iday):td(iday)+endEpoch)),1);
        % vigorous time
        vigTime = size(find(udata.events.vigorous(td(iday):td(iday)+endEpoch)),1);
        % MVPA time
        mvTime = modTime+vigTime;
        % MVPA bouts time
        mvpaboutsTime = size(find(udata.events.mvbouts(td(iday):td(iday)+endEpoch)),1);
        % sed bouts time
        sedboutsTime = size(find(udata.events.sedbouts(td(iday):td(iday)+endEpoch)),1);
        
        %sleep extra parameters
        if iday >= 2
            [midpoint,bedTime,upTime,frag] = getSleepParameters(udata,td,iday);
        else
            %fill with NAN
            midpoint = NaN;
            bedTime = NaN;
            upTime = NaN;
            frag = NaN;
        end
        
        
        %average intensity in MVPA
        total_cpm_MVPA = udata.counts(td(iday):td(iday)+1439);
        total_cpm_MVPA = total_cpm_MVPA(udata.events.moderate(td(iday):td(iday)+1439) | udata.events.vigorous(td(iday):td(iday)+1439));
        total_cpm_MVPA(total_cpm_MVPA<moderateThreshold) = [];
        avg_cpm_MVPA = sum(total_cpm_MVPA)./size(total_cpm_MVPA,1);
        
        %         %total counts
        %         totcounts = sum(udata.counts(td(iday):td(iday)+endEpoch));
        
        %total counts excluding sleep and non wear
        tmpcnt = udata.counts(td(iday):td(iday)+endEpoch);
        tmpMask = ~(udata.events.sleep(td(iday):td(iday)+endEpoch) | udata.events.nonwear(td(iday):td(iday)+endEpoch));
        tmpcnt = tmpcnt(tmpMask);
        totcounts = sum(tmpcnt); avgcounts = totcounts./size(tmpcnt,1);
        
        %total counts excluding non wear but including sleep
        tmpcnt = udata.counts(td(iday):td(iday)+1439);
        if isfield(udata.events,'nonwear')
            tmpMask = ~udata.events.nonwear(td(iday):td(iday)+1439);
            tmpcnt = tmpcnt(tmpMask);
        end
        totcountsWithSleep = sum(tmpcnt); avgcountsWithSleep = totcountsWithSleep./size(tmpcnt,1);
        
        %number of bouts - sedentary
        sedboutsNumber = ceil(size(find(diff(udata.events.sedbouts(td(iday):td(iday)+endEpoch))),1)./2);
        %if the day both starts and end with a bout we need to add 1 bout
        if udata.events.sedbouts(td(iday)) == 1 && udata.events.sedbouts(td(iday)+endEpoch) == 1
            sedboutsNumber = sedboutsNumber+1;
        end
        %number of bouts - mvpa
        mvpaboutsNumber = ceil(size(find(diff(udata.events.mvbouts(td(iday):td(iday)+endEpoch))),1)./2);
        %if the day both starts and end with a bout we need to add 1 bout
        if udata.events.mvbouts(td(iday)) == 1 && udata.events.mvbouts(td(iday)+endEpoch) == 1
            mvpaboutsNumber = mvpaboutsNumber+1;
        end
        
        %bout length at which 50% sed time is accumulated
        sedBoutLength50 = findSedBoutLength50(udata.events.sedentary(td(iday):td(iday)+endEpoch));
        
        %same but for MVPA - using all events of MVPA
        MVPABoutLength50 = findMVPABoutLength50(udata.events.MVPA(td(iday):td(iday)+1439));
        
        %% ALPHA METRICS
        % NEW METRICS
        tt = udata.events.sedentary(td(iday):td(iday)+endEpoch);
        
        kBout = 1;
        BL = 0;
        ind = 1;
        VEC = [];
        
        while ind < size(tt,1)
            if ~tt(ind)
                if BL
                    VEC(kBout) = BL;
                    kBout = kBout+1;
                    BL=0;
                end
                ind = ind+1;
            elseif tt(ind)
                BL = BL+1;
                ind = ind+1;
            end
        end
        
        VEC = sort(VEC,'descend');
        
        if ~isempty(VEC)
            
            tresb = 10;
            
            VEC(VEC<tresb) = [];
        end
            if ~isempty(VEC)
            %%
            %get GINI, AUC etc
            cumVEC = cumsum(VEC);
            fracbout=[1:size(VEC,2)].*(1/size(VEC,2));
            cumVECn = cumVEC./cumVEC(end);
            cumVECn=[0 cumVECn];
            fracbout=[0 fracbout];
            AUC=(trapz(fracbout,cumVECn)-0.5);
            GINI = AUC./0.5;
            Median_bout = median(VEC);
            Per_time_above_median = sum(VEC(VEC>median(VEC)))./sum(VEC).*100;
            Total_sed_Time = sum(VEC);
            no_bouts_above_median = sum(VEC>Median_bout);
            per_time_in_long_bouts = Per_time_above_median./no_bouts_above_median;
            frag_index = length(VEC)./sum(VEC);
            
            %%
            % get alpha
            bins_spaces = linspace(1,3,100);
            binLims = 10.^bins_spaces;
            %remove bins larger than longest bout
            binLims(max(find(binLims < VEC(1)))+2:end) = [];
            binsR = hist(VEC,binLims);
            
            if size(binLims) > size(binsR)
                binLims = binLims(1:end-1);
            end
            binRnorm = binsR./binLims;
            %         figure, loglog(binLims,binRnorm,'b-o'), grid; hold on;
            
            sumBouts = 0;
            for iBout = 1:length(VEC)
                sumBouts = sumBouts+log(VEC(iBout)/(10-0.5));
            end
            
            sumBouts = 1./sumBouts;
            
            alpha = 1+length(VEC)*sumBouts;
            SDalpha = (alpha-1)./sqrt(length(VEC));
            Constant = (alpha-1)*(10.^(alpha-1));
            
            %         estimates = trapz(binLims,binRnorm).*Constant*(binLims.^(-alpha));
            
            %         loglog(binLims,estimates,'blue','linewidth',2);
        else
            alpha = NaN;
            SDalpha = NaN;
            GINI = NaN;
            Median_bout = NaN;
            Per_time_above_median = NaN;
            per_time_in_long_bouts = NaN;
            
        end
        
        %% ALPHA METRICS MVPA
        % NEW METRICS - MVPA
        tt = udata.events.MVPA(td(iday):td(iday)+1439);
        
        kBout = 1;
        BL = 0;
        ind = 1;
        VEC = [];
        
        while ind < size(tt,1)
            if ~tt(ind)
                if BL
                    VEC(kBout) = BL;
                    kBout = kBout+1;
                    BL=0;
                end
                ind = ind+1;
            elseif tt(ind)
                BL = BL+1;
                ind = ind+1;
            end
        end
        
        VEC = sort(VEC,'descend');
        
        if ~isempty(VEC)
            
            tresb = 1;
            
            VEC(VEC<tresb) = [];
        end
        if ~isempty(VEC)
            
            %%
            %get GINI, AUC etc
            cumVEC = cumsum(VEC);
            fracbout=[1:size(VEC,2)].*(1/size(VEC,2));
            cumVECn = cumVEC./cumVEC(end);
            cumVECn=[0 cumVECn];
            fracbout=[0 fracbout];
            AUC=(trapz(fracbout,cumVECn)-0.5);
            GINIMVPA = AUC./0.5;
            Median_boutMVPA = median(VEC);
            Per_time_above_medianMVPA = sum(VEC(VEC>median(VEC)))./sum(VEC).*100;
            Total_sed_Time = sum(VEC);
            no_bouts_above_medianMVPA = sum(VEC>Median_boutMVPA);
            per_time_in_long_boutsMVPA = Per_time_above_medianMVPA./no_bouts_above_medianMVPA;
            frag_indexMVPA = length(VEC)./sum(VEC);
            
            %%
            % get alpha
            bins_spaces = linspace(1,3,100);
            binLims = 10.^bins_spaces;
            %remove bins larger than longest bout
            binLims(max(find(binLims < VEC(1)))+2:end) = [];
            binsR = hist(VEC,binLims);
            
            if size(binLims) > size(binsR)
                binLims = binLims(1:end-1);
            end
            binRnorm = binsR./binLims;
            %         figure, loglog(binLims,binRnorm,'b-o'), grid; hold on;
            
            sumBouts = 0;
            for iBout = 1:length(VEC)
                sumBouts = sumBouts+log(VEC(iBout)/(1-0.5));
            end
            
            sumBouts = 1./sumBouts;
            
            alphaMVPA = 1+length(VEC)*sumBouts;
            SDalphaMVPA = (alphaMVPA-1)./sqrt(length(VEC));
            ConstantMVPA = (alphaMVPA-1)*(10.^(alphaMVPA-1));
            
            %         estimates = trapz(binLims,binRnorm).*Constant*(binLims.^(-alpha));
            
            %         loglog(binLims,estimates,'blue','linewidth',2);
            
            
            MVPAfitW50 = MVPAcurvefitW50(VEC);
            
            
            %%
            % T50 - midpoint of MVPA accumulation
            
            MVPA_T50 = MVPAmidpoint_T50(tt);
            
            %%
            %getting weekly MVPA
            
            dailyMVPA(:,iday) = tt;
            
            
            
        else
            alphaMVPA = NaN;
            SDalphaMVPA = NaN;
            GINIMVPA = NaN;
            Median_boutMVPA = NaN;
            Per_time_above_medianMVPA = NaN;
            per_time_in_long_boutsMVPA = NaN;
            MVPAfitW50 = NaN;
            MVPA_T50 = NaN;
            dailyMVPA = [];
        end
        %%
        fprintf(fid,'%u,%u,%u,%.0f,%.0f,%.0f,%.1f,%.0f,%.0f,%.0f,%.0f,%.0f,%.0f,%.0f,%.0f,%.0f,%.0f,%.1f,%.0f,%.0f,%.0f,%.1f,%.1f,%.1f,%.1f,%.0f,%.2f,%.2f,%.2f,%.2f,%.0f,%.1f,%.1f,%.0f,%.1f,%.0f,%.1f\n',iday,isweekend,isholiday,sleepTime,sleepTime24,midpoint,frag,bedTime,upTime,wearTime,sedTime,lightTime,modTime,vigTime,mvTime,mvpaboutsTime,mvpaboutsNumber,(mvpaboutsTime./mvpaboutsNumber),avg_cpm_MVPA,sedboutsTime,sedboutsNumber,(sedboutsTime./sedboutsNumber),sedBoutLength50,MVPABoutLength50,MVPAfitW50,MVPA_T50,alpha,alphaMVPA,SDalpha,GINI,Median_bout,Per_time_above_median,per_time_in_long_bouts,totcounts,avgcounts,totcountsWithSleep,avgcountsWithSleep);
        
        %store for averaging later
        %if child, group weekends and holidays
        if isweekend || isholiday
            wedt(end+1,:) = [sleepTime sleepTime24 midpoint frag bedTime upTime wearTime sedTime lightTime modTime vigTime mvTime mvpaboutsTime mvpaboutsNumber (mvpaboutsTime./mvpaboutsNumber) avg_cpm_MVPA sedboutsTime sedboutsNumber (sedboutsTime./sedboutsNumber) sedBoutLength50 MVPAfitW50 MVPA_T50 alpha alphaMVPA totcounts avgcounts totcountsWithSleep avgcountsWithSleep];
        else
            wdt(end+1,:) = [sleepTime sleepTime24 midpoint frag bedTime upTime wearTime sedTime lightTime modTime vigTime mvTime mvpaboutsTime mvpaboutsNumber (mvpaboutsTime./mvpaboutsNumber) avg_cpm_MVPA sedboutsTime sedboutsNumber (sedboutsTime./sedboutsNumber) sedBoutLength50 MVPAfitW50 MVPA_T50 alpha alphaMVPA totcounts avgcounts totcountsWithSleep avgcountsWithSleep];
        end
        
        
    end
    
end

if isempty(wdt) && isempty(wedt)
    fclose(fid);
    return;
end

%%
% weekly metrics
if ~isempty(dailyMVPA)
    MVPA_consistency = MVPAcoefvar(dailyMVPA);
    weekMVPAalpha = MVPA_weekly_alpha(dailyMVPA);
    weekMVPAw50 = MVPA_weekly_W50(dailyMVPA);
else
    MVPA_consistency = [];
    weekMVPAalpha = [];
    weekMVPAw50 = [];
end

alldays = [wdt;wedt];

meanWeek = nanmean(wdt,1);
if isempty(meanWeek)
    meanWeek = nan(1,size(alldays,2));
end
meanWE = nanmean(wedt,1);
if isempty(meanWE)
    meanWE = nan(1,size(alldays,2));
end

alldays11 = nanmean([meanWeek;meanWE],1);
alldays52 = nanmean([repmat(meanWeek,5,1);repmat(meanWE,2,1)],1);
alldaysunweight = nanmean(alldays,1);

%consistency of sleep duration
if ~isempty(wdt)
sleepCV_wd = nanstd(wdt(:,1))./nanmean(wdt(:,1)).*100;
else
    sleepCV_wd = NaN;
end

if ~isempty(wedt)    
sleepCV_wed = nanstd(wedt(:,1))./nanmean(wedt(:,1)).*100;
else
    sleepCV_wed = NaN;
end
if ~isempty(alldays)
sleepCV_ad = nanstd(alldays(:,1))./nanmean(alldays(:,1)).*100;
else
    sleepCV_ad = NaN;
end
sleepCV_ad11 = nanmean([sleepCV_wd sleepCV_wed]);
sleepCV_ad52 = nanmean([repmat(sleepCV_wd,5,1); repmat(sleepCV_wed,2,1)]);

meanWeek = [meanWeek(1:2) sleepCV_wd meanWeek(3:end)];
meanWE = [meanWE(1:2) sleepCV_wed meanWE(3:end)];
alldaysunweight = [alldaysunweight(1:2) sleepCV_ad alldaysunweight(3:end)];
alldays11 = [alldays11(1:2) sleepCV_ad11 alldays11(3:end)];
alldays52 = [alldays52(1:2) sleepCV_ad52 alldays52(3:end)];



fprintf(fid,'\n');
fprintf(fid,'\n');

%print averages
fprintf(fid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n',...
    'week day sleepTime','week day sleepTime24','week day sleep consistency','week day sleep midpoint','week day sleep efficiency','week day bedtime','week day getuptime','week day wearTime','week day sedTime','week day lightTime','week day modTime','week day vigTime','week day mvTime','week day mvpaBoutsTime','week day mvpaBoutsNumber','week day avg mvpaBoutsLength','week day average counts during MVPA','week day sedBoutsTime','week day sedBoutsNumber','week day avg sedBoutsLength','week day W50% sedentary','week day W50% MVPA','week day T50% MVPA','week day sedentary alpha','week day MVPA alpha','week day totCounts','week day avgCounts','week day totCounts with sleep','week day avgCounts with sleep',...
    'weekend or holidays sleepTime','weekend or holidays sleepTime24','weekend or holidays sleep consistency','weekend or holidays sleep midpoint','weekend or holidays sleep efficiency','weekend or holidays bedtime','weekend or holidays getuptime','weekend or holidays wearTime','weekend or holidays sedTime','weekend or holidays lightTime','weekend or holidays modTime','weekend or holidays vigTime','weekend or holidays mvTime','weekend or holidays mvpaBoutsTime','weekend or holidays mvpaBoutsNumber','weekend or holidays avg mvpaBoutsLength','weekend or holidays average counts during MVPA','weekend or holidays sedBoutsTime','weekend or holidays sedBoutsNumber','weekend or holidays avg sedBoutsLength','weekend or holidays W50% sedentary','weekend or holidays W50% MVPA','weekend or holidays T50% MVPA','weekend or holidays sedentary alpha','weekend or holidays MVPA alpha','weekend or holidays totCounts','weekend or holidays avgCounts','weekend or holidays totCounts with sleep','weekend or holidays avgCounts with sleep',...
    'all days sleepTime','all days sleepTime24','all days sleep consistency','all days sleep midpoint','all days sleep efficiency','all days bedtime','all days getuptime','all days wearTime','all days sedTime','all days lightTime','all days modTime','all days vigTime','all days mvTime','all days mvpaBoutsTime','all days mvpaBoutsNumber','all days avg mvpaBoutsLength','all days average counts during MVPA','all days sedBoutsTime','all days sedBoutsNumber','all days avg sedBoutsLength','all days W50% sedentary','all days W50% MVPA','all days T50% MVPA', 'all days sedentary alpha','all days MVPA alpha','all days totCounts','all days avgCounts','all days totCounts with sleep','all days avgCounts with sleep',...
    '11_all days sleepTime','11_all days sleepTime24','11_all days sleep consistency','11_all days sleep midpoint','11_all days sleep efficiency','11_all days bedtime','11_all days getuptime','11_all days wearTime','11_all days sedTime','11_all days lightTime','11_all days modTime','11_all days vigTime','11_all days mvTime','11_all days mvpaBoutsTime','11_all days mvpaBoutsNumber','11_all days avg mvpaBoutsLength','11_all days average counts during MVPA','11_all days sedBoutsTime','11_all days sedBoutsNumber','11_all days avg sedBoutsLength','11_all days W50% sedentary','11_all days W50% MVPA','11_all days T50% MVPA','11_all days sedentary alpha','11_all days MVPA alpha','11_all days totCounts','11_all days avgCounts','11_all days totCounts with sleep','11_all days avgCounts with sleep',...
    '52_all days sleepTime','52_all days sleepTime24','52_all days sleep consistency','52_all days sleep midpoint','52_all days sleep efficiency','52_all days bedtime','52_all days getuptime','52_all days wearTime','52_all days sedTime','52_all days lightTime','52_all days modTime','52_all days vigTime','52_all days mvTime','52_all days mvpaBoutsTime','52_all days mvpaBoutsNumber','52_all days avg mvpaBoutsLength','52_all days average counts during MVPA','52_all days sedBoutsTime','52_all days sedBoutsNumber','52_all days avg sedBoutsLength','52_all days W50% sedentary','52_all days W50% MVPA','52_all days T50%','52_all days sedentary alpha','52_all days MVPA alpha','52_all days totCounts','52_all days avgCounts','52_all days totCounts with sleep','52_all days avgCounts with sleep',...
    'start recording date');

fprintf(fid,...
    '%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.2f,%.2f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.2f,%.2f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.2f,%.2f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.2f,%.2f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.2f,%.2f,%.1f,%.1f,%.1f,%.1f,%s\n',...
    meanWeek,meanWE,alldaysunweight,alldays11,alldays52,udata.date{1});

fprintf(fid,'\n');
fprintf(fid,'\n');

fprintf(fid,'%s,%s,%s\n','weekly MVPA inconsistency','weekly MVPA alpha','weekly MVPA W50%');
fprintf(fid,'%.1f,%.2f,%.2f\n',MVPA_consistency,weekMVPAalpha ,weekMVPAw50);

fprintf(fid,'\n');
fprintf(fid,'\n');

%summary header
fprintf(fid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n','file ID','valid file','valid weekdays','valid weekend days','total valid days','min valid weekdays for valid file','min valid weekend days for valid file','non wear window size (min)','light threshold (counts)','moderate threshold (counts)','vigorous threshold (counts)','MVPA bout window size (min)','MVPA bout % above','sedentary bout window size (min)','sedentary bout % above','min wear for valid day (min)','max non wear for valid day (min)');
fprintf(fid,'%s,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u\n',contents{get(handles.FilesList,'Value')},(vwd>=3 && vwed >=1),vwd,vwed,vwd+vwed,3,1,round(str2double(get(handles.nonwearThreshold,'String'))),round(str2double(get(handles.lightThreshold,'String'))),round(str2double(get(handles.moderateThreshold,'String'))),round(str2double(get(handles.vigorousThreshold,'String'))),round(str2double(get(handles.MVPADur,'String'))),round(str2double(get(handles.MVPAPercent,'String'))),round(str2double(get(handles.sedDur,'String'))),round(str2double(get(handles.sedPercent,'String'))),round(str2double(get(handles.wearTimeValid,'String'))),round(str2double(get(handles.nwearTimeValid,'String'))));

fclose(fid);

%save udata with events
res = rmfield(udata,'impData');
save(fullfile(matPath,fnMat),'res');

%save figure
hf = figure('units','normalized','outerposition',[0 0 1 1],'color','white');
ho = get(handles.mainFig,'children');
ho(strcmp(get(ho,'type'),'uicontrol')) = [];
copyobj(ho,hf);
export_fig(fullfile(figPath,fnFig));
close(hf);

end