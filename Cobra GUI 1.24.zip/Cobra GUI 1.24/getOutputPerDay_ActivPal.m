function getOutputPerDay_ActivPal(udata,handles)

%%
%valid file
nwval = round(str2double(get(handles.nwearTimeValid,'String')))*600;
wval = round(str2double(get(handles.wearTimeValid,'String')))*600;

vwd = 0;    %no of valid week days
vwed = 0;   %no of valid weekend days

%%
%file management
%get file name
contents = cellstr(get(handles.FilesList,'String'));
iifile = get(handles.FilesList,'Value');
fn = contents{get(handles.FilesList,'Value')}; fn = fn(1:strfind(fn,'.')-1);
fnCsv = [fn '_RESULTS.csv'];
fnMat = [fn '.mat'];
fnFig = [fn '_RESULTS.png'];

%create paths to save
csvPath = [udata.rPath '\csv'];
if ~isdir(csvPath), mkdir(csvPath); end
matPath = [udata.rPath '\mat'];
if ~isdir(matPath), mkdir(matPath); end
figPath = [udata.rPath '\figures'];
if ~isdir(figPath), mkdir(figPath); end

fid = fopen(fullfile(csvPath,fnCsv),'w');

%print header
fprintf(fid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n',...
    'day no','is weekend','sitting min','sitting <30 min','sitting >30 min',...
    'standing min','stepping min','stepping >10 min','awake obs min',...
    'no of sitting bouts >30','no of stand/step bouts','no of sitstand trans','no steps',...
    'sleep min','sitstand trans per hour sitting',...
    '% sit','% sit >30min');



%%
%create variable holding only activity and step count
%actArray = (600 x 4 x nepochs)
%1=activity (0=sit 1=stand 2+step)
%2=step count (cumulative)
%3=sleep (bool)
%4=non wear (bool)
actArray = nan(size(udata.impDataRaw{iifile},1),4,size(udata.impDataRaw{iifile},3));
actArray(:,1,:) = udata.impDataRaw{iifile}(:,3,:);
actArray(:,2,:) = udata.impDataRaw{iifile}(:,4,:);

for iep = 1:size(actArray,3)
    actArray(:,3,iep) = udata.events.sleep(iep);
    actArray(:,4,iep) = udata.events.nonwear(iep);
end

actArray = permute(actArray,[1 3 2]);
actArray = reshape(actArray,(size(actArray,1)*size(actArray,2)),4);

%get activities

%levels
udata.events.sitRaw = actArray(:,1)==0 & actArray(:,3)~=1 & actArray(:,4)~=1;
udata.events.standRaw = actArray(:,1)==1 & actArray(:,3)~=1 & actArray(:,4)~=1;
udata.events.stepRaw = actArray(:,1)==2 & actArray(:,3)~=1 & actArray(:,4)~=1;
udata.events.obsRaw = actArray(:,3)~=1 & actArray(:,4)~=1;
udata.events.sleepRaw = actArray(:,3) & ~actArray(:,4);
udata.events.nwRaw = actArray(:,4);

%sit stand trans
udata.events.sstrans = [1; udata.events.sitRaw(1:end-1)] & udata.events.standRaw;

%bouts
mvw = round(str2double(get(handles.MVPADur,'String')))*600;
mvper = round(str2double(get(handles.MVPAPercent,'String')));
sedw = round(str2double(get(handles.sedDur,'String')))*600;
sedper = round(str2double(get(handles.sedPercent,'String')));
mvCrit = mvw*mvper/100;
sedCrit = sedw*sedper/100;
tic
mvbouts=false(size(actArray,1),1);
mvbouts = getMVPAbouts_ActivPal((udata.events.standRaw | udata.events.stepRaw),mvbouts,mvw,mvCrit);
toc
udata.events.stepboutsRaw = mvbouts;
clear mvbouts;

sedbouts=false(size(actArray,1),1);
sedbouts = getMVPAbouts_ActivPal(udata.events.sitRaw,sedbouts,sedw,sedCrit);

udata.events.sitboutsRaw = sedbouts;
clear sedbouts;

%% valid days

td = (udata.events.day-1)*600+1;

wdt = [];
wedt = [];

%get start of recording period
startH = str2double(get(handles.startPeriodH,'String'));
startM = str2double(get(handles.startPeriodM,'String'));

%convert start time to ActivPal epochs
offsetEpochs = (startH * 36000) + (startM * 600);

%create offset vector
td_off = td + offsetEpochs;

for iday = 1:size(td,1)
    
    if iday == size(td,1) && offsetEpochs ~= 0 %if last day and we dont process starting at midnight
        endEpoch = 863999 - offsetEpochs;
    else
        endEpoch = 863999;
    end
        
    %check if day is valid
    if (size(find(udata.events.nwRaw(td_off(iday):td_off(iday)+endEpoch)),1) < nwval)% &&  ((size(find(~udata.events.nwRaw(td_off(iday):td_off(iday)+endEpoch)),1) - size(find(udata.events.sleepRaw(td_off(iday):td_off(iday)+endEpoch)),1)) > wval)
        
        %day is valid, carry on processing
        
        %check if week or weekend day
        [dn, ~] =weekday(datenum(udata.date(udata.events.day(iday)),'dd/mm/yyyy'));
        if (dn == 1) || (dn == 7)
            isweekend = 1;
            disp(['day ' num2str(iday) ' is valid - weekend']);
            vwed = vwed+1;
        else
            isweekend = 0;
            disp(['day ' num2str(iday) ' is valid - weekday']);
            vwd = vwd+1;
        end
        
        % sleep time
        % ignore sleep time for first day
        if iday == 1
            sleepTime = NaN;
        else
            sleepTime = size(find(udata.events.sleepRaw(td_off(iday)-432000:td_off(iday)+431999)),1);
        end
        % wear time
        wearTime = size(find(~udata.events.nwRaw(td_off(iday):td_off(iday)+endEpoch)),1) - size(find(udata.events.sleepRaw(td_off(iday):td_off(iday)+endEpoch)),1); %%%%%%%%%%%%%%%%%%%%%%%%%%%
        % sed time
        sedTime = size(find(udata.events.sitRaw(td_off(iday):td_off(iday)+endEpoch)),1);
        % light time
        lightTime = size(find(udata.events.standRaw(td_off(iday):td_off(iday)+endEpoch)),1);
        % moderate time
        modTime = size(find(udata.events.stepRaw(td_off(iday):td_off(iday)+endEpoch)),1);
        % vigorous time
%         vigTime = size(find(udata.events.vigorous(td_off(iday):td_off(iday)+endEpoch)),1);
        % MVPA time
        mvTime = modTime;
        % MVPA bouts time
        stepboutsTime = size(find(udata.events.stepboutsRaw(td_off(iday):td_off(iday)+endEpoch)),1);
        % sed bouts time
        sitboutsTime = size(find(udata.events.sitboutsRaw(td_off(iday):td_off(iday)+endEpoch)),1);
        %sit stand transitions
        ssTrans = size(find(udata.events.sstrans(td_off(iday):td_off(iday)+endEpoch)),1);
        
        %no of steps
        if iday==1
            noSteps = actArray(td_off(iday)+endEpoch,2)-actArray(td_off(iday),2);
        else
            noSteps = actArray(td_off(iday)+endEpoch,2)-actArray(td_off(iday)-1,2);
        end
        
%         %total counts
%         totcounts = sum(udata.counts(td_off(iday):td_off(iday)+endEpoch));
        
        %total counts excluding sleep and non wear
%         tmpcnt = udata.counts(td_off(iday):td_off(iday)+endEpoch);
%         tmpMask = ~(udata.events.sleep(td_off(iday):td_off(iday)+endEpoch) | udata.events.nonwear(td_off(iday):td_off(iday)+endEpoch));
%         tmpcnt = tmpcnt(tmpMask);
%         totcounts = sum(tmpcnt); avgcounts = totcounts./size(tmpcnt,1)
        
        %number of bouts - sedentary
        sedboutsNumber = ceil(size(find(diff(udata.events.sitboutsRaw(td_off(iday):td_off(iday)+endEpoch))),1)./2);
        %if the day both starts and end with a bout we need to add 1 bout
        if udata.events.sitboutsRaw(td_off(iday)) == 1 && udata.events.sitboutsRaw(td_off(iday)+endEpoch) == 1
            sedboutsNumber = sedboutsNumber+1;
        end
        %number of bouts - mvpa
        mvpaboutsNumber = ceil(size(find(diff(udata.events.stepboutsRaw(td_off(iday):td_off(iday)+endEpoch))),1)./2);
        %if the day both starts and end with a bout we need to add 1 bout
        if udata.events.stepboutsRaw(td_off(iday)) == 1 && udata.events.stepboutsRaw(td_off(iday)+endEpoch) == 1
            mvpaboutsNumber = mvpaboutsNumber+1;
        end
        
        %bout length at which 50% sed time is accumulated
%         sedBoutLength50 = findSedBoutLength50(udata.events.sedentary(td_off(iday):td_off(iday)+endEpoch));
        
        
%         fprintf(fid,'%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u\n',iday,isweekend,sleepTime,wearTime,sedTime,lightTime,modTime,vigTime,mvTime,mvpaboutsTime,mvpaboutsNumber,(mvpaboutsTime./mvpaboutsNumber),sedboutsTime,sedboutsNumber,(sedboutsTime./sedboutsNumber),sedBoutLength50,totcounts,(totcounts./wearTime));
        fprintf(fid,'%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u\n',iday,isweekend,sedTime/600,(sedTime-sitboutsTime)/600,sitboutsTime/600,lightTime/600,modTime/600,stepboutsTime/600,wearTime/600,sedboutsNumber,mvpaboutsNumber,ssTrans,noSteps,sleepTime/600,ssTrans/(sedTime/36000),sedTime*100/wearTime,sitboutsTime*100/wearTime);
        %store for averaging later
        if isweekend
            wedt(end+1,:) = [sedTime/600,(sedTime-sitboutsTime)/600,sitboutsTime/600,lightTime/600,modTime/600,stepboutsTime/600,wearTime/600,sedboutsNumber,mvpaboutsNumber,ssTrans,noSteps,sleepTime/600,ssTrans/(sedTime/36000),sedTime*100/wearTime,sitboutsTime*100/wearTime];
        else
            wdt(end+1,:) = [sedTime/600,(sedTime-sitboutsTime)/600,sitboutsTime/600,lightTime/600,modTime/600,stepboutsTime/600,wearTime/600,sedboutsNumber,mvpaboutsNumber,ssTrans,noSteps,sleepTime/600,ssTrans/(sedTime/36000),sedTime*100/wearTime,sitboutsTime*100/wearTime];
        end
        
    end
    
end

alldays = [wdt;wedt];

fprintf(fid,'\n');
fprintf(fid,'\n');

%print averages
fprintf(fid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n',...
    'all days sitting min','all days sitting <30 min','all days sitting >30 min',...
    'all days standing min','all days stepping min','all days stepping >10 min','all days awake obs min',...
    'all days no of sitting bouts >30','all days no of stand/step bouts','all days no of sitstand trans','all days no steps',...
    'all days sleep min','all days sitstand trans per hour sitting',...
    'all days % sit','all days % sit >30min',...
    'weekday sitting min','weekday sitting <30 min','weekday sitting >30 min',...
    'weekday standing min','weekday stepping min','weekday stepping >10 min','weekday awake obs min',...
    'weekday no of sitting bouts >30','weekday no of stand/step bouts','weekday no of sitstand trans','weekday no steps',...
    'weekday sleep min','weekday sitstand trans per hour sitting',...
    'weekday % sit','weekday % sit >30min',...
    'weekend day sitting min','weekend day sitting <30 min','weekend day sitting >30 min',...
    'weekend day standing min','weekend day stepping min','weekend day stepping >10 min','weekend day awake obs min',...
    'weekend day no of sitting bouts >30','weekend day no of stand/step bouts','weekend day no of sitstand trans','weekend day no steps',...
    'weekend day sleep min','weekend day sitstand trans per hour sitting',...
    'weekend day % sit','weekend day % sit >30min');



fprintf(fid,'%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f\n',...
    nanmean(alldays,1),nanmean(wdt,1),nanmean(wedt,1));

fprintf(fid,'\n');
fprintf(fid,'\n');

%summary header
fprintf(fid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n','file ID','valid file','valid weekdays','valid weekend days','total valid days','min valid weekdays for valid file','min valid weekend days for valid file','non wear window size (min)','step bout window size (min)','step bout % above','sitting bout window size (min)','sitting bout % above','min wear for valid day (min)','max non wear for valid day (min)');
fprintf(fid,'%s,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u\n',contents{get(handles.FilesList,'Value')},(vwd>=3 && vwed >=1),vwd,vwed,vwd+vwed,3,1,round(str2double(get(handles.nonwearThreshold,'String'))),round(str2double(get(handles.MVPADur,'String'))),round(str2double(get(handles.MVPAPercent,'String'))),round(str2double(get(handles.sedDur,'String'))),round(str2double(get(handles.sedPercent,'String'))),round(str2double(get(handles.wearTimeValid,'String'))),round(str2double(get(handles.nwearTimeValid,'String'))));

fclose(fid);

%save udata with events
res = rmfield(udata,'impData');
res = rmfield(res,'impDataRaw');

save(fullfile(matPath,fnMat),'res');

%save figure
hf = figure('units','normalized','outerposition',[0 0 1 1],'color','white');
ho = get(handles.mainFig,'children');
ho(strcmp(get(ho,'type'),'uicontrol')) = [];
copyobj(ho,hf);
export_fig(fullfile(figPath,fnFig));
close(hf);






    
    